# Morning Brew Collective

A Singapore-first headless commerce platform with 1970s retro kopitiam aesthetic and avant-garde minimalism.

## Tech Stack

- **Frontend**: Next.js 15 (App Router) + React 19 + TypeScript
- **Backend**: Laravel 12 + PHP 8.3
- **Database**: PostgreSQL 16
- **Cache**: Redis 7
- **Payments**: Stripe + PayNow
- **Container**: Docker + Docker Compose

## Features

- 🏪 Singapore GST 9% compliance
- 💳 PayNow integration
- 📄 InvoiceNow (PEPPOL) support
- 🔒 PDPA compliance
- 🛒 Real-time inventory management
- 📱 Mobile-first responsive design
- ♿ WCAG 2.2 AAA accessibility

## Quick Start

### Prerequisites

- Docker and Docker Compose
- Node.js 22+ (for local development)
- PHP 8.3+ (for local development)

### Development Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd morning-brew-collective
```

2. Copy environment files:
```bash
cp .env.example .env
cp backend/.env.example backend/.env
```

3. Start the services:
```bash
make up
```

4. Install dependencies:
```bash
make install
```

5. Run database migrations:
```bash
make migrate
```

6. Access the application:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- Mailpit (email testing): http://localhost:8025

### Development Commands

```bash
make help              # Show all available commands
make logs              # Tail all logs
make shell-backend     # Access backend container shell
make shell-frontend    # Access frontend container shell
make migrate           # Run database migrations
make test              # Run all tests
make lint              # Lint all code
make format            # Format all code
```

## Project Structure

```
morning-brew-collective/
├── frontend/           # Next.js 15 application
├── backend/            # Laravel 12 application
├── infra/              # Docker & infrastructure
├── docs/               # Documentation
├── scripts/            # Development scripts
└── docker-compose.yml  # Local development services
```

## Compliance

- **GST Act**: All prices displayed inclusive of 9% GST
- **PDPA**: Explicit consent collection with audit trail
- **InvoiceNow**: UBL 2.1 XML generation for B2B
- **PayNow**: Stripe integration for instant payments

## Design System

The design system is based on 1970s kopitiam heritage with:

- **Colors**: Sunrise Coral (#FF6B4A), Golden Hour (#FFBE4F), Espresso Dark (#3D2317)
- **Typography**: Righteous (display), Nunito (body)
- **Motion**: Bounce easing with 150ms/300ms/500ms duration scale
- **Decorative**: Sunburst gradients, wave dividers, coffee ring elements

## Contributing

1. Follow the established coding standards
2. Write tests for all new features
3. Ensure accessibility compliance (WCAG 2.2 AAA)
4. Maintain the retro kopitiam aesthetic

## License

Private - Morning Brew Collective