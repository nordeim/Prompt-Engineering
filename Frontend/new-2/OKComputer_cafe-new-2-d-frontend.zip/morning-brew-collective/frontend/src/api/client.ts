import { z } from 'zod';

// Type definitions
export interface Product {
  id: string;
  sku: string;
  name: string;
  description: string | null;
  price: number;
  price_formatted: string;
  category: string;
  tags: string[] | null;
  image_url: string | null;
  available_stock: number;
  is_active: boolean;
  created_at: string;
}

export interface Location {
  id: string;
  name: string;
  badge: string | null;
  address: string;
  postal_code: string;
  phone: string;
  email: string;
  hours: Record<string, any>;
  todays_hours: any;
  features: string[];
  image_url: string | null;
  latitude: number;
  longitude: number;
  full_address: string;
  is_open_now: boolean;
}

export interface TimeSlot {
  time: string;
  formatted: string;
  available: boolean;
}

export interface OrderItem {
  product_id: string;
  product_name: string;
  product_sku: string;
  price: number;
  price_formatted: string;
  quantity: number;
  category: string;
  total: number;
  total_formatted: string;
}

export interface Order {
  id: string;
  invoice_number: string;
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  pickup_location: string | null;
  pickup_location_address: string | null;
  pickup_datetime: string | null;
  subtotal: number;
  gst: number;
  total: number;
  subtotal_formatted: string;
  gst_formatted: string;
  total_formatted: string;
  status: string;
  payment_method: string;
  payment_status: string;
  special_instructions: string | null;
  items: OrderItem[];
  created_at: string;
  updated_at: string;
}

export interface CreateOrderPayload {
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  pickup_location_id: string;
  pickup_datetime: string;
  items: Array<{
    product_id: string;
    quantity: number;
  }>;
  payment_method: 'paynow' | 'credit_card' | 'cash';
  special_instructions?: string;
  consent_marketing?: boolean;
}

export interface CreateOrderResponse {
  invoice_number: string;
  payment_intent_id: string | null;
  payment_url: string | null;
  order: {
    id: string;
    invoice_number: string;
    total: number;
    total_formatted: string;
    status: string;
    payment_method: string;
  };
}

// API Client
export class ApiClient {
  private baseUrl: string;

  constructor(baseUrl: string = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api') {
    this.baseUrl = baseUrl;
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    const config: RequestInit = {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    };

    const response = await fetch(url, config);

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || `HTTP error! status: ${response.status}`);
    }

    return response.json();
  }

  // Products
  async getProducts(params?: {
    category?: string;
    in_stock?: boolean;
    search?: string;
    sort_by?: 'name' | 'price' | 'created_at';
    sort_dir?: 'asc' | 'desc';
    per_page?: number;
  }): Promise<{
    data: Product[];
    meta: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
  }> {
    const query = new URLSearchParams();
    
    if (params?.category) query.append('category', params.category);
    if (params?.in_stock !== undefined) query.append('in_stock', String(params.in_stock));
    if (params?.search) query.append('search', params.search);
    if (params?.sort_by) query.append('sort_by', params.sort_by);
    if (params?.sort_dir) query.append('sort_dir', params.sort_dir);
    if (params?.per_page) query.append('per_page', String(params.per_page));

    return this.request(`/products?${query}`);
  }

  async getProduct(id: string): Promise<Product> {
    return this.request(`/products/${id}`);
  }

  async getProductCategories(): Promise<{ data: string[] }> {
    return this.request('/products/categories');
  }

  // Locations
  async getLocations(): Promise<{ data: Location[] }> {
    return this.request('/locations');
  }

  async getLocation(id: string): Promise<Location> {
    return this.request(`/locations/${id}`);
  }

  async getTimeSlots(locationId: string, date?: string): Promise<{ data: TimeSlot[] }> {
    const query = date ? `?date=${date}` : '';
    return this.request(`/locations/${locationId}/time-slots${query}`);
  }

  // Orders
  async createOrder(order: CreateOrderPayload): Promise<CreateOrderResponse> {
    return this.request('/orders', {
      method: 'POST',
      body: JSON.stringify(order),
    });
  }

  async getOrder(id: string): Promise<Order> {
    return this.request(`/orders/${id}`);
  }

  async cancelOrder(id: string): Promise<{ message: string }> {
    return this.request(`/orders/${id}/cancel`, {
      method: 'POST',
    });
  }

  // Health check
  async healthCheck(): Promise<{
    status: string;
    timestamp: string;
    version: string;
  }> {
    return this.request('/health');
  }
}

// Singleton instance
const apiClient = new ApiClient();

export default apiClient;