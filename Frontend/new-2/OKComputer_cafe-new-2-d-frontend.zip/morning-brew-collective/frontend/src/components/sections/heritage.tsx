import { WaveDivider } from '@/components/ui/wave-divider';

export function HeritageSection() {
  return (
    <section id="heritage" className="py-20 bg-ceramic-white">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="font-display text-4xl md:text-5xl text-espresso-dark mb-6">
              Our Heritage
            </h2>
            <div className="space-y-6 text-coffee-medium leading-relaxed">
              <p>
                Morning Brew Collective was born from a simple desire: to preserve the authentic 
                taste of Singapore's beloved kopitiam culture while embracing modern convenience.
              </p>
              <p>
                Our recipes have been passed down through three generations, from the charcoal-roasted 
                coffee beans to the perfectly balanced kaya recipe that's been perfected over decades.
              </p>
              <p>
                Every cup of kopi, every slice of kaya toast, tells a story of Singapore's multicultural 
                heritage—a beautiful blend of Chinese, Malay, and Indian influences that make our 
                kopitiam culture uniquely ours.
              </p>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square bg-paper-aged rounded-3xl p-8 flex items-center justify-center">
              <div className="text-center">
                <div className="w-32 h-32 bg-sunrise-coral rounded-full mx-auto mb-6 flex items-center justify-center">
                  <span className="text-white font-display text-4xl">MBC</span>
                </div>
                <p className="font-display text-2xl text-espresso-dark mb-2">Since 1950</p>
                <p className="text-coffee-medium">Three generations of tradition</p>
              </div>
            </div>
            
            {/* Decorative coffee ring */}
            <div className="absolute -top-4 -right-4 w-24 h-24 border-4 border-coffee-light rounded-full opacity-30" />
            <div className="absolute -bottom-4 -left-4 w-16 h-16 border-4 border-golden-hour rounded-full opacity-30" />
          </div>
        </div>
      </div>
    </section>
  );
}