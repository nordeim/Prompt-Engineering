export function LocationsSection() {
  const locations = [
    {
      name: 'Tanjong Pagar',
      badge: 'Flagship',
      address: '123 Tanjong Pagar Road, Singapore 088533',
      hours: 'Mon-Fri: 7am-7pm, Sat-Sun: 7am-9pm',
      features: ['Dine-in', 'Takeaway', 'Delivery'],
    },
    {
      name: 'Tiong Bahru',
      address: '456 Tiong Bahru Road, Singapore 168730',
      hours: 'Mon-Sun: 7am-8pm',
      features: ['Dine-in', 'Takeaway'],
    },
    {
      name: 'Katong',
      address: '789 East Coast Road, Singapore 459054',
      hours: 'Mon-Sun: 6am-9pm',
      features: ['Dine-in', 'Takeaway', 'Delivery'],
    },
  ];

  return (
    <section id="locations" className="py-20 bg-mint-fresh/10">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl text-espresso-dark mb-4">
            Our Locations
          </h2>
          <p className="text-xl text-coffee-medium max-w-2xl mx-auto">
            Find us at these convenient locations across Singapore. 
            Each outlet maintains the same quality and tradition you've come to expect.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {locations.map((location, index) => (
            <div key={index} className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-display text-2xl text-espresso-dark">{location.name}</h3>
                {location.badge && (
                  <span className="bg-sunrise-coral text-white text-xs px-3 py-1 rounded-full">
                    {location.badge}
                  </span>
                )}
              </div>
              
              <p className="text-coffee-medium mb-4">{location.address}</p>
              
              <div className="mb-4">
                <p className="text-sm font-medium text-espresso-dark mb-2">Operating Hours:</p>
                <p className="text-sm text-coffee-medium">{location.hours}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-espresso-dark mb-2">Services:</p>
                <div className="flex flex-wrap gap-2">
                  {location.features.map((feature, idx) => (
                    <span key={idx} className="text-xs bg-mint-fresh text-teal-retro px-2 py-1 rounded">
                      {feature}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}