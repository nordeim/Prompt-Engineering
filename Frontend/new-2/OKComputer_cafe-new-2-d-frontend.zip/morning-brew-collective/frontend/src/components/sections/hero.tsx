import { Button } from '@/components/ui/button';

export function HeroSection() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Sunburst Background */}
      <div className="absolute inset-0 sunburst-bg" />
      
      {/* Content */}
      <div className="relative z-10 container text-center">
        <div className="max-w-4xl mx-auto">
          <h1 className="font-display text-5xl md:text-7xl text-espresso-dark mb-6">
            Morning Brew
            <span className="block text-sunrise-coral">Collective</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-coffee-medium mb-8 leading-relaxed">
            Where Singapore's kopitiam heritage meets modern convenience. 
            Authentic flavors, traditional recipes, contemporary service.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-sunrise-coral hover:bg-sunrise-coral-dark text-white">
              Order Now
            </Button>
            <Button size="lg" variant="outline" className="border-coffee-medium text-coffee-medium hover:bg-coffee-medium hover:text-white">
              View Menu
            </Button>
          </div>
        </div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-8 left-8 opacity-20">
        <div className="w-16 h-16 bg-golden-hour rounded-full" />
      </div>
      <div className="absolute top-8 right-8 opacity-20">
        <div className="w-12 h-12 bg-mint-fresh rounded-full" />
      </div>
    </section>
  );
}