import { ProductCard } from '@/components/ui/product-card';
import { WaveDivider } from '@/components/ui/wave-divider';

export function MenuSection() {
  // Mock data - in real implementation, this would come from API
  const featuredProducts = [
    {
      id: '1',
      name: 'Traditional Kopi O',
      description: 'Strong black coffee brewed the traditional way',
      price: 1.50,
      image: '/images/kopi-o.jpg',
      category: 'Beverages',
    },
    {
      id: '2',
      name: 'Kaya Toast Set',
      description: 'Toasted bread with kaya and butter, served with soft-boiled eggs',
      price: 4.50,
      image: '/images/kaya-toast.jpg',
      category: 'Breakfast',
    },
    {
      id: '3',
      name: 'Nasi Lemak',
      description: 'Coconut rice with anchovies, peanuts, egg, and sambal',
      price: 5.50,
      image: '/images/nasi-lemak.jpg',
      category: 'Mains',
    },
    {
      id: '4',
      name: 'Teh Tarik',
      description: 'Pulled tea with condensed milk, frothy and smooth',
      price: 1.80,
      image: '/images/teh-tarik.jpg',
      category: 'Beverages',
    },
  ];

  return (
    <section id="menu" className="py-20 bg-latte-cream">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl text-espresso-dark mb-4">
            Our Menu
          </h2>
          <p className="text-xl text-coffee-medium max-w-2xl mx-auto">
            Traditional recipes passed down through generations, 
            made with authentic ingredients and time-honored techniques.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center">
          <a href="/menu" className="inline-flex items-center px-6 py-3 bg-sunrise-coral text-white font-medium rounded-full hover:bg-sunrise-coral-dark transition-colors">
            View Full Menu
          </a>
        </div>
      </div>

      <WaveDivider />
    </section>
  );
}