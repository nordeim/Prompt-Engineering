interface WaveDividerProps {
  className?: string;
  direction?: 'up' | 'down';
}

export function WaveDivider({ className = '', direction = 'up' }: WaveDividerProps) {
  return (
    <div className={`wave-divider ${className} ${direction === 'down' ? 'transform rotate-180' : ''}`}>
      <div className="wave-divider" />
    </div>
  );
}