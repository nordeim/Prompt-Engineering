'use client';

import { ThemeProvider as ShadcnThemeProvider } from "next-themes";
import { designTokens } from "@/lib/design-tokens";

interface ThemeProviderProps {
  children: React.ReactNode;
}

export function ThemeProvider({ children }: ThemeProviderProps) {
  return (
    <ShadcnThemeProvider
      attribute="class"
      defaultTheme="light"
      enableSystem={false}
      disableTransitionOnChange
    >
      <style jsx global>{`
        :root {
          /* Colors */
          --color-sunrise-coral: ${designTokens.colors.sunriseCoral};
          --color-sunrise-coral-light: ${designTokens.colors.sunriseCoralLight};
          --color-sunrise-coral-dark: ${designTokens.colors.sunriseCoralDark};
          
          --color-golden-hour: ${designTokens.colors.goldenHour};
          --color-golden-hour-light: ${designTokens.colors.goldenHourLight};
          --color-golden-hour-dark: ${designTokens.colors.goldenHourDark};
          
          --color-espresso-dark: ${designTokens.colors.espressoDark};
          --color-coffee-medium: ${designTokens.colors.coffeeMedium};
          --color-coffee-light: ${designTokens.colors.coffeeLight};
          --color-mocha-cream: ${designTokens.colors.mochaCream};
          
          --color-latte-cream: ${designTokens.colors.latteCream};
          --color-latte-cream-warm: ${designTokens.colors.latteCreamWarm};
          --color-ceramic-white: ${designTokens.colors.ceramicWhite};
          --color-paper-aged: ${designTokens.colors.paperAged};
          
          --color-mint-fresh: ${designTokens.colors.mintFresh};
          --color-mint-deep: ${designTokens.colors.mintDeep};
          --color-teal-retro: ${designTokens.colors.tealRetro};
          
          --color-success: ${designTokens.colors.success};
          --color-error: ${designTokens.colors.error};
          --color-warning: ${designTokens.colors.warning};
          --color-info: ${designTokens.colors.info};
          
          --color-tile-pattern-1: ${designTokens.colors.tilePattern1};
          --color-tile-pattern-2: ${designTokens.colors.tilePattern2};
          
          /* Spacing */
          --space-0: ${designTokens.spacing.space0};
          --space-1: ${designTokens.spacing.space1};
          --space-2: ${designTokens.spacing.space2};
          --space-3: ${designTokens.spacing.space3};
          --space-4: ${designTokens.spacing.space4};
          --space-5: ${designTokens.spacing.space5};
          --space-6: ${designTokens.spacing.space6};
          --space-8: ${designTokens.spacing.space8};
          --space-10: ${designTokens.spacing.space10};
          --space-12: ${designTokens.spacing.space12};
          --space-16: ${designTokens.spacing.space16};
          --space-20: ${designTokens.spacing.space20};
          --space-24: ${designTokens.spacing.space24};
          --space-32: ${designTokens.spacing.space32};
          --space-40: ${designTokens.spacing.space40};
          --space-48: ${designTokens.spacing.space48};
          --space-56: ${designTokens.spacing.space56};
          --space-64: ${designTokens.spacing.space64};
          
          /* Radius */
          --radius-xs: ${designTokens.radii.xs};
          --radius-sm: ${designTokens.radii.sm};
          --radius-md: ${designTokens.radii.md};
          --radius-lg: ${designTokens.radii.lg};
          --radius-xl: ${designTokens.radii.xl};
          --radius-2xl: ${designTokens.radii['2xl']};
          --radius-full: ${designTokens.radii.full};
          
          /* Shadows */
          --shadow-sm: ${designTokens.shadows.sm};
          --shadow-md: ${designTokens.shadows.md};
          --shadow-lg: ${designTokens.shadows.lg};
          --shadow-xl: ${designTokens.shadows.xl};
          --shadow-2xl: ${designTokens.shadows['2xl']};
          --shadow-glow: ${designTokens.shadows.glow};
          
          /* Animations */
          --ease-bounce: ${designTokens.animations.easeBounce};
          --ease-smooth: ${designTokens.animations.easeSmooth};
          --ease-standard: ${designTokens.animations.easeStandard};
          --ease-accelerate: ${designTokens.animations.easeAccelerate};
          --ease-decelerate: ${designTokens.animations.easeDecelerate};
          
          --duration-fast: ${designTokens.animations.durationFast};
          --duration-normal: ${designTokens.animations.durationNormal};
          --duration-slow: ${designTokens.animations.durationSlow};
          --duration-slower: ${designTokens.animations.durationSlower};
          
          /* Z-index */
          --z-dropdown: ${designTokens.zIndex.dropdown};
          --z-sticky: ${designTokens.zIndex.sticky};
          --z-fixed: ${designTokens.zIndex.fixed};
          --z-modal-backdrop: ${designTokens.zIndex.modalBackdrop};
          --z-modal: ${designTokens.zIndex.modal};
          --z-popover: ${designTokens.zIndex.popover};
          --z-tooltip: ${designTokens.zIndex.tooltip};
          
          /* Breakpoints */
          --breakpoint-sm: ${designTokens.breakpoints.sm};
          --breakpoint-md: ${designTokens.breakpoints.md};
          --breakpoint-lg: ${designTokens.breakpoints.lg};
          --breakpoint-xl: ${designTokens.breakpoints.xl};
          --breakpoint-2xl: ${designTokens.breakpoints['2xl']};
          
          /* Container */
          --container-sm: ${designTokens.breakpoints.sm};
          --container-md: ${designTokens.breakpoints.md};
          --container-lg: ${designTokens.breakpoints.lg};
          --container-xl: ${designTokens.breakpoints.xl};
          --container-2xl: ${designTokens.breakpoints['2xl']};
          
          /* Typography */
          --font-display: ${designTokens.fonts.display};
          --font-body: ${designTokens.fonts.body};
          --font-mono: ${designTokens.fonts.mono};
          
          --text-xs: ${designTokens.fontSizes.xs};
          --text-sm: ${designTokens.fontSizes.sm};
          --text-base: ${designTokens.fontSizes.base};
          --text-lg: ${designTokens.fontSizes.lg};
          --text-xl: ${designTokens.fontSizes.xl};
          --text-2xl: ${designTokens.fontSizes['2xl']};
          --text-3xl: ${designTokens.fontSizes['3xl']};
          --text-4xl: ${designTokens.fontSizes['4xl']};
          --text-5xl: ${designTokens.fontSizes['5xl']};
          
          --leading-none: ${designTokens.lineHeights.none};
          --leading-tight: ${designTokens.lineHeights.tight};
          --leading-snug: ${designTokens.lineHeights.snug};
          --leading-normal: ${designTokens.lineHeights.normal};
          --leading-relaxed: ${designTokens.lineHeights.relaxed};
          --leading-loose: ${designTokens.lineHeights.loose};
        }
      `}</style>
      {children}
    </ShadcnThemeProvider>
  );
}