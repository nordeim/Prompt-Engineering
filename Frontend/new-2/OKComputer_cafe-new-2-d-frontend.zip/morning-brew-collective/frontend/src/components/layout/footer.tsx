export function Footer() {
  return (
    <footer className="bg-espresso-dark text-latte-cream py-12">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-sunrise-coral rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">M</span>
              </div>
              <span className="font-display text-xl">Morning Brew Collective</span>
            </div>
            <p className="text-coffee-light leading-relaxed max-w-md">
              Preserving Singapore's kopitiam heritage with modern convenience. 
              Authentic flavors, traditional recipes, contemporary service.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-display text-lg mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="/menu" className="text-coffee-light hover:text-sunrise-coral transition-colors">
                  Menu
                </a>
              </li>
              <li>
                <a href="/heritage" className="text-coffee-light hover:text-sunrise-coral transition-colors">
                  Heritage
                </a>
              </li>
              <li>
                <a href="/locations" className="text-coffee-light hover:text-sunrise-coral transition-colors">
                  Locations
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-display text-lg mb-4">Contact</h3>
            <div className="space-y-2 text-coffee-light">
              <p>hello@morningbrew.sg</p>
              <p>+65 6123 4567</p>
              <p className="text-sm mt-4">
                Operating Hours:<br />
                Mon-Fri: 7am - 7pm<br />
                Sat-Sun: 7am - 9pm
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-coffee-medium mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-coffee-light text-sm">
            © 2024 Morning Brew Collective. All rights reserved.
          </p>
          <p className="text-coffee-light text-sm mt-2 md:mt-0">
            GST Reg No: 2024123456K
          </p>
        </div>
      </div>
    </footer>
  );
}