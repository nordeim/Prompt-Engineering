export const designTokens = {
  colors: {
    // Primary Palette
    sunriseCoral: '#FF6B4A',
    sunriseCoralLight: '#FF8A70',
    sunriseCoralDark: '#E55A3A',
    
    goldenHour: '#FFBE4F',
    goldenHourLight: '#FFD080',
    goldenHourDark: '#E5A030',
    
    // Coffee Essence
    espressoDark: '#3D2317',
    coffeeMedium: '#6B4423',
    coffeeLight: '#8B6344',
    mochaCream: '#C4A484',
    
    // Surfaces
    latteCream: '#FFF5E6',
    latteCreamWarm: '#FFF0D9',
    ceramicWhite: '#FDFCF9',
    paperAged: '#F9F3E8',
    
    // Accent
    mintFresh: '#B8E6D4',
    mintDeep: '#7ECDB0',
    tealRetro: '#4ECDC4',
    
    // Semantic
    success: '#7CB342',
    error: '#E53935',
    warning: '#FFC107',
    info: '#4ECDC4',
    
    // Decorative
    tilePattern1: '#FFE4CC',
    tilePattern2: '#FFD4B8',
  },
  
  spacing: {
    space0: '0px',
    space1: '0.25rem',    // 4px
    space2: '0.5rem',     // 8px
    space3: '0.75rem',    // 12px
    space4: '1rem',       // 16px
    space5: '1.25rem',    // 20px
    space6: '1.5rem',     // 24px
    space8: '2rem',       // 32px
    space10: '2.5rem',    // 40px
    space12: '3rem',      // 48px
    space16: '4rem',      // 64px
    space20: '5rem',      // 80px
    space24: '6rem',      // 96px
    space32: '8rem',      // 128px
    space40: '10rem',     // 160px
    space48: '12rem',     // 192px
    space56: '14rem',     // 224px
    space64: '16rem',     // 256px
  },
  
  radii: {
    xs: '0.25rem',   // 4px
    sm: '0.5rem',    // 8px
    md: '1rem',      // 16px
    lg: '1.5rem',    // 24px
    xl: '2rem',      // 32px
    '2xl': '3rem',   // 48px
    full: '9999px',
  },
  
  fonts: {
    display: "'Righteous', cursive",
    body: "'Nunito', -apple-system, BlinkMacSystemFont, sans-serif",
    mono: "'JetBrains Mono', monospace",
  },
  
  fontSizes: {
    xs: 'clamp(0.75rem, 0.7rem + 0.25vw, 0.8125rem)',
    sm: 'clamp(0.8125rem, 0.77rem + 0.21vw, 0.9375rem)',
    base: 'clamp(0.9375rem, 0.89rem + 0.25vw, 1.0625rem)',
    lg: 'clamp(1.0625rem, 1rem + 0.31vw, 1.25rem)',
    xl: 'clamp(1.25rem, 1.16rem + 0.45vw, 1.5rem)',
    '2xl': 'clamp(1.5rem, 1.36rem + 0.71vw, 1.875rem)',
    '3xl': 'clamp(1.875rem, 1.65rem + 1.12vw, 2.5rem)',
    '4xl': 'clamp(2.5rem, 2.1rem + 2vw, 3.5rem)',
    '5xl': 'clamp(3rem, 2.5rem + 2.5vw, 4.5rem)',
  },
  
  lineHeights: {
    none: '1',
    tight: '1.25',
    snug: '1.375',
    normal: '1.5',
    relaxed: '1.625',
    loose: '2',
  },
  
  shadows: {
    sm: '0 1px 2px 0 rgba(61, 35, 23, 0.05)',
    md: '0 4px 6px -1px rgba(61, 35, 23, 0.1), 0 2px 4px -1px rgba(61, 35, 23, 0.06)',
    lg: '0 10px 15px -3px rgba(61, 35, 23, 0.1), 0 4px 6px -2px rgba(61, 35, 23, 0.05)',
    xl: '0 20px 25px -5px rgba(61, 35, 23, 0.1), 0 10px 10px -5px rgba(61, 35, 23, 0.04)',
    '2xl': '0 25px 50px -12px rgba(61, 35, 23, 0.25)',
    glow: '0 0 40px rgba(255, 107, 74, 0.2)',
  },
  
  animations: {
    easeBounce: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    easeSmooth: 'cubic-bezier(0.23, 1, 0.32, 1)',
    easeStandard: 'cubic-bezier(0.4, 0, 0.2, 1)',
    easeAccelerate: 'cubic-bezier(0.4, 0, 1, 1)',
    easeDecelerate: 'cubic-bezier(0, 0, 0.2, 1)',
    durationFast: '150ms',
    durationNormal: '300ms',
    durationSlow: '500ms',
    durationSlower: '700ms',
  },
  
  zIndex: {
    dropdown: 1000,
    sticky: 1020,
    fixed: 1030,
    modalBackdrop: 1040,
    modal: 1050,
    popover: 1060,
    tooltip: 1070,
  },
  
  breakpoints: {
    sm: '640px',
    md: '768px',
    lg: '1024px',
    xl: '1280px',
    '2xl': '1536px',
  },
} as const;

export type DesignTokens = typeof designTokens;
export type ColorName = keyof typeof designTokens.colors;
export type SpaceName = keyof typeof designTokens.spacing;
export type RadiusName = keyof typeof designTokens.radii;
export type ShadowName = keyof typeof designTokens.shadows;