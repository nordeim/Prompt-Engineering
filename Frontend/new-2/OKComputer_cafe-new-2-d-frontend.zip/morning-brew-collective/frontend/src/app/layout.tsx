import type { Metadata } from 'next';
import { Nunito, Righteous } from 'next/font/google';
import './globals.css';
import { ThemeProvider } from '@/components/ui/theme-provider';
import { SkipLink } from '@/components/ui/skip-link';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';

const nunito = Nunito({
  subsets: ['latin'],
  variable: '--font-nunito',
  display: 'swap',
});

const righteous = Righteous({
  subsets: ['latin'],
  variable: '--font-righteous',
  weight: '400',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Morning Brew Collective',
  description: 'Singapore\'s finest kopitiam experience - heritage coffee and traditional breakfast with modern convenience.',
  keywords: 'kopitiam, coffee, singapore, breakfast, traditional, heritage',
  authors: [{ name: 'Morning Brew Collective' }],
  creator: 'Morning Brew Collective',
  publisher: 'Morning Brew Collective',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'),
  openGraph: {
    title: 'Morning Brew Collective',
    description: 'Singapore\'s finest kopitiam experience - heritage coffee and traditional breakfast with modern convenience.',
    url: '/',
    siteName: 'Morning Brew Collective',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Morning Brew Collective',
      },
    ],
    locale: 'en_SG',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Morning Brew Collective',
    description: 'Singapore\'s finest kopitiam experience - heritage coffee and traditional breakfast with modern convenience.',
    images: ['/twitter-image.jpg'],
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  manifest: '/site.webmanifest',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en-SG" className={`${nunito.variable} ${righteous.variable}`}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;500;600;700&family=Righteous&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>
        <ThemeProvider>
          <SkipLink />
          <div className="min-h-screen flex flex-col">
            <Header />
            <main className="flex-grow" role="main">
              {children}
            </main>
            <Footer />
          </div>
        </ThemeProvider>
      </body>
    </html>
  );
}