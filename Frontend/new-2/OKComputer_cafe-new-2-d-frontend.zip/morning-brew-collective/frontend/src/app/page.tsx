import { HeroSection } from '@/components/sections/hero';
import { MenuSection } from '@/components/sections/menu';
import { HeritageSection } from '@/components/sections/heritage';
import { LocationsSection } from '@/components/sections/locations';

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <MenuSection />
      <HeritageSection />
      <LocationsSection />
    </>
  );
}