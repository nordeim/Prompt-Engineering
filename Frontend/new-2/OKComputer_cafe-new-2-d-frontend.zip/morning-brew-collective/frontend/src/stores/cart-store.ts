import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { apiClient } from '@/api/client';

export interface CartItem {
  id: string;
  name: string;
  price: number; // in dollars with 4 decimal precision
  quantity: number;
  category: string;
  imageUrl?: string;
  reservationId?: string; // Phase 1 soft reservation
}

interface CartState {
  items: CartItem[];
  reservations: Map<string, string>; // productId → reservationId
  
  // Core actions
  addItem: (item: Omit<CartItem, 'quantity'>) => Promise<void>;
  removeItem: (id: string) => Promise<void>;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  
  // Inventory reservation
  reserveInventory: (productId: string, quantity: number) => Promise<string>;
  releaseInventory: (reservationId: string) => Promise<void>;
  
  // Calculations
  getItemCount: () => number;
  getSubtotal: () => number;
  getGST: () => number; // 9% of subtotal
  getTotal: () => number; // subtotal + GST
  
  // Utilities
  formatPrice: (amount: number) => string; // $X.XX format
  
  // Persistence
  clearPersistedData: () => void;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      reservations: new Map(),

      addItem: async (item) => {
        const existingItem = get().items.find(i => i.id === item.id);
        
        if (existingItem) {
          // Update quantity if item already exists
          get().updateQuantity(item.id, existingItem.quantity + 1);
          return;
        }

        // Reserve inventory first
        let reservationId: string | undefined;
        try {
          reservationId = await get().reserveInventory(item.id, 1);
        } catch (error) {
          console.error('Failed to reserve inventory:', error);
          throw new Error('Item is currently out of stock');
        }

        set((state) => ({
          items: [...state.items, { ...item, quantity: 1, reservationId }],
          reservations: new Map(state.reservations).set(item.id, reservationId!),
        }));
      },

      removeItem: async (id) => {
        const item = get().items.find(i => i.id === id);
        if (!item) return;

        // Release inventory reservation
        if (item.reservationId) {
          try {
            await get().releaseInventory(item.reservationId);
          } catch (error) {
            console.error('Failed to release inventory:', error);
          }
        }

        set((state) => ({
          items: state.items.filter(i => i.id !== id),
          reservations: (() => {
            const newReservations = new Map(state.reservations);
            newReservations.delete(id);
            return newReservations;
          })(),
        }));
      },

      updateQuantity: (id, quantity) => {
        if (quantity <= 0) {
          get().removeItem(id);
          return;
        }

        set((state) => ({
          items: state.items.map(item =>
            item.id === id ? { ...item, quantity } : item
          ),
        }));
      },

      clearCart: () => {
        // Release all reservations
        const { items } = get();
        items.forEach(async (item) => {
          if (item.reservationId) {
            try {
              await get().releaseInventory(item.reservationId);
            } catch (error) {
              console.error('Failed to release inventory:', error);
            }
          }
        });

        set({ items: [], reservations: new Map() });
      },

      reserveInventory: async (productId, quantity) => {
        try {
          const response = await fetch('/api/inventory/reserve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ productId, quantity }),
          });

          if (!response.ok) {
            throw new Error('Failed to reserve inventory');
          }

          const data = await response.json();
          return data.reservationId;
        } catch (error) {
          console.error('Inventory reservation failed:', error);
          throw error;
        }
      },

      releaseInventory: async (reservationId) => {
        try {
          const response = await fetch('/api/inventory/release', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ reservationId }),
          });

          if (!response.ok) {
            throw new Error('Failed to release inventory');
          }
        } catch (error) {
          console.error('Inventory release failed:', error);
          throw error;
        }
      },

      getItemCount: () => {
        return get().items.reduce((sum, item) => sum + item.quantity, 0);
      },

      getSubtotal: () => {
        return get().items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
      },

      getGST: () => {
        return get().getSubtotal() * 0.09; // 9% GST
      },

      getTotal: () => {
        return get().getSubtotal() + get().getGST();
      },

      formatPrice: (amount) => {
        return new Intl.NumberFormat('en-SG', {
          style: 'currency',
          currency: 'SGD',
        }).format(amount);
      },

      clearPersistedData: () => {
        localStorage.removeItem('cart-storage');
      },
    }),
    {
      name: 'cart-storage',
      version: 1,
      // Persist cart for 30 days (PDPA compliance)
      partialize: (state) => ({
        items: state.items.map(item => ({
          ...item,
          reservationId: undefined, // Don't persist reservation IDs
        })),
      }),
    }
  )
);