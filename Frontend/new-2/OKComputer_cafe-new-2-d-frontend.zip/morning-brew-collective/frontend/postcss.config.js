module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
    'postcss-nested': {},
    'autoprefixer': {},
  },
}