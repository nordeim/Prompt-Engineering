import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
    './src/styles/**/*.{css}',
  ],
  theme: {
    extend: {
      colors: {
        // Primary palette
        'sunrise-coral': 'rgb(var(--color-sunrise-coral) / <alpha-value>)',
        'sunrise-coral-light': 'rgb(var(--color-sunrise-coral-light) / <alpha-value>)',
        'sunrise-coral-dark': 'rgb(var(--color-sunrise-coral-dark) / <alpha-value>)',
        
        'golden-hour': 'rgb(var(--color-golden-hour) / <alpha-value>)',
        'golden-hour-light': 'rgb(var(--color-golden-hour-light) / <alpha-value>)',
        'golden-hour-dark': 'rgb(var(--color-golden-hour-dark) / <alpha-value>)',
        
        // Coffee essence
        'espresso-dark': 'rgb(var(--color-espresso-dark) / <alpha-value>)',
        'coffee-medium': 'rgb(var(--color-coffee-medium) / <alpha-value>)',
        'coffee-light': 'rgb(var(--color-coffee-light) / <alpha-value>)',
        'mocha-cream': 'rgb(var(--color-mocha-cream) / <alpha-value>)',
        
        // Surfaces
        'latte-cream': 'rgb(var(--color-latte-cream) / <alpha-value>)',
        'latte-cream-warm': 'rgb(var(--color-latte-cream-warm) / <alpha-value>)',
        'ceramic-white': 'rgb(var(--color-ceramic-white) / <alpha-value>)',
        'paper-aged': 'rgb(var(--color-paper-aged) / <alpha-value>)',
        
        // Accent
        'mint-fresh': 'rgb(var(--color-mint-fresh) / <alpha-value>)',
        'mint-deep': 'rgb(var(--color-mint-deep) / <alpha-value>)',
        'teal-retro': 'rgb(var(--color-teal-retro) / <alpha-value>)',
        
        // Semantic
        success: 'rgb(var(--color-success) / <alpha-value>)',
        error: 'rgb(var(--color-error) / <alpha-value>)',
        warning: 'rgb(var(--color-warning) / <alpha-value>)',
        info: 'rgb(var(--color-info) / <alpha-value>)',
      },
      
      spacing: {
        0: 'var(--space-0)',
        1: 'var(--space-1)',
        2: 'var(--space-2)',
        3: 'var(--space-3)',
        4: 'var(--space-4)',
        5: 'var(--space-5)',
        6: 'var(--space-6)',
        8: 'var(--space-8)',
        10: 'var(--space-10)',
        12: 'var(--space-12)',
        16: 'var(--space-16)',
        20: 'var(--space-20)',
        24: 'var(--space-24)',
        32: 'var(--space-32)',
        40: 'var(--space-40)',
        48: 'var(--space-48)',
        56: 'var(--space-56)',
        64: 'var(--space-64)',
      },
      
      borderRadius: {
        xs: 'var(--radius-xs)',
        sm: 'var(--radius-sm)',
        md: 'var(--radius-md)',
        lg: 'var(--radius-lg)',
        xl: 'var(--radius-xl)',
        '2xl': 'var(--radius-2xl)',
        full: 'var(--radius-full)',
      },
      
      boxShadow: {
        sm: 'var(--shadow-sm)',
        md: 'var(--shadow-md)',
        lg: 'var(--shadow-lg)',
        xl: 'var(--shadow-xl)',
        '2xl': 'var(--shadow-2xl)',
        glow: 'var(--shadow-glow)',
      },
      
      transitionTimingFunction: {
        bounce: 'var(--ease-bounce)',
        smooth: 'var(--ease-smooth)',
        standard: 'var(--ease-standard)',
        accelerate: 'var(--ease-accelerate)',
        decelerate: 'var(--ease-decelerate)',
      },
      
      transitionDuration: {
        fast: 'var(--duration-fast)',
        normal: 'var(--duration-normal)',
        slow: 'var(--duration-slow)',
        slower: 'var(--duration-slower)',
      },
      
      fontFamily: {
        display: 'var(--font-display)',
        body: 'var(--font-body)',
        mono: 'var(--font-mono)',
      },
      
      fontSize: {
        xs: 'var(--text-xs)',
        sm: 'var(--text-sm)',
        base: 'var(--text-base)',
        lg: 'var(--text-lg)',
        xl: 'var(--text-xl)',
        '2xl': 'var(--text-2xl)',
        '3xl': 'var(--text-3xl)',
        '4xl': 'var(--text-4xl)',
        '5xl': 'var(--text-5xl)',
      },
      
      lineHeight: {
        none: 'var(--leading-none)',
        tight: 'var(--leading-tight)',
        snug: 'var(--leading-snug)',
        normal: 'var(--leading-normal)',
        relaxed: 'var(--leading-relaxed)',
        loose: 'var(--leading-loose)',
      },
      
      letterSpacing: {
        tighter: 'var(--tracking-tighter)',
        tight: 'var(--tracking-tight)',
        normal: 'var(--tracking-normal)',
        wide: 'var(--tracking-wide)',
        wider: 'var(--tracking-wider)',
        widest: 'var(--tracking-widest)',
      },
      
      zIndex: {
        dropdown: 'var(--z-dropdown)',
        sticky: 'var(--z-sticky)',
        fixed: 'var(--z-fixed)',
        modalBackdrop: 'var(--z-modal-backdrop)',
        modal: 'var(--z-modal)',
        popover: 'var(--z-popover)',
        tooltip: 'var(--z-tooltip)',
      },
      
      screens: {
        sm: 'var(--breakpoint-sm)',
        md: 'var(--breakpoint-md)',
        lg: 'var(--breakpoint-lg)',
        xl: 'var(--breakpoint-xl)',
        '2xl': 'var(--breakpoint-2xl)',
      },
      
      container: {
        sm: 'var(--container-sm)',
        md: 'var(--container-md)',
        lg: 'var(--container-lg)',
        xl: 'var(--container-xl)',
        '2xl': 'var(--container-2xl)',
      },
      
      animation: {
        'sunburst-rotate': 'sunburst-rotate 20s linear infinite',
        'wave-move': 'wave-move 10s linear infinite',
        'badge-float': 'badge-float 3s ease-in-out infinite',
        'steam-rise': 'steam-rise 2s ease-out infinite',
      },
    },
  },
  plugins: [],
};

export default config;