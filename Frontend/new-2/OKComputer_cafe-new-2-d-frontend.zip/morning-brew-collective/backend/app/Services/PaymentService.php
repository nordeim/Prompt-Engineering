<?php

namespace App\Services;

use App\Models\Order;
use Stripe\Stripe;
use Stripe\PaymentIntent;
use Stripe\PaymentLink;

class PaymentService
{
    public function __construct()
    {
        Stripe::setApiKey(config('services.stripe.secret'));
    }

    /**
     * Create PayNow payment for an order.
     */
    public function createPayNowPayment(Order $order): PaymentResult
    {
        // Create payment intent with PayNow
        $paymentIntent = PaymentIntent::create([
            'amount' => $order->total_decimal * 100, // Convert to cents
            'currency' => 'sgd',
            'payment_method_types' => ['paynow'],
            'description' => "Order {$order->invoice_number} - Morning Brew Collective",
            'metadata' => [
                'order_id' => $order->id,
                'invoice_number' => $order->invoice_number,
                'customer_email' => $order->customer_email,
                'customer_name' => $order->customer_name,
            ],
        ]);

        // Update order with payment intent
        $order->payment_intent_id = $paymentIntent->id;
        $order->payment_status = 'processing';
        $order->save();

        return new PaymentResult(
            paymentIntentId: $paymentIntent->id,
            clientSecret: $paymentIntent->client_secret,
            paymentUrl: $paymentIntent->next_action?->paynow_display_qr_code?->data ?? null
        );
    }

    /**
     * Create payment link for PayNow (alternative approach).
     */
    public function createPayNowPaymentLink(Order $order): PaymentLinkResult
    {
        $paymentLink = PaymentLink::create([
            'line_items' => [
                [
                    'price_data' => [
                        'currency' => 'sgd',
                        'product_data' => [
                            'name' => "Order {$order->invoice_number}",
                            'description' => 'Morning Brew Collective Order',
                        ],
                        'unit_amount' => $order->total_decimal * 100,
                    ],
                    'quantity' => 1,
                ],
            ],
            'payment_method_types' => ['paynow'],
            'metadata' => [
                'order_id' => $order->id,
                'invoice_number' => $order->invoice_number,
            ],
        ]);

        return new PaymentLinkResult(
            paymentLinkId: $paymentLink->id,
            paymentUrl: $paymentLink->url
        );
    }

    /**
     * Confirm payment intent.
     */
    public function confirmPayment(string $paymentIntentId): bool
    {
        try {
            $paymentIntent = PaymentIntent::retrieve($paymentIntentId);
            
            if ($paymentIntent->status === 'succeeded') {
                return true;
            }

            return false;
        } catch (\Exception $e) {
            \Log::error('Payment confirmation failed', [
                'payment_intent_id' => $paymentIntentId,
                'error' => $e->getMessage(),
            ]);
            return false;
        }
    }

    /**
     * Handle webhook events.
     */
    public function handleWebhook(array $payload): void
    {
        $event = $payload['type'];
        $data = $payload['data']['object'];

        switch ($event) {
            case 'payment_intent.succeeded':
                $this->handlePaymentSuccess($data);
                break;
            
            case 'payment_intent.payment_failed':
                $this->handlePaymentFailed($data);
                break;
                
            case 'payment_intent.canceled':
                $this->handlePaymentCancelled($data);
                break;
        }
    }

    /**
     * Handle successful payment.
     */
    private function handlePaymentSuccess(array $data): void
    {
        $order = Order::where('payment_intent_id', $data['id'])->first();
        
        if (!$order) {
            \Log::warning('Order not found for payment success', ['payment_intent_id' => $data['id']]);
            return;
        }

        $order->payment_status = 'completed';
        $order->status = Order::STATUS_CONFIRMED;
        $order->save();

        // Commit inventory reservations
        foreach ($order->items as $item) {
            if ($item->reservation_id) {
                app(\App\Services\InventoryService::class)->commit($item->reservation_id);
            }
        }

        // Send confirmation email
        \App\Jobs\SendOrderConfirmation::dispatch($order);
    }

    /**
     * Handle failed payment.
     */
    private function handlePaymentFailed(array $data): void
    {
        $order = Order::where('payment_intent_id', $data['id'])->first();
        
        if (!$order) {
            return;
        }

        $order->payment_status = 'failed';
        $order->status = Order::STATUS_FAILED;
        $order->save();

        // Release inventory reservations
        foreach ($order->items as $item) {
            if ($item->reservation_id) {
                app(\App\Services\InventoryService::class)->release($item->reservation_id);
            }
        }
    }

    /**
     * Handle cancelled payment.
     */
    private function handlePaymentCancelled(array $data): void
    {
        $order = Order::where('payment_intent_id', $data['id'])->first();
        
        if (!$order) {
            return;
        }

        $order->payment_status = 'failed';
        $order->status = Order::STATUS_CANCELLED;
        $order->save();

        // Release inventory reservations
        foreach ($order->items as $item) {
            if ($item->reservation_id) {
                app(\App\Services\InventoryService::class)->release($item->reservation_id);
            }
        }
    }
}

class PaymentResult
{
    public function __construct(
        public string $paymentIntentId,
        public string $clientSecret,
        public ?string $paymentUrl
    ) {}
}

class PaymentLinkResult
{
    public function __construct(
        public string $paymentLinkId,
        public string $paymentUrl
    ) {}
}