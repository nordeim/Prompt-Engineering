<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;
use Ramsey\Uuid\Uuid;

class InventoryService
{
    private const RESERVATION_TTL = 900; // 15 minutes

    /**
     * Reserve inventory for a product.
     */
    public function reserve(string $productId, int $quantity): ReservationResult
    {
        return DB::transaction(function () use ($productId, $quantity) {
            // 1. Pessimistic lock in PostgreSQL
            $product = Product::where('id', $productId)
                ->lockForUpdate()
                ->first();

            if (!$product) {
                throw new \Exception("Product not found");
            }

            if ($product->available_stock < $quantity) {
                throw new \Exception("Insufficient stock for product: {$product->name}");
            }

            // 2. Update PostgreSQL (source of truth)
            $product->decreaseStock($quantity);

            // 3. Create Redis reservation
            $reservationId = Uuid::uuid4()->toString();
            $expiresAt = now()->addSeconds(self::RESERVATION_TTL);

            Redis::setex(
                "reservation:{$reservationId}",
                self::RESERVATION_TTL,
                json_encode([
                    'product_id' => $productId,
                    'quantity' => $quantity,
                    'created_at' => now()->toIso8601String(),
                    'expires_at' => $expiresAt->toIso8601String(),
                ])
            );

            // 4. Schedule automatic rollback
            $this->scheduleRollback($reservationId, $expiresAt);

            return new ReservationResult($reservationId, $expiresAt);
        });
    }

    /**
     * Release a reservation.
     */
    public function release(string $reservationId): void
    {
        $reservationData = Redis::get("reservation:{$reservationId}");

        if (!$reservationData) {
            return; // Reservation already expired or doesn't exist
        }

        $reservation = json_decode($reservationData, true);

        DB::transaction(function () use ($reservation, $reservationId) {
            // Restore stock
            $product = Product::find($reservation['product_id']);
            if ($product) {
                $product->increaseStock($reservation['quantity']);
            }

            // Delete reservation
            Redis::del("reservation:{$reservationId}");
        });
    }

    /**
     * Commit a reservation (convert to hard allocation).
     */
    public function commit(string $reservationId): void
    {
        // Just delete the reservation key - stock is already decremented
        Redis::del("reservation:{$reservationId}");
    }

    /**
     * Schedule automatic rollback.
     */
    private function scheduleRollback(string $reservationId, \Carbon\Carbon $expiresAt): void
    {
        // Redis keyspace notifications will handle this
        // Additionally, we can schedule a Laravel job as a fallback
        \App\Jobs\ReleaseExpiredReservation::dispatch($reservationId)
            ->delay($expiresAt);
    }

    /**
     * Get reservation details.
     */
    public function getReservation(string $reservationId): ?array
    {
        $data = Redis::get("reservation:{$reservationId}");
        
        if (!$data) {
            return null;
        }

        return json_decode($data, true);
    }

    /**
     * Check if reservation exists and is valid.
     */
    public function isReservationValid(string $reservationId): bool
    {
        return Redis::exists("reservation:{$reservationId}") > 0;
    }
}

class ReservationResult
{
    public function __construct(
        public string $reservationId,
        public \Carbon\Carbon $expiresAt
    ) {}
}