<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Order extends Model
{
    use HasFactory;

    /**
     * Order status constants.
     */
    const STATUS_PENDING = 'pending';
    const STATUS_CONFIRMED = 'confirmed';
    const STATUS_PREPARING = 'preparing';
    const STATUS_READY = 'ready';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_FAILED = 'failed';

    /**
     * Payment method constants.
     */
    const PAYMENT_METHOD_PAYNOW = 'paynow';
    const PAYMENT_METHOD_CREDIT_CARD = 'credit_card';
    const PAYMENT_METHOD_CASH = 'cash';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'invoice_number',
        'customer_name',
        'customer_email',
        'customer_phone',
        'customer_pseudonym',
        'pickup_location_id',
        'pickup_datetime',
        'subtotal_decimal',
        'gst_decimal',
        'total_decimal',
        'status',
        'payment_method',
        'payment_intent_id',
        'payment_status',
        'special_instructions',
        'consent_marketing',
        'consent_version',
        'ip_address',
        'user_agent',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'pickup_datetime' => 'datetime',
        'subtotal_decimal' => 'decimal:4',
        'gst_decimal' => 'decimal:4',
        'total_decimal' => 'decimal:4',
        'consent_marketing' => 'boolean',
    ];

    /**
     * Get the order items.
     */
    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Get the pickup location.
     */
    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'pickup_location_id');
    }

    /**
     * Calculate order totals.
     */
    public function calculateTotals(): void
    {
        $subtotal = $this->items->sum(function ($item) {
            return $item->price_decimal * $item->quantity;
        });

        // GST is 9% of subtotal
        $gst = $subtotal * 0.09;
        $total = $subtotal + $gst;

        $this->subtotal_decimal = $subtotal;
        $this->gst_decimal = $gst;
        $this->total_decimal = $total;
    }

    /**
     * Generate invoice number.
     */
    public static function generateInvoiceNumber(): string
    {
        $date = now()->format('Ymd');
        $lastOrder = self::whereDate('created_at', today())->latest()->first();
        
        if ($lastOrder) {
            $sequence = (int) substr($lastOrder->invoice_number, -4) + 1;
        } else {
            $sequence = 1;
        }

        return 'MBC' . $date . str_pad($sequence, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Get formatted subtotal.
     */
    public function getSubtotalFormattedAttribute(): string
    {
        return 'S$' . number_format($this->subtotal_decimal, 2);
    }

    /**
     * Get formatted GST.
     */
    public function getGstFormattedAttribute(): string
    {
        return 'S$' . number_format($this->gst_decimal, 2);
    }

    /**
     * Get formatted total.
     */
    public function getTotalFormattedAttribute(): string
    {
        return 'S$' . number_format($this->total_decimal, 2);
    }

    /**
     * Check if order is payable.
     */
    public function isPayable(): bool
    {
        return in_array($this->status, [
            self::STATUS_PENDING,
            self::STATUS_FAILED,
        ]);
    }

    /**
     * Check if order can be cancelled.
     */
    public function canBeCancelled(): bool
    {
        return in_array($this->status, [
            self::STATUS_PENDING,
            self::STATUS_CONFIRMED,
            self::STATUS_PREPARING,
        ]);
    }

    /**
     * Scope a query by status.
     */
    public function scopeByStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    /**
     * Scope a query by payment method.
     */
    public function scopeByPaymentMethod($query, string $method)
    {
        return $query->where('payment_method', $method);
    }

    /**
     * Scope a query for today.
     */
    public function scopeToday($query)
    {
        return $query->whereDate('created_at', today());
    }
}