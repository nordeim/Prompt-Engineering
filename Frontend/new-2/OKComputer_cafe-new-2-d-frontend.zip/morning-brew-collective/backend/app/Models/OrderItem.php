<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class OrderItem extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'order_id',
        'product_id',
        'product_name',
        'product_sku',
        'price_decimal',
        'quantity',
        'category',
        'reservation_id',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'price_decimal' => 'decimal:4',
        'quantity' => 'integer',
    ];

    /**
     * Get the order that owns the item.
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Get the product.
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Get formatted price.
     */
    public function getPriceFormattedAttribute(): string
    {
        return 'S$' . number_format($this->price_decimal, 2);
    }

    /**
     * Get total price for this item.
     */
    public function getTotalDecimalAttribute(): float
    {
        return $this->price_decimal * $this->quantity;
    }

    /**
     * Get formatted total price.
     */
    public function getTotalFormattedAttribute(): string
    {
        return 'S$' . number_format($this->total_decimal, 2);
    }
}