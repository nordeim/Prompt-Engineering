<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Product extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'description',
        'price_decimal', // Stored as DECIMAL(10,4) for precision
        'category',
        'tags',
        'is_active',
        'image_url',
        'available_stock',
        'sku',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'price_decimal' => 'decimal:4',
        'tags' => 'array',
        'is_active' => 'boolean',
        'available_stock' => 'integer',
    ];

    /**
     * Get the price as a formatted string.
     */
    public function getPriceFormattedAttribute(): string
    {
        return 'S$' . number_format($this->price_decimal, 2);
    }

    /**
     * Get the price in cents (for Stripe).
     */
    public function getPriceInCentsAttribute(): int
    {
        return (int) ($this->price_decimal * 100);
    }

    /**
     * Scope a query to only include active products.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Scope a query to only include products in stock.
     */
    public function scopeInStock($query)
    {
        return $query->where('available_stock', '>', 0);
    }

    /**
     * Scope a query by category.
     */
    public function scopeByCategory($query, string $category)
    {
        return $query->where('category', $category);
    }

    /**
     * Check if product has sufficient stock.
     */
    public function hasSufficientStock(int $quantity): bool
    {
        return $this->available_stock >= $quantity;
    }

    /**
     * Decrease available stock.
     */
    public function decreaseStock(int $quantity): void
    {
        $this->decrement('available_stock', $quantity);
    }

    /**
     * Increase available stock.
     */
    public function increaseStock(int $quantity): void
    {
        $this->increment('available_stock', $quantity);
    }
}