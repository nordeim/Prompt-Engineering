<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Location extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'badge',
        'address',
        'postal_code',
        'phone',
        'email',
        'hours',
        'features',
        'image_url',
        'latitude',
        'longitude',
        'is_active',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'features' => 'array',
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'is_active' => 'boolean',
    ];

    /**
     * Scope a query to only include active locations.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Get formatted hours attribute.
     */
    public function getFormattedHoursAttribute(): array
    {
        return is_array($this->hours) ? $this->hours : json_decode($this->hours, true) ?? [];
    }

    /**
     * Check if location is open at a specific time.
     */
    public function isOpenAt(\Carbon\Carbon $time): bool
    {
        $day = strtolower($time->format('l')); // monday, tuesday, etc.
        $hours = $this->formatted_hours;

        if (!isset($hours[$day]) || $hours[$day]['closed']) {
            return false;
        }

        $currentTime = $time->format('H:i');
        $open = $hours[$day]['open'];
        $close = $hours[$day]['close'];

        return $currentTime >= $open && $currentTime <= $close;
    }

    /**
     * Get today's hours.
     */
    public function getTodaysHoursAttribute(): ?array
    {
        $today = strtolower(now()->format('l'));
        $hours = $this->formatted_hours;

        return $hours[$today] ?? null;
    }

    /**
     * Get full address.
     */
    public function getFullAddressAttribute(): string
    {
        return $this->address . ', Singapore ' . $this->postal_code;
    }
}