<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Services\InventoryService;
use App\Services\PaymentService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class OrderController extends Controller
{
    public function __construct(
        private InventoryService $inventoryService,
        private PaymentService $paymentService
    ) {}

    /**
     * Display a listing of the orders.
     */
    public function index(Request $request): JsonResponse
    {
        $query = Order::with(['items', 'location']);

        // Filter by status
        if ($request->has('status')) {
            $query->byStatus($request->string('status'));
        }

        // Filter by email
        if ($request->has('email')) {
            $query->where('customer_email', $request->string('email'));
        }

        // Date range
        if ($request->has('from_date')) {
            $query->whereDate('created_at', '>=', $request->date('from_date'));
        }

        if ($request->has('to_date')) {
            $query->whereDate('created_at', '<=', $request->date('to_date'));
        }

        $orders = $query->latest()->paginate($request->integer('per_page', 20));

        return response()->json([
            'data' => $orders->map(function ($order) {
                return [
                    'id' => $order->id,
                    'invoice_number' => $order->invoice_number,
                    'customer_name' => $order->customer_name,
                    'customer_email' => $order->customer_email,
                    'customer_phone' => $order->customer_phone,
                    'pickup_location' => $order->location?->name,
                    'pickup_datetime' => $order->pickup_datetime?->toIso8601String(),
                    'subtotal' => (float) $order->subtotal_decimal,
                    'gst' => (float) $order->gst_decimal,
                    'total' => (float) $order->total_decimal,
                    'status' => $order->status,
                    'payment_method' => $order->payment_method,
                    'payment_status' => $order->payment_status,
                    'items' => $order->items->map(function ($item) {
                        return [
                            'product_name' => $item->product_name,
                            'price' => (float) $item->price_decimal,
                            'quantity' => $item->quantity,
                            'total' => (float) $item->total_decimal,
                        ];
                    }),
                    'created_at' => $order->created_at->toIso8601String(),
                ];
            }),
            'meta' => [
                'current_page' => $orders->currentPage(),
                'last_page' => $orders->lastPage(),
                'per_page' => $orders->perPage(),
                'total' => $orders->total(),
            ],
        ]);
    }

    /**
     * Store a newly created order.
     */
    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'customer_name' => ['required', 'string', 'max:255'],
            'customer_email' => ['required', 'email', 'max:255'],
            'customer_phone' => ['required', 'string', 'max:20'],
            'pickup_location_id' => ['required', 'exists:locations,id'],
            'pickup_datetime' => ['required', 'date', 'after:now'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'exists:products,id'],
            'items.*.quantity' => ['required', 'integer', 'min:1'],
            'payment_method' => ['required', Rule::in(['paynow', 'credit_card', 'cash'])],
            'special_instructions' => ['nullable', 'string', 'max:500'],
            'consent_marketing' => ['boolean'],
        ]);

        return DB::transaction(function () use ($validated) {
            // Create order
            $order = new Order();
            $order->invoice_number = Order::generateInvoiceNumber();
            $order->fill($validated);
            
            // PDPA compliance: pseudonymize customer data
            $order->customer_pseudonym = hash('sha256', $validated['customer_email'] . config('app.pdpa_salt'));
            $order->consent_version = config('app.pdpa_consent_version');
            $order->ip_address = $request->ip();
            $order->user_agent = $request->userAgent();

            // Reserve inventory and create order items
            $reservations = [];
            foreach ($validated['items'] as $itemData) {
                $product = Product::findOrFail($itemData['product_id']);
                
                if (!$product->hasSufficientStock($itemData['quantity'])) {
                    throw new \Exception("Insufficient stock for product: {$product->name}");
                }

                // Reserve inventory
                $reservation = $this->inventoryService->reserve(
                    $product->id,
                    $itemData['quantity']
                );
                
                $reservations[] = $reservation->reservationId;
            }

            // Save order to get ID
            $order->save();

            // Create order items
            foreach ($validated['items'] as $index => $itemData) {
                $product = Product::findOrFail($itemData['product_id']);
                
                $orderItem = new OrderItem();
                $orderItem->order_id = $order->id;
                $orderItem->product_id = $product->id;
                $orderItem->product_name = $product->name;
                $orderItem->product_sku = $product->sku;
                $orderItem->price_decimal = $product->price_decimal;
                $orderItem->quantity = $itemData['quantity'];
                $orderItem->category = $product->category;
                $orderItem->reservation_id = $reservations[$index];
                $orderItem->save();
            }

            // Calculate totals
            $order->calculateTotals();
            $order->save();

            // Handle payment based on method
            if ($order->payment_method === 'paynow') {
                $paymentResult = $this->paymentService->createPayNowPayment($order);
                $order->payment_intent_id = $paymentResult->paymentIntentId;
                $order->save();
            }

            return response()->json([
                'invoice_number' => $order->invoice_number,
                'payment_intent_id' => $order->payment_intent_id,
                'payment_url' => $paymentResult->paymentUrl ?? null,
                'order' => [
                    'id' => $order->id,
                    'invoice_number' => $order->invoice_number,
                    'total' => (float) $order->total_decimal,
                    'total_formatted' => $order->total_formatted,
                    'status' => $order->status,
                    'payment_method' => $order->payment_method,
                ],
            ], 201);
        });
    }

    /**
     * Display the specified order.
     */
    public function show(Order $order): JsonResponse
    {
        return response()->json([
            'id' => $order->id,
            'invoice_number' => $order->invoice_number,
            'customer_name' => $order->customer_name,
            'customer_email' => $order->customer_email,
            'customer_phone' => $order->customer_phone,
            'pickup_location' => $order->location?->name,
            'pickup_location_address' => $order->location?->full_address,
            'pickup_datetime' => $order->pickup_datetime?->toIso8601String(),
            'subtotal' => (float) $order->subtotal_decimal,
            'gst' => (float) $order->gst_decimal,
            'total' => (float) $order->total_decimal,
            'subtotal_formatted' => $order->subtotal_formatted,
            'gst_formatted' => $order->gst_formatted,
            'total_formatted' => $order->total_formatted,
            'status' => $order->status,
            'payment_method' => $order->payment_method,
            'payment_status' => $order->payment_status,
            'special_instructions' => $order->special_instructions,
            'items' => $order->items->map(function ($item) {
                return [
                    'product_id' => $item->product_id,
                    'product_name' => $item->product_name,
                    'product_sku' => $item->product_sku,
                    'price' => (float) $item->price_decimal,
                    'price_formatted' => $item->price_formatted,
                    'quantity' => $item->quantity,
                    'category' => $item->category,
                    'total' => (float) $item->total_decimal,
                    'total_formatted' => $item->total_formatted,
                ];
            }),
            'created_at' => $order->created_at->toIso8601String(),
            'updated_at' => $order->updated_at->toIso8601String(),
        ]);
    }

    /**
     * Cancel an order.
     */
    public function cancel(Order $order): JsonResponse
    {
        if (!$order->canBeCancelled()) {
            return response()->json(['message' => 'Order cannot be cancelled'], 422);
        }

        DB::transaction(function () use ($order) {
            // Release inventory reservations
            foreach ($order->items as $item) {
                if ($item->reservation_id) {
                    $this->inventoryService->release($item->reservation_id);
                }
            }

            $order->status = Order::STATUS_CANCELLED;
            $order->save();
        });

        return response()->json(['message' => 'Order cancelled successfully']);
    }
}