<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Location;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class LocationController extends Controller
{
    /**
     * Display a listing of the locations.
     */
    public function index(Request $request): JsonResponse
    {
        $locations = Location::active()
            ->orderBy('name')
            ->get()
            ->map(function ($location) {
                return [
                    'id' => $location->id,
                    'name' => $location->name,
                    'badge' => $location->badge,
                    'address' => $location->address,
                    'postal_code' => $location->postal_code,
                    'phone' => $location->phone,
                    'email' => $location->email,
                    'hours' => $location->formatted_hours,
                    'todays_hours' => $location->todays_hours,
                    'features' => $location->features,
                    'image_url' => $location->image_url,
                    'latitude' => (float) $location->latitude,
                    'longitude' => (float) $location->longitude,
                    'full_address' => $location->full_address,
                    'is_open_now' => $location->isOpenAt(now()),
                ];
            });

        return response()->json(['data' => $locations]);
    }

    /**
     * Display the specified location.
     */
    public function show(Location $location): JsonResponse
    {
        if (!$location->is_active) {
            return response()->json(['message' => 'Location not found'], 404);
        }

        return response()->json([
            'id' => $location->id,
            'name' => $location->name,
            'badge' => $location->badge,
            'address' => $location->address,
            'postal_code' => $location->postal_code,
            'phone' => $location->phone,
            'email' => $location->email,
            'hours' => $location->formatted_hours,
            'todays_hours' => $location->todays_hours,
            'features' => $location->features,
            'image_url' => $location->image_url,
            'latitude' => (float) $location->latitude,
            'longitude' => (float) $location->longitude,
            'full_address' => $location->full_address,
            'is_open_now' => $location->isOpenAt(now()),
        ]);
    }

    /**
     * Get available pickup time slots for a location.
     */
    public function timeSlots(Location $location, Request $request): JsonResponse
    {
        $date = $request->date ? \Carbon\Carbon::parse($request->date) : now();
        
        // Get today's hours
        $today = strtolower($date->format('l'));
        $hours = $location->formatted_hours;

        if (!isset($hours[$today]) || $hours[$today]['closed']) {
            return response()->json(['data' => []]);
        }

        $open = \Carbon\Carbon::parse($date->format('Y-m-d') . ' ' . $hours[$today]['open']);
        $close = \Carbon\Carbon::parse($date->format('Y-m-d') . ' ' . $hours[$today]['close']);

        // Generate 30-minute time slots
        $slots = [];
        $current = $open->copy();

        while ($current < $close) {
            // Skip past times for today
            if ($date->isToday() && $current < now()) {
                $current->addMinutes(30);
                continue;
            }

            $slots[] = [
                'time' => $current->format('H:i'),
                'formatted' => $current->format('g:i A'),
                'available' => true, // You could add logic here to check capacity
            ];

            $current->addMinutes(30);
        }

        return response()->json(['data' => $slots]);
    }
}