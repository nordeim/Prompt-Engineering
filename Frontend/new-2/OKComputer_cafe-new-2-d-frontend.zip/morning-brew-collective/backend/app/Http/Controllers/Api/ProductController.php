<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ProductController extends Controller
{
    /**
     * Display a listing of the products.
     */
    public function index(Request $request): JsonResponse
    {
        $query = Product::active()->with(['category']);

        // Filter by category
        if ($request->has('category')) {
            $query->byCategory($request->string('category'));
        }

        // Filter by in stock only
        if ($request->boolean('in_stock')) {
            $query->inStock();
        }

        // Search by name or description
        if ($request->has('search')) {
            $search = $request->string('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'ilike', "%{$search}%")
                  ->orWhere('description', 'ilike', "%{$search}%");
            });
        }

        // Sorting
        $sortBy = $request->enum('sort_by', ['name', 'price', 'created_at']) ?? 'created_at';
        $sortDir = $request->enum('sort_dir', ['asc', 'desc']) ?? 'desc';
        $query->orderBy($sortBy, $sortDir);

        $products = $query->paginate($request->integer('per_page', 20));

        return response()->json([
            'data' => $products->map(function ($product) {
                return [
                    'id' => $product->id,
                    'sku' => $product->sku,
                    'name' => $product->name,
                    'description' => $product->description,
                    'price' => (float) $product->price_decimal,
                    'price_formatted' => $product->price_formatted,
                    'category' => $product->category,
                    'tags' => $product->tags,
                    'image_url' => $product->image_url,
                    'available_stock' => $product->available_stock,
                    'is_active' => $product->is_active,
                    'created_at' => $product->created_at->toIso8601String(),
                ];
            }),
            'meta' => [
                'current_page' => $products->currentPage(),
                'last_page' => $products->lastPage(),
                'per_page' => $products->perPage(),
                'total' => $products->total(),
                'from' => $products->firstItem(),
                'to' => $products->lastItem(),
            ],
        ]);
    }

    /**
     * Display the specified product.
     */
    public function show(Product $product): JsonResponse
    {
        if (!$product->is_active) {
            return response()->json(['message' => 'Product not found'], 404);
        }

        return response()->json([
            'id' => $product->id,
            'sku' => $product->sku,
            'name' => $product->name,
            'description' => $product->description,
            'price' => (float) $product->price_decimal,
            'price_formatted' => $product->price_formatted,
            'category' => $product->category,
            'tags' => $product->tags,
            'image_url' => $product->image_url,
            'available_stock' => $product->available_stock,
            'is_active' => $product->is_active,
            'created_at' => $product->created_at->toIso8601String(),
        ]);
    }

    /**
     * Get product categories.
     */
    public function categories(): JsonResponse
    {
        $categories = Product::active()
            ->select('category')
            ->distinct()
            ->orderBy('category')
            ->pluck('category');

        return response()->json(['data' => $categories]);
    }
}