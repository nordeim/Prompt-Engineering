<?php

namespace App\Jobs;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class SendOrderConfirmation implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     */
    public function __construct(
        private Order $order
    ) {}

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        // Send email confirmation
        Mail::to($this->order->customer_email)
            ->send(new \App\Mail\OrderConfirmation($this->order));

        // Send SMS if phone number is provided (implement SMS service as needed)
        if ($this->order->customer_phone) {
            // $this->sendSmsConfirmation($this->order);
        }
    }
}