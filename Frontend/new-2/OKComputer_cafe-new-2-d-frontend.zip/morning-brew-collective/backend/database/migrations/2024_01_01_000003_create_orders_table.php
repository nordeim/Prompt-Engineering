<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('invoice_number')->unique();
            $table->string('customer_name');
            $table->string('customer_email');
            $table->string('customer_phone');
            $table->string('customer_pseudonym'); // For PDPA compliance
            $table->foreignUuid('pickup_location_id')->constrained('locations');
            $table->dateTime('pickup_datetime');
            $table->decimal('subtotal_decimal', 10, 4);
            $table->decimal('gst_decimal', 10, 4);
            $table->decimal('total_decimal', 10, 4);
            $table->enum('status', [
                'pending',
                'confirmed',
                'preparing',
                'ready',
                'completed',
                'cancelled',
                'failed'
            ])->default('pending');
            $table->enum('payment_method', ['paynow', 'credit_card', 'cash']);
            $table->string('payment_intent_id')->nullable();
            $table->enum('payment_status', ['pending', 'processing', 'completed', 'failed'])->default('pending');
            $table->text('special_instructions')->nullable();
            $table->boolean('consent_marketing')->default(false);
            $table->string('consent_version');
            $table->ipAddress('ip_address');
            $table->text('user_agent')->nullable();
            $table->timestamps();
            
            $table->index('invoice_number');
            $table->index('status');
            $table->index('payment_method');
            $table->index('pickup_location_id');
            $table->index('customer_email');
            $table->index('created_at');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};