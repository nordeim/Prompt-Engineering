<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('order_items', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->foreignUuid('order_id')->constrained('orders')->onDelete('cascade');
            $table->foreignUuid('product_id')->constrained('products');
            $table->string('product_name');
            $table->string('product_sku');
            $table->decimal('price_decimal', 10, 4);
            $table->integer('quantity');
            $table->string('category');
            $table->string('reservation_id')->nullable(); // For inventory reservation
            $table->timestamps();
            
            $table->index('order_id');
            $table->index('product_id');
            $table->index('reservation_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('order_items');
    }
};