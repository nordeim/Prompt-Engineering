'use client'

import { useState } from 'react'
import { Plus, ShoppingCart } from 'lucide-react'
import { useCartStore } from '@/stores/cart-store'
import { formatPrice } from '@/lib/utils'
import { Button } from '@/components/ui/button'

interface MenuItem {
  id: string
  name: string
  description: string
  price: number
  category: 'coffee' | 'tea' | 'food'
  tags: string[]
  icon: string
}

const menuItems: MenuItem[] = [
  {
    id: 'traditional-kopi',
    name: 'Traditional Kopi',
    description: 'Strong coffee brewed with margarine and sugar, served with evaporated milk — the authentic Singaporean way.',
    price: 3.50,
    category: 'coffee',
    tags: ['House Specialty', 'Bold'],
    icon: '☕',
  },
  {
    id: 'kopi-c',
    name: 'Kopi-C',
    description: 'Coffee with evaporated milk and sugar. Creamy, sweet, and perfectly balanced for your morning ritual.',
    price: 3.20,
    category: 'coffee',
    tags: ['Best Seller', 'Creamy'],
    icon: '☕',
  },
  {
    id: 'kopi-o',
    name: 'Kopi-O',
    description: 'Strong black coffee with sugar. Bold, intense, and unapologetically Singaporean. For the purists.',
    price: 3.00,
    category: 'coffee',
    tags: ['Authentic', 'Strong'],
    icon: '☕',
  },
  {
    id: 'teh-tarik',
    name: 'Teh Tarik',
    description: 'Pulled tea with condensed milk. Frothy, sweet, and theatrical — a true Malaysian-Singaporean classic.',
    price: 3.20,
    category: 'tea',
    tags: ['Theatrical', 'Sweet'],
    icon: '🍵',
  },
  {
    id: 'kaya-toast',
    name: 'Kaya Toast',
    description: 'Crispy toast spread with homemade kaya jam and a slab of butter. The perfect companion to kopi.',
    price: 4.50,
    category: 'food',
    tags: ['Classic', 'Homemade'],
    icon: '🍞',
  },
  {
    id: 'soft-boiled-eggs',
    name: 'Soft-Boiled Eggs',
    description: 'Perfectly timed soft-boiled eggs served with soy sauce and white pepper. Simple comfort food.',
    price: 3.80,
    category: 'food',
    tags: ['Comfort Food', 'Traditional'],
    icon: '🥚',
  },
]

const categories = [
  { id: 'all', name: 'All', icon: '🍽️' },
  { id: 'coffee', name: 'Coffee', icon: '☕' },
  { id: 'tea', name: 'Tea', icon: '🍵' },
  { id: 'food', name: 'Food', icon: '🍞' },
]

export default function MenuPage() {
  const [activeCategory, setActiveCategory] = useState('all')
  const { addItem, getItemCount } = useCartStore()

  const filteredItems = activeCategory === 'all' 
    ? menuItems 
    : menuItems.filter(item => item.category === activeCategory)

  const handleAddToCart = (item: MenuItem) => {
    addItem({
      id: item.id,
      name: item.name,
      price: item.price,
      category: item.category,
      imageUrl: item.icon,
    })
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-latte-cream to-latte-cream-warm">
      {/* Hero Section */}
      <section className="relative py-20 text-center">
        <div className="container">
          <h1 className="font-display text-5xl md:text-6xl text-espresso-dark mb-6">
            Our Signature Brews
          </h1>
          <p className="text-xl text-coffee-medium max-w-2xl mx-auto">
            Crafted with love using beans roasted in-house since 1973
          </p>
        </div>
      </section>

      {/* Category Filters */}
      <section className="py-8 sticky top-[72px] bg-latte-cream/95 backdrop-blur-sm z-40 border-b-2 border-golden-hour/20">
        <div className="container">
          <div className="flex flex-wrap justify-center gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`flex items-center gap-2 px-6 py-3 rounded-full font-display text-base transition-all duration-normal ease-bounce ${
                  activeCategory === category.id
                    ? 'bg-sunrise-coral text-white shadow-lg'
                    : 'bg-ceramic-white text-coffee-medium hover:bg-golden-hour-light hover:text-sunrise-coral'
                }`}
              >
                <span className="text-lg">{category.icon}</span>
                {category.name}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Menu Grid */}
      <section className="py-16">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item) => (
              <article
                key={item.id}
                className="menu-card bg-ceramic-white rounded-2xl overflow-hidden shadow-[0_8px_0_rgba(0,0,0,0.1),0_8px_32px_rgba(107,68,35,0.15)] transition-all duration-normal ease-smooth hover:-translate-y-2 hover:shadow-[0_12px_0_rgba(0,0,0,0.1),0_12px_40px_rgba(107,68,35,0.2)] hover:rotate-[-1deg]"
              >
                {/* Card Image */}
                <div className="menu-card-image h-40 bg-gradient-to-br from-latte-cream to-tile-pattern-1 flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-tile-pattern-2 opacity-30"></div>
                  <span className="menu-card-icon text-6xl relative z-1 filter drop-shadow-lg">
                    {item.icon}
                  </span>
                </div>

                {/* Card Body */}
                <div className="menu-card-body p-6">
                  <div className="menu-card-header flex justify-between items-start gap-4 mb-3">
                    <h3 className="menu-card-title font-display text-xl text-espresso-dark">
                      {item.name}
                    </h3>
                    <span className="menu-card-price font-display text-xl text-sunrise-coral whitespace-nowrap">
                      {formatPrice(item.price)}
                    </span>
                  </div>

                  <p className="menu-card-desc text-sm text-coffee-medium leading-relaxed mb-4">
                    {item.description}
                  </p>

                  <div className="menu-card-tags flex flex-wrap gap-2 mb-4">
                    {item.tags.map((tag) => (
                      <span
                        key={tag}
                        className="tag px-3 py-1 bg-golden-hour-light text-coffee-medium rounded-full text-xs font-bold uppercase tracking-wider"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <button
                    onClick={() => handleAddToCart(item)}
                    className="add-to-cart w-full px-6 py-3 bg-espresso-dark text-white rounded-lg font-display text-base flex items-center justify-center gap-2 transition-all duration-normal ease-bounce hover:bg-coffee-medium hover:scale-102"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    Add to Cart
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Cart Summary Banner */}
      {getItemCount() > 0 && (
        <div className="fixed bottom-6 right-6 bg-espresso-dark text-white px-6 py-4 rounded-xl shadow-lg z-50">
          <div className="flex items-center gap-3">
            <ShoppingCart className="w-5 h-5" />
            <span className="font-display">
              {getItemCount()} items in cart
            </span>
          </div>
        </div>
      )}
    </div>
  )
}