import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { SkipLink } from '@/components/ui/skip-link'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Morning Brew Collective — Where Every Morning Shines Since 1973',
  description: 'Singapore\'s beloved kopitiam since 1973. Experience authentic kopi, kaya toast, and the warmth of our heritage.',
  themeColor: '#FF6B4A',
  openGraph: {
    title: 'Morning Brew Collective',
    description: 'Where Every Morning Shines Since 1973',
    type: 'website',
    locale: 'en_SG',
    siteName: 'Morning Brew Collective',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Morning Brew Collective',
    description: 'Where Every Morning Shines Since 1973',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link
          href="https://fonts.googleapis.com/css2?family=Righteous&family=Nunito:wght@400;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className={inter.className}>
        <SkipLink />
        <Header />
        <main id="main">
          {children}
        </main>
        <Footer />
      </body>
    </html>
  )
}