'use client'

import { useState } from 'react'
import { useCartStore } from '@/stores/cart-store'
import { formatPrice } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Calendar } from '@/components/ui/calendar'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

interface CustomerData {
  name: string
  email: string
  phone: string
}

interface PickupData {
  locationId: string
  datetime: string
}

type CheckoutStep = 'customer' | 'pickup' | 'payment' | 'review'

export default function CheckoutPage() {
  const { items, getSubtotal, getGST, getTotal, clearCart } = useCartStore()
  const [step, setStep] = useState<CheckoutStep>('customer')
  const [customerData, setCustomerData] = useState<CustomerData | null>(null)
  const [pickupData, setPickupData] = useState<PickupData | null>(null)
  const [paymentMethod, setPaymentMethod] = useState<'paynow' | 'credit_card' | 'cash'>('paynow')

  const locations = [
    { id: 'chinatown', name: 'Chinatown Point' },
    { id: 'tampines', name: 'Tampines Hub' },
    { id: 'jurong', name: 'Jurong East' },
  ]

  const timeSlots = [
    '7:00 AM', '7:30 AM', '8:00 AM', '8:30 AM', '9:00 AM', '9:30 AM',
    '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM',
    '1:00 PM', '1:30 PM', '2:00 PM', '2:30 PM', '3:00 PM', '3:30 PM',
    '4:00 PM', '4:30 PM', '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM',
    '7:00 PM', '7:30 PM', '8:00 PM', '8:30 PM', '9:00 PM'
  ]

  const handlePlaceOrder = async () => {
    if (!customerData || !pickupData) return

    // TODO: Implement order placement logic
    console.log('Placing order:', {
      customerData,
      pickupData,
      paymentMethod,
      items,
      total: getTotal()
    })

    // For now, just show success and clear cart
    alert('Order placed successfully!')
    clearCart()
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-latte-cream flex items-center justify-center">
        <div className="text-center">
          <h1 className="font-display text-3xl text-espresso-dark mb-4">Your cart is empty</h1>
          <p className="text-coffee-medium mb-8">Add some items to your cart before checking out</p>
          <Button onClick={() => window.location.href = '/menu'}>
            Browse Menu
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-latte-cream py-12">
      <div className="container max-w-4xl">
        <h1 className="font-display text-4xl text-espresso-dark mb-8 text-center">
          Checkout
        </h1>

        {/* Progress Indicator */}
        <div className="flex justify-center mb-12">
          <div className="flex items-center space-x-4">
            {['Customer Info', 'Pickup Details', 'Payment', 'Review'].map((label, index) => {
              const stepIndex = ['customer', 'pickup', 'payment', 'review'].indexOf(step)
              const isActive = index <= stepIndex
              return (
                <div key={label} className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                      isActive ? 'bg-sunrise-coral text-white' : 'bg-mocha-cream text-coffee-medium'
                    }`}
                  >
                    {index + 1}
                  </div>
                  <span className={`ml-2 text-sm ${isActive ? 'text-espresso-dark' : 'text-coffee-medium'}`}>
                    {label}
                  </span>
                  {index < 3 && <div className={`ml-4 w-8 h-0.5 ${isActive ? 'bg-sunrise-coral' : 'bg-mocha-cream'}`} />}
                </div>
              )
            })}
          </div>
        </div>

        <div className="bg-ceramic-white rounded-2xl shadow-lg p-8">
          {/* Step 1: Customer Details */}
          {step === 'customer' && (
            <div className="space-y-6">
              <h2 className="font-display text-2xl text-espresso-dark mb-6">Customer Information</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    placeholder="Enter your full name"
                    className="mt-2"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    className="mt-2"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  placeholder="+65 9123 4567"
                  className="mt-2"
                />
              </div>

              <div className="flex justify-end mt-8">
                <Button
                  onClick={() => {
                    // TODO: Validate form
                    setStep('pickup')
                  }}
                  className="px-8 py-3"
                >
                  Next: Pickup Details
                </Button>
              </div>
            </div>
          )}

          {/* Step 2: Pickup Details */}
          {step === 'pickup' && (
            <div className="space-y-6">
              <h2 className="font-display text-2xl text-espresso-dark mb-6">Pickup Details</h2>
              
              <div>
                <Label>Pickup Location</Label>
                <Select>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select a location" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map((location) => (
                      <SelectItem key={location.id} value={location.id}>
                        {location.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Pickup Date</Label>
                <Input
                  type="date"
                  className="mt-2"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>

              <div>
                <Label>Pickup Time</Label>
                <Select>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select a time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    {timeSlots.map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={() => setStep('customer')}
                  className="px-8 py-3"
                >
                  Back
                </Button>
                <Button
                  onClick={() => setStep('payment')}
                  className="px-8 py-3"
                >
                  Next: Payment
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Payment Method */}
          {step === 'payment' && (
            <div className="space-y-6">
              <h2 className="font-display text-2xl text-espresso-dark mb-6">Payment Method</h2>
              
              <RadioGroup value={paymentMethod} onValueChange={(value) => setPaymentMethod(value as any)}>
                <div className="space-y-4">
                  <label className="flex items-center space-x-3 p-4 border-2 border-golden-hour rounded-lg cursor-pointer hover:bg-golden-hour-light transition-colors">
                    <RadioGroupItem value="paynow" />
                    <div className="flex-1">
                      <div className="font-display text-espresso-dark">PayNow (Recommended)</div>
                      <div className="text-sm text-coffee-medium">Scan QR code with your banking app</div>
                    </div>
                    <div className="text-2xl">📱</div>
                  </label>
                  
                  <label className="flex items-center space-x-3 p-4 border-2 border-mocha-cream rounded-lg cursor-pointer hover:bg-mocha-cream/20 transition-colors">
                    <RadioGroupItem value="credit_card" />
                    <div className="flex-1">
                      <div className="font-display text-espresso-dark">Credit/Debit Card</div>
                      <div className="text-sm text-coffee-medium">Visa, Mastercard, AMEX</div>
                    </div>
                    <div className="text-2xl">💳</div>
                  </label>
                  
                  <label className="flex items-center space-x-3 p-4 border-2 border-mocha-cream rounded-lg cursor-pointer hover:bg-mocha-cream/20 transition-colors">
                    <RadioGroupItem value="cash" />
                    <div className="flex-1">
                      <div className="font-display text-espresso-dark">Cash</div>
                      <div className="text-sm text-coffee-medium">Pay at pickup</div>
                    </div>
                    <div className="text-2xl">💵</div>
                  </label>
                </div>
              </RadioGroup>

              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={() => setStep('pickup')}
                  className="px-8 py-3"
                >
                  Back
                </Button>
                <Button
                  onClick={() => setStep('review')}
                  className="px-8 py-3"
                >
                  Review Order
                </Button>
              </div>
            </div>
          )}

          {/* Step 4: Order Review */}
          {step === 'review' && (
            <div className="space-y-6">
              <h2 className="font-display text-2xl text-espresso-dark mb-6">Order Summary</h2>
              
              {/* Order Items */}
              <div className="space-y-4">
                <h3 className="font-display text-lg text-espresso-dark">Items</h3>
                {items.map((item) => (
                  <div key={item.id} className="flex justify-between items-center py-3 border-b border-mocha-cream">
                    <div>
                      <div className="font-display text-espresso-dark">{item.name}</div>
                      <div className="text-sm text-coffee-medium">Qty: {item.quantity}</div>
                    </div>
                    <div className="font-display text-sunrise-coral">
                      {formatPrice(item.price * item.quantity)}
                    </div>
                  </div>
                ))}
              </div>

              {/* Totals */}
              <div className="space-y-2 py-4 border-t-2 border-dashed border-mocha-cream">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-display">{formatPrice(getSubtotal())}</span>
                </div>
                <div className="flex justify-between">
                  <span>GST (9%)</span>
                  <span className="font-display">{formatPrice(getGST())}</span>
                </div>
                <div className="flex justify-between text-xl font-display text-sunrise-coral border-t border-mocha-cream pt-2">
                  <span>Total</span>
                  <span>{formatPrice(getTotal())}</span>
                </div>
              </div>

              {/* Order Details */}
              <div className="space-y-4 py-4">
                <h3 className="font-display text-lg text-espresso-dark">Order Details</h3>
                <div className="text-sm space-y-2">
                  <div><strong>Payment Method:</strong> {paymentMethod.replace('_', ' ').toUpperCase()}</div>
                  <div><strong>Estimated Ready Time:</strong> 15-20 minutes</div>
                </div>
              </div>

              {/* PDPA Consent */}
              <div className="bg-latte-cream p-4 rounded-lg">
                <label className="flex items-start space-x-3">
                  <input type="checkbox" className="mt-1" required />
                  <div className="text-sm text-coffee-medium">
                    I consent to Morning Brew Collective collecting and using my personal data for order processing and customer service in accordance with the PDPA. I understand I can withdraw this consent at any time.
                  </div>
                </label>
              </div>

              <div className="flex justify-between mt-8">
                <Button
                  variant="outline"
                  onClick={() => setStep('payment')}
                  className="px-8 py-3"
                >
                  Back
                </Button>
                <Button
                  onClick={handlePlaceOrder}
                  className="px-8 py-3 bg-sunrise-coral text-white hover:bg-sunrise-coral-dark"
                >
                  Place Order
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}