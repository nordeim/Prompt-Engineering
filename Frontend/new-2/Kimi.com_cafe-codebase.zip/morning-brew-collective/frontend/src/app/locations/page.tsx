export default function LocationsPage() {
  const locations = [
    {
      id: 'chinatown',
      name: 'Chinatown Point',
      badge: 'Original',
      address: '133 New Bridge Road, #01-01 Chinatown Point, Singapore 059413',
      hours: 'Mon-Sun: 6:30 AM - 10:00 PM',
      features: ['Heritage Location', 'Indoor Seating', 'Wheelchair Accessible', 'Free WiFi'],
      coordinates: { lat: 1.2834, lng: 103.8447 }
    },
    {
      id: 'tampines',
      name: 'Tampines Hub',
      badge: 'Newest',
      address: '1 Tampines Walk, #B1-01 Our Tampines Hub, Singapore 528523',
      hours: 'Mon-Sun: 7:00 AM - 9:30 PM',
      features: ['Family Friendly', 'Outdoor Seating', 'Parking Available', 'Kids Menu'],
      coordinates: { lat: 1.3543, lng: 103.9454 }
    },
    {
      id: 'jurong',
      name: 'Jurong East',
      badge: 'Popular',
      address: '50 Jurong Gateway Road, #01-01 JEM, Singapore 608549',
      hours: 'Mon-Sun: 7:00 AM - 10:00 PM',
      features: ['MRT Connected', 'Shopping Mall', 'Extended Hours', 'Delivery Available'],
      coordinates: { lat: 1.3329, lng: 103.7436 }
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-mint-fresh to-mint-deep">
      <section className="py-20">
        <div className="container">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="font-display text-5xl md:text-6xl text-espresso-dark mb-6">
              Visit Our Locations
            </h1>
            <p className="text-xl text-coffee-medium max-w-2xl mx-auto">
              Find us at three convenient locations across Singapore, each offering the same authentic kopitiam experience
            </p>
          </div>

          {/* Locations Grid */}
          <div className="locations-grid grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
            {locations.map((location) => (
              <div
                key={location.id}
                className="location-card bg-ceramic-white rounded-2xl overflow-hidden shadow-md transition-all duration-normal ease-smooth hover:-translate-y-2 hover:shadow-lg"
              >
                {/* Location Header */}
                <div className="location-header bg-espresso-dark text-white p-5 flex justify-between items-center">
                  <h3 className="location-name font-display text-xl">{location.name}</h3>
                  <span className="location-badge bg-golden-hour text-espresso-dark px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                    {location.badge}
                  </span>
                </div>

                {/* Location Image Placeholder */}
                <div className="location-image h-45 bg-gradient-to-br from-mint-deep to-teal-retro flex items-center justify-center text-6xl">
                  📍
                </div>

                {/* Location Details */}
                <div className="location-details p-6">
                  <div className="location-address font-bold text-espresso-dark mb-2">
                    {location.address}
                  </div>
                  <div className="location-hours text-sm text-coffee-medium mb-4">
                    {location.hours}
                  </div>

                  <div className="location-features flex flex-wrap gap-2 mb-4">
                    {location.features.map((feature) => (
                      <span
                        key={feature}
                        className="feature text-xs px-2 py-1 bg-latte-cream rounded-sm text-coffee-medium"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>

                  <div className="location-actions flex gap-3">
                    <button className="location-btn location-btn-primary flex-1 px-3 py-2 bg-sunrise-coral text-white rounded-lg font-display text-sm transition-all duration-normal ease-bounce hover:bg-sunrise-coral-dark hover:-translate-y-1">
                      Get Directions
                    </button>
                    <button className="location-btn location-btn-secondary flex-1 px-3 py-2 bg-latte-cream text-espresso-dark border-2 border-golden-hour rounded-lg font-display text-sm transition-all duration-normal ease-bounce hover:bg-golden-hour-light">
                      Call Store
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Map Section */}
          <div className="map-container">
            <div className="text-center mb-8">
              <h2 className="font-display text-3xl text-espresso-dark mb-4">
                Find Us Across Singapore
              </h2>
              <p className="text-coffee-medium">
                All locations are easily accessible by public transport
              </p>
            </div>

            <div className="map-placeholder h-96 bg-espresso-dark rounded-2xl flex flex-col items-center justify-center text-white text-center p-8">
              <div className="map-title font-display text-2xl mb-4">
                Interactive Map Coming Soon
              </div>
              <div className="map-desc opacity-80 max-w-md mb-6">
                We're working on integrating with Google Maps to show you real-time directions, 
                store hours, and live wait times.
              </div>
              <div className="map-markers flex gap-8">
                <div className="text-center">
                  <div className="map-marker w-6 h-6 bg-sunrise-coral rounded-full shadow-[0_0_0_4px_rgba(255,107,74,0.3)] animate-pulse mx-auto mb-2"></div>
                  <div className="text-xs">Chinatown</div>
                </div>
                <div className="text-center">
                  <div className="map-marker w-6 h-6 bg-sunrise-coral rounded-full shadow-[0_0_0_4px_rgba(255,107,74,0.3)] animate-pulse mx-auto mb-2" style={{ animationDelay: '0.5s' }}></div>
                  <div className="text-xs">Tampines</div>
                </div>
                <div className="text-center">
                  <div className="map-marker w-6 h-6 bg-sunrise-coral rounded-full shadow-[0_0_0_4px_rgba(255,107,74,0.3)] animate-pulse mx-auto mb-2" style={{ animationDelay: '1s' }}></div>
                  <div className="text-xs">Jurong East</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}