export default function HeritagePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-golden-hour to-golden-hour-light">
      <section className="py-20">
        <div className="container">
          <div className="heritage-content grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Heritage Text */}
            <div className="heritage-text">
              <h1 className="font-display text-5xl text-espresso-dark mb-8">
                Our Heritage Story
              </h1>
              
              <div className="heritage-paragraph text-lg leading-relaxed mb-6">
                <span className="drop-cap font-display text-7xl leading-none text-sunrise-coral float-left mr-4 mt-2" style={{ textShadow: '3px 3px 0 #FDFCF9' }}>
                  I
                </span>
                n 1973, our founder Mr. Tan Ah Kow opened the first Morning Brew kiosk in the heart of Chinatown, 
                Singapore. With nothing but a brass kettle, a secret blend of coffee beans, and an unwavering 
                commitment to quality, he began what would become a beloved institution.
              </div>

              <p className="heritage-paragraph text-lg leading-relaxed mb-6">
                For over five decades, we've stayed true to the traditional methods of kopi brewing. Our beans 
                are still roasted with margarine and sugar, ground fresh daily, and brewed to perfection using 
                the time-honored sock filter method.
              </p>

              <div className="heritage-quote bg-ceramic-white p-8 rounded-2xl my-8 relative shadow-[8px_8px_0_#FF6B4A,0_8px_32px_rgba(107,68,35,0.15)]">
                <blockquote className="text-xl italic leading-relaxed mb-4 relative z-10">
                  "A good cup of kopi is not just about the taste—it's about bringing people together, 
                  creating moments of connection, and preserving a piece of Singaporean culture."
                </blockquote>
                <footer className="font-display text-base text-sunrise-coral">
                  — Mr. Tan Ah Kow, Founder
                </footer>
              </div>

              <p className="heritage-paragraph text-lg leading-relaxed mb-8">
                Today, the third generation of the Tan family continues this legacy, serving the same authentic 
                flavors that have been bringing smiles to faces for over 50 years. Every cup tells a story of 
                dedication, tradition, and the simple joy of a perfectly brewed morning.
              </p>

              {/* Values Grid */}
              <div className="heritage-values grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
                <div className="value-card text-center p-6 bg-white/50 rounded-xl transition-all duration-normal ease-smooth hover:bg-ceramic-white hover:-translate-y-1 hover:shadow-md">
                  <div className="value-icon text-4xl mb-3">☕</div>
                  <h3 className="value-title font-display text-lg mb-2">Authenticity</h3>
                  <p className="value-desc text-sm text-coffee-medium">Traditional recipes passed down through generations</p>
                </div>
                <div className="value-card text-center p-6 bg-white/50 rounded-xl transition-all duration-normal ease-smooth hover:bg-ceramic-white hover:-translate-y-1 hover:shadow-md">
                  <div className="value-icon text-4xl mb-3">❤️</div>
                  <h3 className="value-title font-display text-lg mb-2">Heritage</h3>
                  <p className="value-desc text-sm text-coffee-medium">Preserving Singaporean kopitiam culture</p>
                </div>
                <div className="value-card text-center p-6 bg-white/50 rounded-xl transition-all duration-normal ease-smooth hover:bg-ceramic-white hover:-translate-y-1 hover:shadow-md">
                  <div className="value-icon text-4xl mb-3">🤝</div>
                  <h3 className="value-title font-display text-lg mb-2">Community</h3>
                  <p className="value-desc text-sm text-coffee-medium">Bringing people together over great coffee</p>
                </div>
              </div>
            </div>

            {/* Heritage Gallery */}
            <div className="heritage-gallery grid grid-cols-2 gap-4">
              <div className="gallery-item bg-ceramic-white rounded-lg overflow-hidden shadow-md transition-all duration-normal ease-smooth hover:scale-102 hover:shadow-lg col-span-2">
                <div className="gallery-image aspect-[4/3] bg-gradient-to-br from-mocha-cream to-coffee-light flex items-center justify-center font-display text-2xl text-ceramic-white">
                  Original 1973 Kiosk
                </div>
                <div className="gallery-caption p-4 text-xs text-center text-coffee-medium">
                  Our first location in Chinatown
                </div>
              </div>
              <div className="gallery-item bg-ceramic-white rounded-lg overflow-hidden shadow-md transition-all duration-normal ease-smooth hover:scale-102 hover:shadow-lg">
                <div className="gallery-image aspect-[4/3] bg-gradient-to-br from-mocha-cream to-coffee-light flex items-center justify-center font-display text-xl text-ceramic-white">
                  Vintage Roaster
                </div>
                <div className="gallery-caption p-4 text-xs text-center text-coffee-medium">
                  Traditional roasting methods
                </div>
              </div>
              <div className="gallery-item bg-ceramic-white rounded-lg overflow-hidden shadow-md transition-all duration-normal ease-smooth hover:scale-102 hover:shadow-lg">
                <div className="gallery-image aspect-[4/3] bg-gradient-to-br from-mocha-cream to-coffee-light flex items-center justify-center font-display text-xl text-ceramic-white">
                  Family Legacy
                </div>
                <div className="gallery-caption p-4 text-xs text-center text-coffee-medium">
                  Three generations of brewers
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}