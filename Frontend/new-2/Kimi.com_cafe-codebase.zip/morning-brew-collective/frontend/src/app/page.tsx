import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="hero relative min-h-[calc(100vh-72px)] flex items-center py-16 overflow-hidden bg-gradient-to-b from-latte-cream via-latte-cream-warm to-tile-pattern-1">
        {/* Sunburst Background */}
        <div className="sunburst-bg" aria-hidden="true">
          <div className="absolute inset-0" style={{
            background: 'repeating-conic-gradient(from 0deg, #FFBE4F 0deg 8deg, transparent 8deg 16deg)',
            opacity: 0.2,
          }}></div>
        </div>

        <div className="container relative z-10">
          <div className="hero-content grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Hero Text */}
            <div className="hero-text max-w-[560px]">
              {/* Retro Badge */}
              <div className="retro-badge inline-flex items-center gap-2 bg-sunrise-coral text-white px-4 py-2 rounded-full font-display text-sm tracking-wider mb-6 shadow-[4px_4px_0_#FFBE4F,8px_8px_0_#3D2317] animate-bounce-gentle">
                <svg viewBox="0 0 16 16" fill="currentColor" className="w-4 h-4" aria-hidden="true">
                  <path d="M8 0l1.5 5.5L15 7l-5.5 1.5L8 16l-1.5-5.5L1 9l5.5-1.5z"/>
                </svg>
                Est. 1973 · Singapore
              </div>

              {/* Hero Title */}
              <h1 className="hero-title font-display text-[clamp(2.5rem,8vw,4.5rem)] leading-tight text-espresso-dark mb-6">
                Where Every
                <span className="highlight block text-sunrise-coral relative">
                  Morning Shines
                  <span className="absolute bottom-0 left-0 right-0 h-2 bg-golden-hour rounded-full transform scale-x-90 -z-10"></span>
                </span>
              </h1>

              {/* Hero Subtitle */}
              <p className="hero-subtitle text-xl leading-relaxed text-coffee-medium mb-8">
                Step into our kopitiam and taste 50 years of tradition. From the first aromatic sip of kopi to the last crumb of kaya toast, every moment is crafted with heritage and heart.
              </p>

              {/* CTA Buttons */}
              <div className="cta-group flex flex-wrap gap-4 mb-10">
                <Link href="#menu" className="btn btn-primary inline-flex items-center gap-2 px-8 py-4 rounded-full font-display text-lg bg-sunrise-coral text-white shadow-[0_4px_0_#E55A3A,0_8px_20px_rgba(255,107,74,0.2)] transition-all duration-normal ease-bounce hover:translate-y-[-2px] hover:shadow-[0_6px_0_#E55A3A,0_12px_30px_rgba(255,107,74,0.2)] active:translate-y-[2px] active:shadow-[0_2px_0_#E55A3A,0_4px_10px_rgba(255,107,74,0.2)]">
                  Explore Our Menu
                  <ArrowRight className="ml-2" />
                </Link>
                <Link href="#order" className="btn btn-secondary inline-flex items-center gap-2 px-8 py-4 rounded-full font-display text-lg bg-ceramic-white text-espresso-dark border-3 border-golden-hour shadow-[0_4px_0_#E5A030] transition-all duration-normal ease-bounce hover:bg-golden-hour-light hover:translate-y-[-2px] hover:shadow-[0_6px_0_#E5A030]">
                  Order for Pickup
                </Link>
              </div>

              {/* Stats */}
              <div className="hero-stats grid grid-cols-3 gap-6">
                <div className="stat-item text-center p-4 bg-ceramic-white rounded-lg border-2 border-tile-pattern-1 transition-all duration-normal ease-smooth hover:-translate-y-1 hover:shadow-md hover:border-golden-hour">
                  <span className="stat-number block font-display text-[2.5rem] text-sunrise-coral leading-none">50+</span>
                  <span className="stat-label text-sm font-semibold text-coffee-medium mt-1">Years of Craft</span>
                </div>
                <div className="stat-item text-center p-4 bg-ceramic-white rounded-lg border-2 border-tile-pattern-1 transition-all duration-normal ease-smooth hover:-translate-y-1 hover:shadow-md hover:border-golden-hour">
                  <span className="stat-number block font-display text-[2.5rem] text-sunrise-coral leading-none">1,000+</span>
                  <span className="stat-label text-sm font-semibold text-coffee-medium mt-1">Daily Brews</span>
                </div>
                <div className="stat-item text-center p-4 bg-ceramic-white rounded-lg border-2 border-tile-pattern-1 transition-all duration-normal ease-smooth hover:-translate-y-1 hover:shadow-md hover:border-golden-hour">
                  <span className="stat-number block font-display text-[2.5rem] text-sunrise-coral leading-none">3</span>
                  <span className="stat-label text-sm font-semibold text-coffee-medium mt-1">Locations</span>
                </div>
              </div>
            </div>

            {/* Hero Visual */}
            <div className="hero-visual flex items-center justify-center" aria-hidden="true">
              <div className="coffee-cup-wrapper relative w-full max-w-[400px] aspect-square">
                <div className="coffee-cup-bg absolute inset-0 bg-radial-gradient from-golden-hour-light via-transparent to-transparent rounded-full animate-pulse-gentle"></div>
                <svg className="coffee-cup-illustration relative z-1 w-full h-full" viewBox="0 0 200 200" fill="none">
                  {/* Coffee Cup Base */}
                  <ellipse cx="100" cy="170" rx="55" ry="15" fill="#C4A484" opacity="0.5"/>
                  <path d="M55 80 L55 150 Q55 170 100 170 Q145 170 145 150 L145 80 Z" fill="#FDFCF9" stroke="#3D2317" strokeWidth="3"/>
                  {/* Coffee Surface */}
                  <ellipse cx="100" cy="80" rx="45" ry="12" fill="#6B4423"/>
                  <ellipse cx="100" cy="78" rx="35" ry="8" fill="#8B6344" opacity="0.5"/>
                  {/* Cup Handle */}
                  <path d="M145 95 Q175 95 175 120 Q175 145 145 145" fill="none" stroke="#3D2317" strokeWidth="3"/>
                  {/* Decorative Pattern on Cup */}
                  <path d="M65 100 L135 100" stroke="#FF6B4A" strokeWidth="2"/>
                  <path d="M65 115 L135 115" stroke="#FFBE4F" strokeWidth="2"/>
                  <path d="M65 130 L135 130" stroke="#FF6B4A" strokeWidth="2"/>
                </svg>
                {/* Steam */}
                <div className="steam-container absolute top-[15%] left-1/2 transform -translate-x-1/2 flex gap-2">
                  <div className="steam w-2 h-10 bg-gradient-to-t from-transparent to-white/60 rounded-full animate-steam"></div>
                  <div className="steam w-2 h-[50px] bg-gradient-to-t from-transparent to-white/60 rounded-full animate-steam" style={{ animationDelay: '0.3s' }}></div>
                  <div className="steam w-2 h-[35px] bg-gradient-to-t from-transparent to-white/60 rounded-full animate-steam" style={{ animationDelay: '0.6s' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Wave Divider */}
        <div className="wave-divider absolute bottom-[-1px] left-0 right-0 h-[60px] overflow-hidden" aria-hidden="true">
          <svg viewBox="0 0 1440 60" preserveAspectRatio="none" className="absolute bottom-0 w-full h-full fill-sunrise-coral">
            <path d="M0 60 L0 30 Q360 0 720 30 Q1080 60 1440 30 L1440 60 Z"/>
          </svg>
        </div>
      </section>

      {/* Custom CSS for animations */}
      <style jsx>{`
        @keyframes bounce-gentle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }
        
        @keyframes pulse-gentle {
          0%, 100% { transform: scale(1); opacity: 0.6; }
          50% { transform: scale(1.1); opacity: 0.4; }
        }
        
        @keyframes steam {
          0%, 100% { opacity: 0; transform: translateY(0) scaleY(0.5); }
          50% { opacity: 1; transform: translateY(-20px) scaleY(1); }
        }
        
        .animate-bounce-gentle {
          animation: bounce-gentle 3s ease-in-out infinite;
        }
        
        .animate-pulse-gentle {
          animation: pulse-gentle 4s ease-in-out infinite;
        }
        
        .animate-steam {
          animation: steam 2s ease-in-out infinite;
        }
      `}</style>
    </>
  )
}