export function Footer() {
  return (
    <footer className="footer bg-espresso-dark text-white py-16">
      <div className="container">
        <div className="footer-content grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* About Section */}
          <div className="footer-section">
            <h3 className="font-display text-xl text-golden-hour mb-5">About Us</h3>
            <p className="footer-text text-sm leading-relaxed opacity-90">
              Morning Brew Collective has been serving authentic Singaporean kopi and traditional breakfast since 1973. 
              We're committed to preserving the heritage of kopitiam culture while embracing modern convenience.
            </p>
          </div>

          {/* Quick Links */}
          <div className="footer-section">
            <h3 className="font-display text-xl text-golden-hour mb-5">Quick Links</h3>
            <nav className="footer-links flex flex-col gap-3">
              <a href="#menu" className="footer-link text-sm opacity-90 transition-all duration-normal ease-smooth hover:opacity-100 hover:text-golden-hour hover:translate-x-1">
                Our Menu
              </a>
              <a href="#heritage" className="footer-link text-sm opacity-90 transition-all duration-normal ease-smooth hover:opacity-100 hover:text-golden-hour hover:translate-x-1">
                Our Story
              </a>
              <a href="#locations" className="footer-link text-sm opacity-90 transition-all duration-normal ease-smooth hover:opacity-100 hover:text-golden-hour hover:translate-x-1">
                Visit Us
              </a>
              <a href="#order" className="footer-link text-sm opacity-90 transition-all duration-normal ease-smooth hover:opacity-100 hover:text-golden-hour hover:translate-x-1">
                Order Online
              </a>
            </nav>
          </div>

          {/* Contact Info */}
          <div className="footer-section">
            <h3 className="font-display text-xl text-golden-hour mb-5">Contact</h3>
            <ul className="footer-contact space-y-2">
              <li className="text-sm opacity-90">
                📧 hello@morningbrew.sg
              </li>
              <li className="text-sm opacity-90">
                📞 +65 6123 4567
              </li>
              <li className="text-sm opacity-90">
                📍 Multiple locations across Singapore
              </li>
            </ul>
          </div>

          {/* Social Links */}
          <div className="footer-section">
            <h3 className="font-display text-xl text-golden-hour mb-5">Follow Us</h3>
            <div className="social-links flex gap-3">
              <a href="#" className="social-link w-11 h-11 bg-white/10 rounded-full flex items-center justify-center text-sm transition-all duration-normal ease-bounce hover:bg-sunrise-coral hover:-translate-y-1" aria-label="Facebook">
                f
              </a>
              <a href="#" className="social-link w-11 h-11 bg-white/10 rounded-full flex items-center justify-center text-sm transition-all duration-normal ease-bounce hover:bg-sunrise-coral hover:-translate-y-1" aria-label="Instagram">
                📷
              </a>
              <a href="#" className="social-link w-11 h-11 bg-white/10 rounded-full flex items-center justify-center text-sm transition-all duration-normal ease-bounce hover:bg-sunrise-coral hover:-translate-y-1" aria-label="Twitter">
                🐦
              </a>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="footer-bottom text-center pt-8 border-t border-white/10">
          <p className="text-sm opacity-70 mb-2">
            © 2024 Morning Brew Collective. All rights reserved.
          </p>
          <p className="text-xs opacity-60">
            Made with ☕ and ❤️ in Singapore
          </p>
          
          {/* Compliance Badges */}
          <div className="footer-badges flex flex-wrap justify-center gap-3 mt-4">
            <span className="footer-badge px-3 py-1 bg-white/10 rounded-full text-xs font-semibold uppercase tracking-wider">
              GST Registered
            </span>
            <span className="footer-badge px-3 py-1 bg-white/10 rounded-full text-xs font-semibold uppercase tracking-wider">
              PayNow Accepted
            </span>
            <span className="footer-badge px-3 py-1 bg-white/10 rounded-full text-xs font-semibold uppercase tracking-wider">
              PDPA Compliant
            </span>
            <span className="footer-badge px-3 py-1 bg-white/10 rounded-full text-xs font-semibold uppercase tracking-wider">
              Halal Certified
            </span>
          </div>
        </div>
      </div>
    </footer>
  )
}