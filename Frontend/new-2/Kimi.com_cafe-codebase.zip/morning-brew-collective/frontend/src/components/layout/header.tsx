'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { ShoppingCart, Menu, X } from 'lucide-react'
import { useCartStore } from '@/stores/cart-store'

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isCartOpen, setIsCartOpen] = useState(false)
  const { getItemCount } = useCartStore()

  const cartItemCount = getItemCount()

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = 'auto'
    }
  }, [isMobileMenuOpen])

  return (
    <header className="header sticky top-0 z-50 bg-ceramic-white border-b-4 border-golden-hour shadow-sm">
      <div className="container">
        <div className="header-inner flex items-center justify-between h-[72px] gap-8">
          {/* Logo */}
          <Link href="/" className="logo flex items-center gap-3" aria-label="Morning Brew Collective Home">
            <div className="logo-badge w-14 h-14 bg-sunrise-coral rounded-full flex items-center justify-center relative shadow-[0_0_0_3px_#FDFCF9,0_0_0_6px_#FFBE4F]" aria-hidden="true">
              <span className="text-[1.75rem] filter brightness-0 invert">☕</span>
            </div>
            <div className="logo-text flex flex-col leading-tight">
              <span className="logo-title font-display text-[1.5rem] text-espresso-dark tracking-[0.02em]">
                Morning Brew
              </span>
              <span className="logo-subtitle text-[0.75rem] font-bold text-sunrise-coral uppercase tracking-[0.15em]">
                Collective
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="nav-main hidden md:flex items-center gap-2" aria-label="Main navigation">
            <Link href="#menu" className="nav-link font-display text-base text-coffee-medium px-3 py-2 rounded-full relative transition-all duration-normal ease-smooth hover:text-sunrise-coral hover:bg-latte-cream">
              Menu
            </Link>
            <Link href="#heritage" className="nav-link font-display text-base text-coffee-medium px-3 py-2 rounded-full relative transition-all duration-normal ease-smooth hover:text-sunrise-coral hover:bg-latte-cream">
              Our Story
            </Link>
            <Link href="#locations" className="nav-link font-display text-base text-coffee-medium px-3 py-2 rounded-full relative transition-all duration-normal ease-smooth hover:text-sunrise-coral hover:bg-latte-cream">
              Visit Us
            </Link>
            <Link href="#order" className="nav-link font-display text-base text-coffee-medium px-3 py-2 rounded-full relative transition-all duration-normal ease-smooth hover:text-sunrise-coral hover:bg-latte-cream">
              Order
            </Link>
          </nav>

          {/* Header Actions */}
          <div className="header-actions flex items-center gap-4">
            <button
              onClick={() => setIsCartOpen(true)}
              aria-label={`Shopping cart, ${cartItemCount} items`}
              className="cart-btn relative w-11 h-11 bg-latte-cream rounded-full flex items-center justify-center transition-all duration-normal ease-smooth hover:bg-golden-hour-light hover:border-golden-hour hover:scale-105 border-2 border-transparent"
            >
              <ShoppingCart className="w-[22px] h-[22px] stroke-coffee-medium stroke-2" />
              {cartItemCount > 0 && (
                <span className="cart-count absolute -top-1 -right-1 min-w-[20px] h-[20px] bg-sunrise-coral text-white text-[0.7rem] font-bold rounded-full flex items-center justify-center border-2 border-ceramic-white">
                  {cartItemCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(true)}
              aria-expanded={isMobileMenuOpen}
              aria-controls="mobile-menu"
              className="menu-toggle md:hidden flex flex-col gap-[5px] p-2 rounded-sm transition-background duration-normal ease-smooth hover:bg-latte-cream"
              aria-label="Open menu"
            >
              <span className="block w-6 h-[3px] bg-coffee-medium rounded-full transition-all duration-normal ease-smooth"></span>
              <span className="block w-6 h-[3px] bg-coffee-medium rounded-full transition-all duration-normal ease-smooth"></span>
              <span className="block w-6 h-[3px] bg-coffee-medium rounded-full transition-all duration-normal ease-smooth"></span>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div
          id="mobile-menu"
          className="mobile-menu fixed inset-0 bg-ceramic-white z-50 flex flex-col items-center justify-center gap-8 transform translate-y-[-100%] transition-transform duration-slow ease-smooth md:hidden"
          aria-hidden={!isMobileMenuOpen}
        >
          <button
            onClick={() => setIsMobileMenuOpen(false)}
            className="mobile-menu-close absolute top-6 right-6 w-12 h-12 bg-latte-cream rounded-full text-[1.5rem] text-coffee-medium flex items-center justify-center"
            aria-label="Close menu"
          >
            <X />
          </button>
          <Link href="#menu" onClick={() => setIsMobileMenuOpen(false)} className="mobile-nav-link font-display text-[2rem] text-espresso-dark px-6 py-3 rounded-full transition-all duration-normal ease-smooth hover:bg-golden-hour-light hover:text-sunrise-coral">
            Menu
          </Link>
          <Link href="#heritage" onClick={() => setIsMobileMenuOpen(false)} className="mobile-nav-link font-display text-[2rem] text-espresso-dark px-6 py-3 rounded-full transition-all duration-normal ease-smooth hover:bg-golden-hour-light hover:text-sunrise-coral">
            Our Story
          </Link>
          <Link href="#locations" onClick={() => setIsMobileMenuOpen(false)} className="mobile-nav-link font-display text-[2rem] text-espresso-dark px-6 py-3 rounded-full transition-all duration-normal ease-smooth hover:bg-golden-hour-light hover:text-sunrise-coral">
            Visit Us
          </Link>
          <Link href="#order" onClick={() => setIsMobileMenuOpen(false)} className="mobile-nav-link font-display text-[2rem] text-espresso-dark px-6 py-3 rounded-full transition-all duration-normal ease-smooth hover:bg-golden-hour-light hover:text-sunrise-coral">
            Order
          </Link>
        </div>
      )}

      {/* Cart Overlay */}
      {/* TODO: Implement CartOverlay component */}
    </header>
  )
}