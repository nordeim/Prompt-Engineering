import * as React from "react"
import { cn } from "@/lib/utils"

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'default' | 'outline' | 'secondary'
  size?: 'default' | 'sm' | 'lg'
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'default', size = 'default', ...props }, ref) => {
    return (
      <button
        className={cn(
          "inline-flex items-center justify-center rounded-full font-display font-semibold transition-all duration-normal ease-bounce focus:outline-none focus:ring-2 focus:ring-sunrise-coral focus:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none",
          {
            'bg-sunrise-coral text-white hover:bg-sunrise-coral-dark shadow-[0_4px_0_#E55A3A] hover:shadow-[0_6px_0_#E55A3A] hover:-translate-y-1 active:shadow-[0_2px_0_#E55A3A] active:translate-y-0':
              variant === 'default',
            'bg-ceramic-white text-espresso-dark border-2 border-golden-hour hover:bg-golden-hour-light':
              variant === 'outline',
            'bg-golden-hour text-espresso-dark hover:bg-golden-hour-light':
              variant === 'secondary',
          },
          {
            'h-10 px-4 py-2': size === 'sm',
            'h-12 px-6 py-3': size === 'default',
            'h-14 px-8 py-4 text-lg': size === 'lg',
          },
          className
        )}
        ref={ref}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button }