import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  category: string
  imageUrl?: string
}

interface CartState {
  items: CartItem[]
  addItem: (item: Omit<CartItem, 'quantity'>) => void
  removeItem: (id: string) => void
  updateQuantity: (id: string, quantity: number) => void
  clearCart: () => void
  getItemCount: () => number
  getSubtotal: () => number
  getGST: () => number // 9% of subtotal
  getTotal: () => number // subtotal + GST
  isOpen: boolean
  setIsOpen: (isOpen: boolean) => void
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      isOpen: false,
      
      addItem: (item) => {
        set((state) => {
          const existingItem = state.items.find(i => i.id === item.id)
          if (existingItem) {
            return {
              items: state.items.map(i =>
                i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
              )
            }
          }
          return {
            items: [...state.items, { ...item, quantity: 1 }]
          }
        })
      },
      
      removeItem: (id) => {
        set((state) => ({
          items: state.items.filter(i => i.id !== id)
        }))
      },
      
      updateQuantity: (id, quantity) => {
        set((state) => ({
          items: state.items
            .map(i => i.id === id ? { ...i, quantity: Math.max(0, quantity) } : i)
            .filter(i => i.quantity > 0)
        }))
      },
      
      clearCart: () => set({ items: [] }),
      
      getItemCount: () => {
        const state = get()
        return state.items.reduce((sum, item) => sum + item.quantity, 0)
      },
      
      getSubtotal: () => {
        const state = get()
        return state.items.reduce((sum, item) => sum + (item.price * item.quantity), 0)
      },
      
      getGST: () => {
        const state = get()
        return Math.round(state.getSubtotal() * 0.09 * 100) / 100
      },
      
      getTotal: () => {
        const state = get()
        return Math.round((state.getSubtotal() + state.getGST()) * 100) / 100
      },
      
      setIsOpen: (isOpen) => set({ isOpen }),
    }),
    {
      name: 'morning-brew-cart',
      version: 1,
    }
  )
)