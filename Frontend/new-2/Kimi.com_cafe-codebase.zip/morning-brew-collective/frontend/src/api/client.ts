export interface Product {
  id: string
  name: string
  description: string
  price: number
  price_formatted: string
  category: string
  tags: string[]
  image_url?: string
  is_active: boolean
  in_stock: boolean
  stock_quantity: number
}

export interface ProductCategory {
  id: string
  name: string
  count: number
}

export interface Location {
  id: string
  name: string
  slug: string
  address: string
  full_address: string
  postal_code: string
  phone: string
  email: string
  operating_hours: Record<string, any>
  features: string[]
  latitude: number
  longitude: number
  description?: string
  image_url?: string
  is_open_now: boolean
  next_available_slot?: string
}

export interface OrderItem {
  product_id: string
  name: string
  price: number
  quantity: number
}

export interface CreateOrderPayload {
  customer_name: string
  customer_email: string
  customer_phone: string
  pickup_location_id: string
  pickup_datetime: string
  items: OrderItem[]
  payment_method: 'paynow' | 'credit_card' | 'cash'
  consent_data?: Record<string, any>
}

export interface Order {
  id: string
  invoice_number: string
  customer_name: string
  customer_email: string
  customer_phone: string
  pickup_location_id: string
  pickup_datetime: string
  subtotal: number
  gst: number
  total: number
  status: string
  payment_method: string
  payment_status: string
  items: OrderItem[]
  location?: Location
  created_at: string
  updated_at: string
}

export class ApiClient {
  private baseUrl: string

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl.replace(/\/$/, '')
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    }

    const response = await fetch(url, config)

    if (!response.ok) {
      const error = await response.json().catch(() => ({}))
      throw new Error(error.message || `HTTP ${response.status}: ${response.statusText}`)
    }

    return response.json()
  }

  async getProducts(params?: {
    category?: string
    search?: string
  }): Promise<Product[]> {
    const query = new URLSearchParams()
    if (params?.category) query.append('category', params.category)
    if (params?.search) query.append('search', params.search)

    return this.request<Product[]>(`/products?${query}`)
  }

  async getProduct(id: string): Promise<Product> {
    return this.request<Product>(`/products/${id}`)
  }

  async getProductCategories(): Promise<ProductCategory[]> {
    return this.request<ProductCategory[]>('/products/categories')
  }

  async getLocations(): Promise<Location[]> {
    return this.request<Location[]>('/locations')
  }

  async getLocation(id: string): Promise<Location> {
    return this.request<Location>(`/locations/${id}`)
  }

  async createOrder(order: CreateOrderPayload): Promise<Order> {
    return this.request<Order>('/orders', {
      method: 'POST',
      body: JSON.stringify(order),
    })
  }

  async getOrder(id: string): Promise<Order> {
    return this.request<Order>(`/orders/${id}`)
  }

  async cancelOrder(id: string): Promise<Order> {
    return this.request<Order>(`/orders/${id}/cancel`, {
      method: 'PUT',
    })
  }

  async getHealth(): Promise<{ status: string; timestamp: string; version: string }> {
    return this.request('/health')
  }
}

// Singleton instance
const apiClient = new ApiClient(
  process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api'
)

export default apiClient