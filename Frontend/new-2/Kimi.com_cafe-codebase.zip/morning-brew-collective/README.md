# Morning Brew Collective

A modern, Singapore-compliant e-commerce platform for a traditional kopitiam, built with Next.js 15, Laravel 12, and PostgreSQL 16.

## 🌟 Features

- **1970s Retro Aesthetic**: Authentic kopitiam design with modern UX
- **Singapore Compliance**: GST 9%, PayNow integration, InvoiceNow ready, PDPA compliant
- **Full E-commerce**: Cart, checkout, inventory management
- **Multi-location Support**: Find and order from different outlets
- **Responsive Design**: Works perfectly on all devices

## 🏗️ Architecture

```
morning-brew-collective/
├── frontend/          # Next.js 15 application
├── backend/           # Laravel 12 API
├── infra/            # Docker & infrastructure
├── docs/             # Documentation
└── scripts/          # Development scripts
```

## 🚀 Quick Start

### Prerequisites

- Docker and Docker Compose
- Node.js 22+ (for local development)
- PHP 8.3+ (for local development)

### Development Setup

1. **Clone and setup**:
   ```bash
   cd morning-brew-collective
   cp backend/.env.example backend/.env
   cp frontend/.env.example frontend/.env.local
   ```

2. **Start with Docker**:
   ```bash
   make up
   make migrate
   make seed
   ```

3. **Access the applications**:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - Mailpit: http://localhost:8025

### Development Commands

```bash
make help           # Show all available commands
make up            # Start all services
make down          # Stop all services
make logs          # View logs
make shell-backend # Access backend container
make shell-frontend # Access frontend container
make migrate       # Run database migrations
make test          # Run all tests
make lint          # Lint code
make format        # Format code
```

## 🎨 Design System

The project follows a strict 1970s kopitiam aesthetic with:

- **Colors**: Sunrise coral (#FF6B4A), Golden hour (#FFBE4F), Espresso dark (#3D2317)
- **Typography**: Righteous (display), Nunito (body)
- **Animations**: Bounce and smooth easing curves
- **Patterns**: Sunburst, waves, tiles, coffee rings

## 📱 Pages

- `/` - Homepage with hero section and brand story
- `/menu` - Interactive menu with filtering
- `/heritage` - Brand heritage and story
- `/locations` - Store locations and directions
- `/checkout` - Multi-step checkout with Singapore compliance

## 🔧 Technology Stack

### Frontend
- Next.js 15 with App Router
- React 19
- TypeScript with strict mode
- Tailwind CSS v4
- Shadcn UI components
- Zustand for state management
- Framer Motion for animations

### Backend
- Laravel 12
- PHP 8.3
- PostgreSQL 16
- Redis 7
- Stripe for payments
- Laravel Sanctum for API auth

### Infrastructure
- Docker Compose for development
- Nginx for production
- Mailpit for email testing
- Health checks enabled

## 🏛️ Singapore Compliance

### GST Calculation
- All prices displayed include 9% GST
- Proper rounding to 2 decimal places
- GST breakdown shown at checkout

### PayNow Integration
- QR code generation via Stripe
- Instant payment confirmation
- Support for all major Singapore banks

### InvoiceNow (PEPPOL)
- UBL 2.1 XML generation ready
- IMDA-approved Access Point integration
- B2B transaction support

### PDPA Compliance
- Explicit consent collection
- Data minimization principles
- Consent audit trail
- Right to erasure implementation

## 🧪 Testing

```bash
# Frontend tests
cd frontend && npm test

# Backend tests
cd backend && php artisan test

# E2E tests
cd frontend && npm run test:e2e
```

## 🚀 Deployment

### Production Build

```bash
# Build frontend
cd frontend && npm run build

# Build backend
cd backend && composer install --no-dev --optimize-autoloader
```

### Docker Production

```bash
docker-compose -f docker-compose.prod.yml up -d
```

## 📊 Monitoring

- Application metrics via Laravel Telescope
- Error tracking with Sentry integration
- Performance monitoring with New Relic
- Uptime monitoring with custom health checks

## 🔒 Security

- CSRF protection enabled
- XSS prevention with React
- SQL injection prevention with Eloquent
- Rate limiting on API endpoints
- Secure cookie configuration

## 📄 License

MIT License - see LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests and linting
5. Submit a pull request

## 📞 Support

For support, please contact:
- Email: hello@morningbrew.sg
- Phone: +65 6123 4567

---

Made with ☕ and ❤️ in Singapore