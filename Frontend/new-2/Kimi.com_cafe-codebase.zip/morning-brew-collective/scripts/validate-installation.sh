#!/bin/bash

# Morning Brew Collective - Installation Validation Script
# This script validates that the project has been set up correctly

set -e

echo "🔍 Validating Morning Brew Collective Installation..."
echo "=================================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if we're in the right directory
if [ ! -f "docker-compose.yml" ]; then
    echo -e "${RED}❌ Error: docker-compose.yml not found. Please run this script from the project root.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Project root directory confirmed${NC}"

# Check directory structure
echo ""
echo "📁 Checking directory structure..."
REQUIRED_DIRS=(
    "frontend/src"
    "frontend/src/app"
    "frontend/src/components"
    "frontend/src/lib"
    "frontend/src/styles"
    "frontend/src/stores"
    "backend/app"
    "backend/app/Models"
    "backend/app/Http/Controllers"
    "backend/routes"
    "infra/postgres"
    "scripts"
    "docs"
)

for dir in "${REQUIRED_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        echo -e "${GREEN}✅ $dir${NC}"
    else
        echo -e "${RED}❌ $dir (missing)${NC}"
    fi
done

# Check essential files
echo ""
echo "📄 Checking essential files..."
ESSENTIAL_FILES=(
    "docker-compose.yml"
    "Makefile"
    "frontend/package.json"
    "frontend/next.config.ts"
    "frontend/tsconfig.json"
    "frontend/postcss.config.mjs"
    "frontend/components.json"
    "backend/composer.json"
    "backend/Dockerfile.dev"
    "backend/.env.example"
    "infra/postgres/init.sql"
)

for file in "${ESSENTIAL_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✅ $file${NC}"
    else
        echo -e "${RED}❌ $file (missing)${NC}"
    fi
done

# Check Docker services
echo ""
echo "🐳 Checking Docker services..."
if command -v docker-compose &> /dev/null; then
    echo -e "${GREEN}✅ Docker Compose is installed${NC}"
else
    echo -e "${RED}❌ Docker Compose is not installed${NC}"
fi

# Check Node.js version
echo ""
echo "📦 Checking Node.js version..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node -v 2>/dev/null | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -ge 22 ]; then
        echo -e "${GREEN}✅ Node.js $(node -v) (>=22 required)${NC}"
    else
        echo -e "${YELLOW}⚠️  Node.js $(node -v) (>=22 recommended)${NC}"
    fi
else
    echo -e "${RED}❌ Node.js is not installed${NC}"
fi

# Check PHP version
echo ""
echo "🐘 Checking PHP version..."
if command -v php &> /dev/null; then
    PHP_VERSION=$(php -v 2>/dev/null | head -n1 | cut -d' ' -f2 | cut -d'.' -f1)
    if [ "$PHP_VERSION" -ge 8 ]; then
        echo -e "${GREEN}✅ PHP $(php -v 2>/dev/null | head -n1 | cut -d' ' -f2) (>=8.3 required)${NC}"
    else
        echo -e "${YELLOW}⚠️  PHP $(php -v 2>/dev/null | head -n1 | cut -d' ' -f2) (>=8.3 recommended)${NC}"
    fi
else
    echo -e "${RED}❌ PHP is not installed${NC}"
fi

# Check environment files
echo ""
echo "⚙️  Checking environment files..."
if [ -f "backend/.env" ]; then
    echo -e "${GREEN}✅ backend/.env${NC}"
else
    echo -e "${YELLOW}⚠️  backend/.env (copy from .env.example)${NC}"
fi

if [ -f "frontend/.env.local" ]; then
    echo -e "${GREEN}✅ frontend/.env.local${NC}"
else
    echo -e "${YELLOW}⚠️  frontend/.env.local (copy from .env.example)${NC}"
fi

# Summary
echo ""
echo "📊 Installation Summary"
echo "======================="
echo ""
echo "🎯 Next Steps:"
echo "1. Copy environment files: cp backend/.env.example backend/.env && cp frontend/.env.example frontend/.env.local"
echo "2. Start Docker services: make up"
echo "3. Run migrations: make migrate"
echo "4. Install dependencies: make install"
echo "5. Access the application at http://localhost:3000"
echo ""
echo "🚀 You're ready to start developing!"
echo ""
echo "📚 Useful Commands:"
echo "- make help     # Show all available commands"
echo "- make logs     # View application logs"
echo "- make shell-backend  # Access backend container"
echo "- make shell-frontend # Access frontend container"
echo ""
echo "Happy coding! ☕"