<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Location extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'address',
        'postal_code',
        'phone',
        'email',
        'operating_hours',
        'features',
        'latitude',
        'longitude',
        'is_active',
        'image_url',
        'description',
    ];

    protected $casts = [
        'features' => 'array',
        'operating_hours' => 'array',
        'latitude' => 'decimal:8',
        'longitude' => 'decimal:8',
        'is_active' => 'boolean',
    ];

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'pickup_location_id');
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function getFullAddressAttribute(): string
    {
        return "{$this->address}, Singapore {$this->postal_code}";
    }

    public function isOpenNow(): bool
    {
        $now = now('Asia/Singapore');
        $currentTime = $now->format('H:i');
        $currentDay = strtolower($now->format('l'));

        if (!isset($this->operating_hours[$currentDay])) {
            return false;
        }

        $hours = $this->operating_hours[$currentDay];
        
        if ($hours['closed'] ?? false) {
            return false;
        }

        return $currentTime >= $hours['open'] && $currentTime <= $hours['close'];
    }

    public function getNextAvailableSlot(): ?string
    {
        $now = now('Asia/Singapore');
        
        // Add 30 minutes lead time
        $availableFrom = $now->copy()->addMinutes(30);
        
        // Round to next 30-minute interval
        $minutes = $availableFrom->minute;
        if ($minutes < 30) {
            $availableFrom->minute = 30;
        } else {
            $availableFrom->minute = 0;
            $availableFrom->addHour();
        }

        return $availableFrom->format('Y-m-d H:i');
    }
}