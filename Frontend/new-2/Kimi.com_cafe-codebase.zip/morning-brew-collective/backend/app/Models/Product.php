<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'price_cents', // stored as integer cents (350 for $3.50)
        'category',
        'tags',
        'is_active',
        'image_url',
        'stock_quantity',
        'available_stock',
    ];

    protected $casts = [
        'price_cents' => 'integer',
        'tags' => 'array',
        'is_active' => 'boolean',
        'stock_quantity' => 'integer',
        'available_stock' => 'integer',
    ];

    public function getPriceAttribute()
    {
        return $this->price_cents / 100;
    }

    public function getPriceFormattedAttribute()
    {
        return number_format($this->price, 2);
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeInStock($query)
    {
        return $query->where('available_stock', '>', 0);
    }

    public function hasStock(int $quantity): bool
    {
        return $this->available_stock >= $quantity;
    }

    public function reserveStock(int $quantity): void
    {
        if (!$this->hasStock($quantity)) {
            throw new \Exception('Insufficient stock available');
        }

        $this->decrement('available_stock', $quantity);
    }

    public function releaseStock(int $quantity): void
    {
        $this->increment('available_stock', $quantity);
    }

    public function commitStock(int $quantity): void
    {
        $this->decrement('stock_quantity', $quantity);
    }
}