<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class OrderItem extends Model
{
    protected $fillable = [
        'order_id',
        'product_id',
        'name',
        'price_cents',
        'quantity',
        'subtotal_cents',
    ];

    protected $casts = [
        'price_cents' => 'integer',
        'quantity' => 'integer',
        'subtotal_cents' => 'integer',
    ];

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    public function getPriceAttribute()
    {
        return $this->price_cents / 100;
    }

    public function getSubtotalAttribute()
    {
        return $this->subtotal_cents / 100;
    }

    public function calculateSubtotal(): void
    {
        $this->subtotal_cents = $this->price_cents * $this->quantity;
    }
}