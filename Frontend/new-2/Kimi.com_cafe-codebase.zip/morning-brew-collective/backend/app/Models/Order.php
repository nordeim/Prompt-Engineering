<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Order extends Model
{
    protected $fillable = [
        'customer_name',
        'customer_email',
        'customer_phone',
        'customer_pseudonym',
        'pickup_location_id',
        'pickup_datetime',
        'subtotal_cents',
        'gst_cents', // 9% of subtotal
        'total_cents',
        'status', // pending, confirmed, completed, cancelled, refunded
        'payment_method', // paynow, credit_card, cash
        'payment_status', // pending, processing, completed, failed, refunded
        'invoice_number',
        'stripe_payment_intent_id',
        'stripe_charge_id',
        'paynow_qr_code',
        'consent_data',
        'ip_address',
        'user_agent',
    ];

    protected $casts = [
        'subtotal_cents' => 'integer',
        'gst_cents' => 'integer',
        'total_cents' => 'integer',
        'pickup_datetime' => 'datetime',
        'consent_data' => 'array',
    ];

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function location(): BelongsTo
    {
        return $this->belongsTo(Location::class, 'pickup_location_id');
    }

    public function calculateTotals(): void
    {
        $subtotal = $this->items->sum(fn($item) => $item->price_cents * $item->quantity);
        $gst = round($subtotal * 0.09); // 9% GST
        $total = $subtotal + $gst;

        $this->subtotal_cents = $subtotal;
        $this->gst_cents = $gst;
        $this->total_cents = $total;
    }

    public function getSubtotalAttribute()
    {
        return $this->subtotal_cents / 100;
    }

    public function getGstAttribute()
    {
        return $this->gst_cents / 100;
    }

    public function getTotalAttribute()
    {
        return $this->total_cents / 100;
    }

    public function getTotalFormattedAttribute()
    {
        return number_format($this->total, 2);
    }

    public function generateInvoiceNumber(): string
    {
        $date = now()->format('Ymd');
        $sequence = self::whereDate('created_at', today())->count() + 1;
        
        return "MBC{$date}" . str_pad($sequence, 4, '0', STR_PAD_LEFT);
    }

    public function markAsPaid(string $paymentIntentId = null, string $chargeId = null): void
    {
        $this->payment_status = 'completed';
        $this->status = 'confirmed';
        
        if ($paymentIntentId) {
            $this->stripe_payment_intent_id = $paymentIntentId;
        }
        
        if ($chargeId) {
            $this->stripe_charge_id = $chargeId;
        }

        $this->save();
    }

    public function canBeCancelled(): bool
    {
        return in_array($this->status, ['pending', 'confirmed']) && 
               $this->pickup_datetime > now()->addHours(2);
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeConfirmed($query)
    {
        return $query->where('status', 'confirmed');
    }

    public function scopeCompleted($query)
    {
        return $query->where('status', 'completed');
    }
}