<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Product::active()->inStock();

        // Filter by category
        if ($request->has('category')) {
            $query->where('category', $request->get('category'));
        }

        // Search by name or description
        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        $products = $query->orderBy('name')->get();

        return response()->json(
            $products->map(function ($product) {
                return [
                    'id' => $product->id,
                    'name' => $product->name,
                    'description' => $product->description,
                    'price' => $product->price,
                    'price_formatted' => $product->price_formatted,
                    'category' => $product->category,
                    'tags' => $product->tags,
                    'image_url' => $product->image_url,
                    'is_active' => $product->is_active,
                    'in_stock' => $product->available_stock > 0,
                ];
            })
        );
    }

    public function show(Product $product): JsonResponse
    {
        if (!$product->is_active || !$product->in_stock) {
            return response()->json(['message' => 'Product not available'], 404);
        }

        return response()->json([
            'id' => $product->id,
            'name' => $product->name,
            'description' => $product->description,
            'price' => $product->price,
            'price_formatted' => $product->price_formatted,
            'category' => $product->category,
            'tags' => $product->tags,
            'image_url' => $product->image_url,
            'is_active' => $product->is_active,
            'in_stock' => $product->available_stock > 0,
            'stock_quantity' => $product->available_stock,
        ]);
    }

    public function categories(): JsonResponse
    {
        $categories = Product::active()
            ->select('category')
            ->distinct()
            ->orderBy('category')
            ->pluck('category');

        return response()->json($categories->map(function ($category) {
            return [
                'id' => $category,
                'name' => ucfirst($category),
                'count' => Product::active()->where('category', $category)->count(),
            ];
        }));
    }
}