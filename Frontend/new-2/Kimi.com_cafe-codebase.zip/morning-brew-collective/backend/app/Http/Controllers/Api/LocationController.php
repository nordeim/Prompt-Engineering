<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Location;
use Illuminate\Http\JsonResponse;

class LocationController extends Controller
{
    public function index(): JsonResponse
    {
        $locations = Location::active()->orderBy('name')->get();

        return response()->json(
            $locations->map(function ($location) {
                return [
                    'id' => $location->id,
                    'name' => $location->name,
                    'slug' => $location->slug,
                    'address' => $location->address,
                    'full_address' => $location->full_address,
                    'postal_code' => $location->postal_code,
                    'phone' => $location->phone,
                    'email' => $location->email,
                    'operating_hours' => $location->operating_hours,
                    'features' => $location->features,
                    'latitude' => $location->latitude,
                    'longitude' => $location->longitude,
                    'description' => $location->description,
                    'image_url' => $location->image_url,
                    'is_open_now' => $location->isOpenNow(),
                    'next_available_slot' => $location->getNextAvailableSlot(),
                ];
            })
        );
    }

    public function show(Location $location): JsonResponse
    {
        if (!$location->is_active) {
            return response()->json(['message' => 'Location not found'], 404);
        }

        return response()->json([
            'id' => $location->id,
            'name' => $location->name,
            'slug' => $location->slug,
            'address' => $location->address,
            'full_address' => $location->full_address,
            'postal_code' => $location->postal_code,
            'phone' => $location->phone,
            'email' => $location->email,
            'operating_hours' => $location->operating_hours,
            'features' => $location->features,
            'latitude' => $location->latitude,
            'longitude' => $location->longitude,
            'description' => $location->description,
            'image_url' => $location->image_url,
            'is_open_now' => $location->isOpenNow(),
            'next_available_slot' => $location->getNextAvailableSlot(),
        ]);
    }
}