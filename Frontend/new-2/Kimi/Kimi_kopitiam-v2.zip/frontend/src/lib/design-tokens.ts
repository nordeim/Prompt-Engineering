/**
 * Design Tokens - Morning Brew Collective
 * TypeScript definitions for all CSS custom properties
 */

export const designTokens = {
  colors: {
    'sunrise-amber': {
      DEFAULT: '#E8A857',
      50: '#FFF8E7',
      100: '#F5DEB3',
      200: '#E8A857',
      300: '#D4A574',
      400: '#C68642',
    },
    'terracotta-warm': {
      DEFAULT: '#D4693B',
      50: '#FAF3E3',
      100: '#E6C9A8',
      200: '#D4693B',
      300: '#C68642',
      400: '#6B4423',
    },
    'espresso-dark': {
      DEFAULT: '#3D2B1F',
      50: '#FAF3E3',
      100: '#FFF8E7',
      200: '#F5DEB3',
      300: '#3D2B1F',
      400: '#2A1F16',
    },
    'coral-pop': {
      DEFAULT: '#FF7B54',
      50: '#FFF5F2',
      100: '#FFE8E1',
      200: '#FF7B54',
      300: '#E86A45',
      400: '#D45D3A',
    },
    'sage-fresh': {
      DEFAULT: '#8FA68A',
      50: '#F4F6F3',
      100: '#E8EBE7',
      200: '#8FA68A',
      300: '#7A9475',
      400: '#6B8267',
    },
    'cream-white': '#FFF8E7',
    'honey-light': '#F5DEB3',
    'mocha-medium': '#6B4423',
    'cinnamon-glow': '#C68642',
    'caramel-swirl': '#D4A574',
    'butter-toast': '#E6C9A8',
    'vintage-paper': '#FAF3E3',
    'kopi-black': '#2A1F16',
  },
  
  gradients: {
    sunrise: 'linear-gradient(135deg, #FFF8E7 0%, #F5DEB3 50%, #E8A857 100%)',
    warmGlow: 'radial-gradient(ellipse at center, rgba(232, 168, 87, 0.3) 0%, transparent 70%)',
    sunsetStripe: 'repeating-linear-gradient(-45deg, transparent, transparent 10px, rgba(212, 105, 59, 0.05) 10px, rgba(212, 105, 59, 0.05) 20px)',
  },
  
  textures: {
    grain: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 400 400\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'4\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")',
    sunburst: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 800 800\'%3E%3Cdefs%3E%3ClinearGradient id=\'sb\' x1=\'0%25\' y1=\'0%25\' x2=\'100%25\' y2=\'100%25\'%3E%3Cstop offset=\'0%25\' style=\'stop-color:%23E8A857;stop-opacity:0.15\'/%3E%3Cstop offset=\'100%25\' style=\'stop-color:%23D4693B;stop-opacity:0.08\'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cg fill=\'url(%23sb)\'%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(15 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(30 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(45 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(60 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(75 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(90 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(105 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(120 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(135 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(150 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(165 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(180 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(195 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(210 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(225 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(240 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(255 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(270 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(285 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(300 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(315 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(330 400 400)\'/%3E%3Cpath d=\'M400 0L420 380L400 400L380 380Z\' transform=\'rotate(345 400 400)\'/%3E%3C/g%3E%3C/svg%3E")',
    circles: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'100\' height=\'100\' viewBox=\'0 0 100 100\'%3E%3Ccircle cx=\'50\' cy=\'50\' r=\'40\' fill=\'none\' stroke=\'%23E8A857\' stroke-width=\'1\' opacity=\'0.1\'/%3E%3Ccircle cx=\'50\' cy=\'50\' r=\'30\' fill=\'none\' stroke=\'%23D4693B\' stroke-width=\'1\' opacity=\'0.08\'/%3E%3Ccircle cx=\'50\' cy=\'50\' r=\'20\' fill=\'none\' stroke=\'%23C68642\' stroke-width=\'1\' opacity=\'0.06\'/%3E%3C/svg%3E")',
    arcs: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'60\' height=\'60\' viewBox=\'0 0 60 60\'%3E%3Cpath d=\'M0 60 Q30 30 60 60\' fill=\'none\' stroke=\'%23E8A857\' stroke-width=\'2\' opacity=\'0.08\'/%3E%3C/svg%3E")',
  },
  
  fonts: {
    display: "'Fraunces', Georgia, serif",
    body: "'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif",
  },
  
  spacing: {
    1: '0.25rem',   /* 4px */
    2: '0.5rem',    /* 8px */
    3: '0.75rem',   /* 12px */
    4: '1rem',      /* 16px */
    5: '1.25rem',   /* 20px */
    6: '1.5rem',    /* 24px */
    8: '2rem',      /* 32px */
    10: '2.5rem',   /* 40px */
    12: '3rem',     /* 48px */
    16: '4rem',     /* 64px */
    20: '5rem',     /* 80px */
    24: '6rem',     /* 96px */
  },
  
  radii: {
    sm: '8px',
    md: '16px',
    lg: '24px',
    xl: '32px',
    '2xl': '48px',
    full: '9999px',
  },
  
  shadows: {
    sm: '0 2px 8px rgba(61, 43, 31, 0.08)',
    md: '0 4px 16px rgba(61, 43, 31, 0.12)',
    lg: '0 8px 32px rgba(61, 43, 31, 0.16)',
    glow: '0 0 40px rgba(232, 168, 87, 0.3)',
    button: '0 4px 0 var(--terracotta-warm)',
  },
  
  transitions: {
    ease: {
      smooth: 'cubic-bezier(0.23, 1, 0.32, 1)',
      bounce: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
    },
    duration: {
      fast: '0.15s',
      normal: '0.3s',
      slow: '0.5s',
    },
  },
  
  zIndex: {
    base: 1,
    sticky: 100,
    nav: 1000,
    overlay: 2000,
    modal: 3000,
    toast: 4000,
  },
} as const;

export type DesignToken = typeof designTokens;

export type ColorToken = keyof typeof designTokens.colors;
export type FontToken = keyof typeof designTokens.fonts;
export type SpacingToken = keyof typeof designTokens.spacing;
export type RadiusToken = keyof typeof designTokens.radii;
export type ShadowToken = keyof typeof designTokens.shadows;
export type ZIndexToken = keyof typeof designTokens.zIndex;