import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Merge Tailwind CSS classes with clsx support
 * @param inputs - Class values to merge
 * @returns Merged class string
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format price in Singapore Dollars (SGD)
 * @param amount - Price amount in dollars
 * @param options - Formatting options
 * @returns Formatted price string
 */
export function formatPrice(amount: number, options?: {
  currency?: string;
  minimumFractionDigits?: number;
  maximumFractionDigits?: number;
}): string {
  const {
    currency = 'SGD',
    minimumFractionDigits = 2,
    maximumFractionDigits = 2,
  } = options || {};

  return new Intl.NumberFormat('en-SG', {
    style: 'currency',
    currency,
    minimumFractionDigits,
    maximumFractionDigits,
  }).format(amount);
}

/**
 * Calculate GST (Goods and Services Tax) for Singapore
 * @param amount - Base amount before GST
 * @param rate - GST rate (default: 9%)
 * @returns GST amount
 */
export function calculateGST(amount: number, rate: number = 0.09): number {
  return Math.round((amount * rate) * 100) / 100;
}

/**
 * Calculate total amount including GST
 * @param amount - Base amount before GST
 * @param rate - GST rate (default: 9%)
 * @returns Total amount including GST
 */
export function calculateTotalWithGST(amount: number, rate: number = 0.09): number {
  return amount + calculateGST(amount, rate);
}

/**
 * Format date in Singapore timezone
 * @param date - Date to format
 * @param options - Formatting options
 * @returns Formatted date string
 */
export function formatDate(date: Date | string, options?: {
  format?: 'short' | 'medium' | 'long' | 'full';
  timeZone?: string;
}): string {
  const {
    format = 'medium',
    timeZone = 'Asia/Singapore',
  } = options || {};

  const dateObj = typeof date === 'string' ? new Date(date) : date;

  const formatOptions: Intl.DateTimeFormatOptions = {
    short: { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      timeZone,
    },
    medium: { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      timeZone,
    },
    long: { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric', 
      weekday: 'long',
      timeZone,
    },
    full: { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric', 
      weekday: 'long',
      hour: '2-digit',
      minute: '2-digit',
      timeZone,
    },
  };

  return new Intl.DateTimeFormat('en-SG', formatOptions[format]).format(dateObj);
}

/**
 * Debounce function calls
 * @param func - Function to debounce
 * @param wait - Wait time in milliseconds
 * @returns Debounced function
 */
export function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout;
  
  return (...args: Parameters<T>) => {
    clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

/**
 * Throttle function calls
 * @param func - Function to throttle
 * @param limit - Time limit in milliseconds
 * @returns Throttled function
 */
export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  
  return (...args: Parameters<T>) => {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => (inThrottle = false), limit);
    }
  };
}

/**
 * Generate a random ID
 * @param prefix - Optional prefix for the ID
 * @returns Random ID string
 */
export function generateId(prefix: string = 'id'): string {
  return `${prefix}-${Math.random().toString(36).substr(2, 9)}-${Date.now().toString(36)}`;
}

/**
 * Check if a value is empty (null, undefined, empty string, empty array, empty object)
 * @param value - Value to check
 * @returns True if empty, false otherwise
 */
export function isEmpty(value: any): boolean {
  if (value === null || value === undefined) return true;
  if (typeof value === 'string' && value.trim() === '') return true;
  if (Array.isArray(value) && value.length === 0) return true;
  if (typeof value === 'object' && Object.keys(value).length === 0) return true;
  return false;
}

/**
 * Deep clone an object
 * @param obj - Object to clone
 * @returns Cloned object
 */
export function deepClone<T>(obj: T): T {
  if (obj === null || typeof obj !== 'object') return obj;
  if (obj instanceof Date) return new Date(obj.getTime()) as unknown as T;
  if (obj instanceof Array) return obj.map(item => deepClone(item)) as unknown as T;
  if (typeof obj === 'object') {
    const clonedObj = {} as T;
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        clonedObj[key] = deepClone(obj[key]);
      }
    }
    return clonedObj;
  }
  return obj;
}

/**
 * Validate Singapore phone number format
 * @param phone - Phone number to validate
 * @returns True if valid, false otherwise
 */
export function isValidSingaporePhone(phone: string): boolean {
  // Singapore phone numbers: +65 6xxx xxxx, +65 8xxx xxxx, +65 9xxx xxxx
  const singaporePhoneRegex = /^\+65\s?(?:6|8|9)\d{3}\s?\d{4}$/;
  return singaporePhoneRegex.test(phone.replace(/\s/g, ''));
}

/**
 * Validate Singapore postal code
 * @param postalCode - Postal code to validate
 * @returns True if valid, false otherwise
 */
export function isValidSingaporePostalCode(postalCode: string): boolean {
  // Singapore postal codes: 6 digits
  const postalCodeRegex = /^\d{6}$/;
  return postalCodeRegex.test(postalCode);
}

/**
 * Local storage helper with error handling
 */
export const storage = {
  get: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (error) {
      console.warn(`Failed to get item from localStorage: ${key}`, error);
      return null;
    }
  },
  
  set: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (error) {
      console.warn(`Failed to set item in localStorage: ${key}`, error);
    }
  },
  
  remove: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.warn(`Failed to remove item from localStorage: ${key}`, error);
    }
  },
  
  clear: (): void => {
    try {
      localStorage.clear();
    } catch (error) {
      console.warn('Failed to clear localStorage', error);
    }
  },
};

/**
 * Session storage helper with error handling
 */
export const sessionStorage = {
  get: (key: string): string | null => {
    try {
      return window.sessionStorage.getItem(key);
    } catch (error) {
      console.warn(`Failed to get item from sessionStorage: ${key}`, error);
      return null;
    }
  },
  
  set: (key: string, value: string): void => {
    try {
      window.sessionStorage.setItem(key, value);
    } catch (error) {
      console.warn(`Failed to set item in sessionStorage: ${key}`, error);
    }
  },
  
  remove: (key: string): void => {
    try {
      window.sessionStorage.removeItem(key);
    } catch (error) {
      console.warn(`Failed to remove item from sessionStorage: ${key}`, error);
    }
  },
  
  clear: (): void => {
    try {
      window.sessionStorage.clear();
    } catch (error) {
      console.warn('Failed to clear sessionStorage', error);
    }
  },
};