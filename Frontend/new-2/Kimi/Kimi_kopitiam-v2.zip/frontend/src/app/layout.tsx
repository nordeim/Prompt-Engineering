import type { Metadata } from 'next';
import { Fraunces, DM_Sans } from 'next/font/google';
import './globals.css';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';
import { SkipLink } from '@/components/ui/skip-link';

const fraunces = Fraunces({
  subsets: ['latin'],
  variable: '--font-fraunces',
  display: 'swap',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-dm-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Morning Brew Collective - Where Singapore\'s Morning Ritual Begins',
  description: 'Singapore\'s authentic kopitiam experience since 1973. Traditional coffee, breakfast, and pastries with a modern touch.',
  keywords: ['kopitiam', 'singapore', 'coffee', 'breakfast', 'traditional', '1970s', 'vintage'],
  authors: [{ name: 'Morning Brew Collective' }],
  creator: 'Morning Brew Collective',
  publisher: 'Morning Brew Collective',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL('https://morningbrew.sg'),
  openGraph: {
    title: 'Morning Brew Collective - Authentic Singapore Kopitiam',
    description: 'Experience Singapore\'s authentic kopitiam culture since 1973.',
    url: 'https://morningbrew.sg',
    siteName: 'Morning Brew Collective',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Morning Brew Collective - Singapore Kopitiam',
      },
    ],
    locale: 'en_SG',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Morning Brew Collective',
    description: 'Singapore\'s authentic kopitiam experience since 1973.',
    images: ['/twitter-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'google-site-verification-code',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html 
      lang="en" 
      className={`${fraunces.variable} ${dmSans.variable}`}
      suppressHydrationWarning
    >
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link 
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,600;0,9..144,700;0,9..144,800;1,9..144,400&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap" 
          rel="stylesheet" 
        />
        <meta name="theme-color" content="#3D2B1F" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </head>
      <body>
        <SkipLink href="#main-content">Skip to main content</SkipLink>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main id="main-content" className="flex-grow">
            {children}
          </main>
          <Footer />
        </div>
      </body>
    </html>
  );
}