import { HeroStats } from '@/components/ui/hero-stats';
import { FloatingCoffeeCup } from '@/components/ui/floating-coffee-cup';
import { SteamRise } from '@/components/ui/steam-rise';
import { BeanBounce } from '@/components/ui/bean-bounce';
import { Button } from '@/components/ui/retro/button';
import Link from 'next/link';

export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <div className="hero__content">
            {/* Vintage Badge */}
            <div className="hero__badge">
              <svg className="hero__badge-icon" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
              </svg>
              <span>Since 1973</span>
            </div>

            {/* Hero Title */}
            <h1 className="hero__title">
              Where Singapore's
              <span className="hero__title-highlight">Morning Ritual</span>
              Begins
            </h1>

            {/* Hero Subtitle */}
            <p className="hero__subtitle">
              Experience the authentic taste of Singapore's heritage kopitiam culture. 
              Traditional coffee, kaya toast, and nostalgic flavors that have warmed hearts for generations.
            </p>

            {/* CTA Buttons */}
            <div className="hero__ctas">
              <Link href="/menu">
                <Button variant="primary" size="lg">
                  Order Now
                </Button>
              </Link>
              <Link href="/heritage">
                <Button variant="secondary" size="lg">
                  Our Story
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="hero__stats">
              <HeroStats />
            </div>
          </div>
        </div>

        {/* Floating Illustration */}
        <div className="hero__illustration">
          <FloatingCoffeeCup />
          <SteamRise />
        </div>

        {/* Decorative Elements */}
        <BeanBounce />
      </section>
    </>
  );
}