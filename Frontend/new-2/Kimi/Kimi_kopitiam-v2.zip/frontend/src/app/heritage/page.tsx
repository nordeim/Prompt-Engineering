import { PolaroidGallery } from '@/components/ui/polaroid-gallery';
import { AnimatedSection } from '@/components/ui/animated-section';

export default function HeritagePage() {
  return (
    <section className="heritage py-24">
      <div className="container">
        {/* Section Header */}
        <AnimatedSection className="section-header">
          <h2 className="section-header__title">Our Heritage</h2>
          <p className="section-header__subtitle">
            A journey through five decades of Singapore's kopitiam culture
          </p>
        </AnimatedSection>

        {/* Story Section */}
        <AnimatedSection className="story">
          <div className="story__image">
            <img 
              src="/heritage/coffee-master.jpg" 
              alt="Master coffee brewer at Morning Brew Collective"
              className="rounded-2xl shadow-lg"
            />
          </div>
          
          <div className="story__content">
            <h3 className="story__heading">A Legacy of Five Decades</h3>
            <div className="story__text">
              <p>
                In 1973, a young coffee roaster named Lim Ah Kow opened a small kopitiam 
                in Singapore's bustling Chinatown. With nothing but a traditional sock 
                filter and a passion for perfect coffee, he began what would become a 
                beloved institution.
              </p>
              <p>
                Today, Morning Brew Collective continues this legacy, serving the same 
                authentic kopi that has warmed the hearts of generations. Our coffee 
                beans are still roasted in small batches using the same time-honored 
                techniques passed down through our family.
              </p>
              <p>
                From early morning commuters to late-night students, from families 
                gathering for breakfast to friends catching up over teh tarik - our 
                kopitiam has been a witness to countless stories and memories.
              </p>
            </div>
          </div>
        </AnimatedSection>

        {/* Quote Section */}
        <AnimatedSection className="quote">
          <blockquote className="quote__text">
            "A good cup of kopi is not just about the taste. It's about the warmth, 
            the tradition, and the stories we share over it."
          </blockquote>
          <cite className="quote__author">— Lim Ah Kow, Founder (1920-2010)</cite>
        </AnimatedSection>

        {/* Values Section */}
        <AnimatedSection className="values">
          <h3 className="values__title">Our Values</h3>
          <div className="values__grid">
            <div className="value-card">
              <div className="value-card__icon">
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
              </div>
              <h4 className="value-card__title">Authenticity</h4>
              <p className="value-card__description">
                We preserve traditional recipes and brewing methods passed down through generations.
              </p>
            </div>
            
            <div className="value-card">
              <div className="value-card__icon">
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                </svg>
              </div>
              <h4 className="value-card__title">Community</h4>
              <p className="value-card__description">
                We believe in bringing people together over great food and coffee.
              </p>
            </div>
            
            <div className="value-card">
              <div className="value-card__icon">
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z" />
                </svg>
              </div>
              <h4 className="value-card__title">Quality</h4>
              <p className="value-card__description">
                We source only the finest ingredients to ensure every cup is perfect.
              </p>
            </div>
            
            <div className="value-card">
              <div className="value-card__icon">
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
              </div>
              <h4 className="value-card__title">Sustainability</h4>
              <p className="value-card__description">
                We are committed to environmentally responsible practices in all we do.
              </p>
            </div>
          </div>
        </AnimatedSection>

        {/* Polaroid Gallery */}
        <PolaroidGallery />
      </div>
    </section>
  );
}