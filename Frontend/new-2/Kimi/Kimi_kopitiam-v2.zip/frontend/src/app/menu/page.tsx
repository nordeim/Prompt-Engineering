import { ProductGrid } from '@/components/ui/product-grid';
import { FilterButtons } from '@/components/ui/filter-buttons';
import { AnimatedSection } from '@/components/ui/animated-section';

export default function MenuPage() {
  return (
    <section className="menu py-24">
      <div className="container">
        {/* Section Header */}
        <AnimatedSection className="section-header">
          <h2 className="section-header__title">Our Menu</h2>
          <p className="section-header__subtitle">
            Authentic Singaporean flavors crafted with love and tradition
          </p>
          <div className="section-header__decoration">
            <div className="section-header__line" />
            <svg className="section-header__icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
            </svg>
            <div className="section-header__line" />
          </div>
        </AnimatedSection>

        {/* Filter Buttons */}
        <FilterButtons />

        {/* Product Grid */}
        <ProductGrid />
      </div>
    </section>
  );
}