import { MapMarker } from '@/components/ui/map-marker';
import { AnimatedSection } from '@/components/ui/animated-section';
import { Clock, MapPin, Phone } from 'lucide-react';

const locations = [
  {
    id: '1',
    name: 'Chinatown Heritage Outlet',
    address: '123 Kopitiam Lane, Singapore 059413',
    phone: '+65 6123 4567',
    hours: 'Mon-Sun: 6AM - 10PM',
    features: ['Traditional Atmosphere', 'Heritage Decor', 'Outdoor Seating'],
    coordinates: { lat: 1.2833, lng: 103.8443 },
  },
  {
    id: '2',
    name: 'Marina Bay Modern',
    address: '456 Marina Boulevard, Singapore 018983',
    phone: '+65 6234 5678',
    hours: 'Mon-Sun: 7AM - 11PM',
    features: ['Modern Design', 'WiFi Available', 'Meeting Rooms'],
    coordinates: { lat: 1.2834, lng: 103.8607 },
  },
  {
    id: '3',
    name: 'Orchard Road Branch',
    address: '789 Orchard Road, Singapore 238877',
    phone: '+65 6345 6789',
    hours: 'Mon-Sun: 7AM - 10PM',
    features: ['Shopping District', 'Family Friendly', 'Parking Available'],
    coordinates: { lat: 1.3048, lng: 103.8318 },
  },
  {
    id: '4',
    name: 'Tiong Bahru Outlet',
    address: '321 Tiong Bahru Road, Singapore 168730',
    phone: '+65 6456 7890',
    hours: 'Mon-Sun: 6AM - 9PM',
    features: ['Artisan Coffee', 'Local Vibes', 'Pet Friendly'],
    coordinates: { lat: 1.2844, lng: 103.8267 },
  },
];

export default function LocationsPage() {
  return (
    <section className="locations py-24">
      <div className="container">
        {/* Section Header */}
        <AnimatedSection className="section-header">
          <h2 className="section-header__title">Our Locations</h2>
          <p className="section-header__subtitle">
            Find your nearest Morning Brew Collective outlet across Singapore
          </p>
        </AnimatedSection>

        {/* Map Section */}
        <AnimatedSection className="map-section">
          <div className="map-container">
            {/* Map Placeholder */}
            <div className="map-placeholder">
              <div className="map-placeholder__content">
                <MapMarker />
                <p className="map-placeholder__text">
                  Interactive map coming soon
                </p>
              </div>
            </div>
          </div>
        </AnimatedSection>

        {/* Location Cards */}
        <div className="locations-grid">
          {locations.map((location, index) => (
            <AnimatedSection key={location.id} className="location-card">
              <div className="location-card__header">
                <h3 className="location-card__title">{location.name}</h3>
              </div>
              
              <div className="location-card__info">
                <div className="location-card__detail">
                  <MapPin className="h-5 w-5 text-sunrise-amber" />
                  <span>{location.address}</span>
                </div>
                
                <div className="location-card__detail">
                  <Phone className="h-5 w-5 text-sunrise-amber" />
                  <a href={`tel:${location.phone}`}>{location.phone}</a>
                </div>
                
                <div className="location-card__detail">
                  <Clock className="h-5 w-5 text-sunrise-amber" />
                  <span>{location.hours}</span>
                </div>
              </div>
              
              <div className="location-card__features">
                {location.features.map((feature) => (
                  <span key={feature} className="location-card__feature">
                    {feature}
                  </span>
                ))}
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}