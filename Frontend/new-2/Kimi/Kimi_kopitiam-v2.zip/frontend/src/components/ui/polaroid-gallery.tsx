'use client';

import { AnimatedSection } from './animated-section';

const photos = [
  {
    id: '1',
    src: '/heritage/1970s-outlet.jpg',
    alt: 'Original outlet in 1973',
    caption: 'Our first outlet, 1973',
    rotation: -3,
  },
  {
    id: '2',
    src: '/heritage/founder.jpg',
    alt: 'Founder Lim Ah Kow',
    caption: 'Founder Lim Ah Kow',
    rotation: 2,
  },
  {
    id: '3',
    src: '/heritage/traditional-brewing.jpg',
    alt: 'Traditional coffee brewing',
    caption: 'Traditional brewing method',
    rotation: -2,
  },
  {
    id: '4',
    src: '/heritage/family.jpg',
    alt: 'Family gathering at kopitiam',
    caption: 'Family moments',
    rotation: 3,
  },
];

export function PolaroidGallery() {
  return (
    <AnimatedSection className="polaroid-gallery">
      <h3 className="polaroid-gallery__title">Memories Through Time</h3>
      
      <div className="polaroid-gallery__grid">
        {photos.map((photo, index) => (
          <div
            key={photo.id}
            className="polaroid-card"
            style={{
              transform: `rotate(${photo.rotation}deg)`,
              animationDelay: `${index * 100}ms`,
            }}
          >
            <div className="polaroid-card__image">
              <img 
                src={photo.src} 
                alt={photo.alt}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="polaroid-card__caption">
              {photo.caption}
            </div>
          </div>
        ))}
      </div>
    </AnimatedSection>
  );
}