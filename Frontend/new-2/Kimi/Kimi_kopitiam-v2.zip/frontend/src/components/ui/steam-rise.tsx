'use client';

export function SteamRise() {
  return (
    <div className="steam">
      <div className="steam__particle animate-steam-rise" />
      <div className="steam__particle animate-steam-rise" style={{ animationDelay: '0.3s' }} />
      <div className="steam__particle animate-steam-rise" style={{ animationDelay: '0.6s' }} />
    </div>
  );
}