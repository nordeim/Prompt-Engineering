'use client';

import { useEffect, useState } from 'react';

const stats = [
  { number: 50, label: 'Years of Heritage', suffix: '+' },
  { number: 100000, label: 'Happy Customers', suffix: '+' },
  { number: 15, label: 'Locations', suffix: '' },
];

export function HeroStats() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 300);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      {stats.map((stat, index) => (
        <div 
          key={stat.label} 
          className={`stat transition-all duration-500 ${
            isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
          }`}
          style={{ transitionDelay: `${index * 150}ms` }}
        >
          <span className="stat__number">
            {stat.number.toLocaleString()}{stat.suffix}
          </span>
          <span className="stat__label">{stat.label}</span>
        </div>
      ))}
    </>
  );
}