import Link from 'next/link';

interface SkipLinkProps {
  href: string;
  children: React.ReactNode;
}

export function SkipLink({ href, children }: SkipLinkProps) {
  return (
    <Link
      href={href}
      className="skip-link"
    >
      {children}
    </Link>
  );
}