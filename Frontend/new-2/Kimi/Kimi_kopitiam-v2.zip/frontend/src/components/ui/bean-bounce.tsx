'use client';

export function BeanBounce() {
  return (
    <div className="absolute bottom-10 left-10 flex gap-2">
      <div className="bean animate-bean-bounce" />
      <div className="bean animate-bean-bounce" style={{ animationDelay: '0.2s' }} />
      <div className="bean animate-bean-bounce" style={{ animationDelay: '0.4s' }} />
    </div>
  );
}