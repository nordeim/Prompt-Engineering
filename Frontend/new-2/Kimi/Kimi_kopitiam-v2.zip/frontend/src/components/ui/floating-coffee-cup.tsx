'use client';

export function FloatingCoffeeCup() {
  return (
    <svg 
      className="w-full h-full animate-gentle-float"
      viewBox="0 0 200 240" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Cup Body */}
      <path 
        d="M40 80 L40 180 Q40 200 60 200 L120 200 Q140 200 140 180 L140 80 Q140 60 120 60 L60 60 Q40 60 40 80 Z" 
        fill="#D4693B"
        stroke="#3D2B1F"
        strokeWidth="3"
      />
      
      {/* Coffee */}
      <ellipse 
        cx="90" 
        cy="85" 
        rx="45" 
        ry="8" 
        fill="#3D2B1F"
      />
      
      {/* Cup Handle */}
      <path 
        d="M140 100 Q160 100 160 120 Q160 140 140 140" 
        stroke="#D4693B"
        strokeWidth="12"
        strokeLinecap="round"
        fill="none"
      />
      
      {/* Cup Rim */}
      <ellipse 
        cx="90" 
        cy="75" 
        rx="50" 
        ry="10" 
        fill="#C68642"
        stroke="#3D2B1F"
        strokeWidth="2"
      />
      
      {/* Decorative Pattern */}
      <circle cx="55" cy="130" r="3" fill="#E8A857" />
      <circle cx="75" cy="140" r="3" fill="#E8A857" />
      <circle cx="105" cy="145" r="3" fill="#E8A857" />
      <circle cx="125" cy="135" r="3" fill="#E8A857" />
      
      {/* Saucer */}
      <ellipse 
        cx="90" 
        cy="215" 
        rx="70" 
        ry="12" 
        fill="#C68642"
        stroke="#3D2B1F"
        strokeWidth="2"
      />
      
      {/* Coffee Beans Decoration */}
      <g transform="translate(160, 160)">
        <ellipse cx="0" cy="0" rx="4" ry="6" fill="#6B4423" transform="rotate(-20)" />
        <line x1="-1" y1="-2" x2="1" y2="2" stroke="#3D2B1F" strokeWidth="1" />
      </g>
      <g transform="translate(170, 180)">
        <ellipse cx="0" cy="0" rx="4" ry="6" fill="#6B4423" transform="rotate(30)" />
        <line x1="-1" y1="-2" x2="1" y2="2" stroke="#3D2B1F" strokeWidth="1" />
      </g>
    </svg>
  );
}