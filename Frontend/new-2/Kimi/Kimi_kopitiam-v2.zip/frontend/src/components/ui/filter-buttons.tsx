'use client';

import { useFilterStore, PRODUCT_CATEGORIES } from '@/stores/filter-store';
import { cn } from '@/lib/utils';

export function FilterButtons() {
  const { activeCategory, setActiveCategory } = useFilterStore();

  return (
    <div className="filter-buttons">
      {PRODUCT_CATEGORIES.map((category) => (
        <button
          key={category.value}
          onClick={() => setActiveCategory(category.value)}
          className={cn(
            'filter-btn',
            activeCategory === category.value && 'filter-btn--active'
          )}
        >
          {category.label}
        </button>
      ))}
    </div>
  );
}