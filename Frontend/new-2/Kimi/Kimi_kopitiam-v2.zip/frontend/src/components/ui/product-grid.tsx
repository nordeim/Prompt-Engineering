'use client';

import { useCartStore } from '@/stores/cart-store';
import { useFilterStore } from '@/stores/filter-store';
import { formatPrice, calculateGST, calculateTotalWithGST } from '@/lib/utils';
import { Plus, Check } from 'lucide-react';
import { useState } from 'react';

// Mock products - in a real app, this would come from an API
const products = [
  {
    id: '1',
    name: 'Traditional Kopi-O',
    price: 2.50,
    category: 'coffee',
    description: 'Strong black coffee with sugar',
    imageUrl: '/products/kopi-o.jpg',
    isPopular: true,
  },
  {
    id: '2',
    name: 'Kopi-C',
    price: 3.00,
    category: 'coffee',
    description: 'Coffee with evaporated milk',
    imageUrl: '/products/kopi-c.jpg',
    isPopular: true,
  },
  {
    id: '3',
    name: 'Kaya Toast Set',
    price: 4.50,
    category: 'breakfast',
    description: 'Traditional kaya toast with soft-boiled eggs',
    imageUrl: '/products/kaya-toast.jpg',
    isPopular: true,
  },
  {
    id: '4',
    name: 'Teh Tarik',
    price: 2.80,
    category: 'beverages',
    description: 'Pulled tea with condensed milk',
    imageUrl: '/products/teh-tarik.jpg',
    isPopular: false,
  },
  {
    id: '5',
    name: 'Butter Croissant',
    price: 3.50,
    category: 'pastries',
    description: 'Flaky butter croissant',
    imageUrl: '/products/croissant.jpg',
    isPopular: false,
  },
  {
    id: '6',
    name: 'Soft-Boiled Eggs',
    price: 2.00,
    category: 'breakfast',
    description: 'Two soft-boiled eggs with soy sauce',
    imageUrl: '/products/soft-eggs.jpg',
    isPopular: false,
  },
];

export function ProductGrid() {
  const { items: cartItems } = useCartStore();
  const { activeCategory, searchQuery, sortBy } = useFilterStore();
  const [addedProductId, setAddedProductId] = useState<string | null>(null);
  const { addItem } = useCartStore();

  // Filter products by category
  const filteredProducts = products.filter((product) => {
    if (activeCategory === 'all') return true;
    return product.category === activeCategory;
  });

  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'name':
        return a.name.localeCompare(b.name);
      case 'price-asc':
        return a.price - b.price;
      case 'price-desc':
        return b.price - a.price;
      case 'popular':
      default:
        return (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0);
    }
  });

  const handleAddToCart = (product: typeof products[0]) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      category: product.category,
      imageUrl: product.imageUrl,
    });
    
    setAddedProductId(product.id);
    setTimeout(() => setAddedProductId(null), 1000);
  };

  const isInCart = (productId: string) => {
    return cartItems.some((item) => item.id === productId);
  };

  return (
    <div className="product-grid">
      {sortedProducts.map((product) => (
        <div key={product.id} className="product-card">
          <div className="product-card__image">
            <img 
              src={product.imageUrl} 
              alt={product.name}
              className="w-full h-full object-cover"
            />
            {product.isPopular && (
              <span className="product-card__badge">Popular</span>
            )}
          </div>
          
          <div className="product-card__content">
            <h3 className="product-card__title">{product.name}</h3>
            <p className="product-card__description">{product.description}</p>
            
            <div className="product-card__footer">
              <span className="product-card__price">
                {formatPrice(product.price)}
              </span>
              
              <button
                onClick={() => handleAddToCart(product)}
                className={cn(
                  'product-card__btn',
                  isInCart(product.id) && 'product-card__btn--in-cart'
                )}
                disabled={addedProductId === product.id}
              >
                {addedProductId === product.id ? (
                  <Check className="h-5 w-5" />
                ) : (
                  <Plus className="h-5 w-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}