export function MapMarker() {
  return (
    <svg 
      className="w-12 h-12 animate-marker-pulse"
      viewBox="0 0 24 24" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="12" cy="12" r="10" fill="#D4693B" fillOpacity="0.2" />
      <circle cx="12" cy="12" r="6" fill="#D4693B" />
      <circle cx="12" cy="12" r="3" fill="#E8A857" />
    </svg>
  );
}