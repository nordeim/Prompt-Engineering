import Link from 'next/link';
import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-espresso-dark text-cream-white py-16">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="logo">
              <span className="logo__main text-cream-white">Morning Brew</span>
              <span className="logo__sub">Collective</span>
            </div>
            <p className="text-cream-white/80 max-w-xs">
              Preserving Singapore's kopitiam heritage since 1973. 
              Where tradition meets modern comfort.
            </p>
            
            {/* Social Media */}
            <div className="flex space-x-4">
              <a href="#" className="text-sunrise-amber hover:text-coral-pop transition-colors" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-sunrise-amber hover:text-coral-pop transition-colors" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-sunrise-amber hover:text-coral-pop transition-colors" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-display font-bold text-lg text-sunrise-amber">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/menu" className="text-cream-white/80 hover:text-sunrise-amber transition-colors">
                  Our Menu
                </Link>
              </li>
              <li>
                <Link href="/heritage" className="text-cream-white/80 hover:text-sunrise-amber transition-colors">
                  Our Heritage
                </Link>
              </li>
              <li>
                <Link href="/locations" className="text-cream-white/80 hover:text-sunrise-amber transition-colors">
                  Locations
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-cream-white/80 hover:text-sunrise-amber transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="font-display font-bold text-lg text-sunrise-amber">Contact</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-sunrise-amber" />
                <span className="text-cream-white/80">
                  123 Kopitiam Lane<br />
                  Singapore 123456
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-sunrise-amber" />
                <a href="tel:+6561234567" className="text-cream-white/80 hover:text-sunrise-amber transition-colors">
                  +65 6123 4567
                </a>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-sunrise-amber" />
                <a href="mailto:hello@morningbrew.sg" className="text-cream-white/80 hover:text-sunrise-amber transition-colors">
                  hello@morningbrew.sg
                </a>
              </div>
            </div>
          </div>

          {/* Operating Hours */}
          <div className="space-y-4">
            <h3 className="font-display font-bold text-lg text-sunrise-amber">Opening Hours</h3>
            <div className="space-y-2 text-cream-white/80">
              <div>
                <p className="font-semibold">Monday - Friday</p>
                <p>6:00 AM - 10:00 PM</p>
              </div>
              <div>
                <p className="font-semibold">Saturday - Sunday</p>
                <p>6:00 AM - 11:00 PM</p>
              </div>
              <div>
                <p className="font-semibold">Public Holidays</p>
                <p>7:00 AM - 10:00 PM</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-sunrise-amber/30 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-cream-white/60 text-sm">
            © {currentYear} Morning Brew Collective. All rights reserved.
          </p>
          
          {/* Compliance Badges */}
          <div className="flex items-center space-x-4 text-cream-white/60 text-sm">
            <span className="bg-sunrise-amber/20 px-3 py-1 rounded-full">
              GST Registered
            </span>
            <span className="bg-sage-fresh/20 px-3 py-1 rounded-full">
              PDPA Compliant
            </span>
            <span className="bg-coral-pop/20 px-3 py-1 rounded-full">
              InvoiceNow Ready
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}