'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { ShoppingCart, Menu, X } from 'lucide-react';
import { useCartStore } from '@/stores/cart-store';
import { Button } from '@/components/ui/retro/button';

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { getItemCount } = useCartStore();

  const cartItemCount = getItemCount();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'auto';
    }

    return () => {
      document.body.style.overflow = 'auto';
    };
  }, [isMobileMenuOpen]);

  const navItems = [
    { href: '/', label: 'Home' },
    { href: '/menu', label: 'Menu' },
    { href: '/heritage', label: 'Heritage' },
    { href: '/locations', label: 'Locations' },
  ];

  return (
    <header 
      className={`header fixed top-0 left-0 right-0 z-nav transition-all duration-300 ${
        isScrolled ? 'bg-espresso-dark/95 backdrop-blur-md' : 'bg-espresso-dark/90'
      }`}
      role="banner"
    >
      <div className="container">
        <div className="header__inner">
          {/* Logo */}
          <Link href="/" className="logo">
            <span className="logo__main">Morning Brew</span>
            <span className="logo__sub">Collective</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="nav" role="navigation" aria-label="Main navigation">
            <ul className="nav__list">
              {navItems.map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="nav__link">
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          {/* Header Actions */}
          <div className="header__actions">
            <button
              className="cart-btn"
              aria-label={`Shopping cart, ${cartItemCount} items`}
            >
              <ShoppingCart className="h-6 w-6" />
              {cartItemCount > 0 && (
                <span className="cart-btn__count">{cartItemCount}</span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              className="menu-toggle lg:hidden"
              onClick={() => setIsMobileMenuOpen(true)}
              aria-expanded={isMobileMenuOpen}
              aria-controls="mobile-menu"
              aria-label="Open mobile menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="mobile-menu active" id="mobile-menu">
          <button
            className="mobile-menu__close"
            onClick={() => setIsMobileMenuOpen(false)}
            aria-label="Close mobile menu"
          >
            <X className="h-6 w-6" />
          </button>
          
          <nav role="navigation" aria-label="Mobile navigation">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="mobile-menu__link"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}