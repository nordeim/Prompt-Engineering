import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type ProductCategory = 'all' | 'coffee' | 'breakfast' | 'pastries' | 'beverages';

interface FilterState {
  activeCategory: ProductCategory;
  searchQuery: string;
  sortBy: 'name' | 'price-asc' | 'price-desc' | 'popular';
  
  // Actions
  setActiveCategory: (category: ProductCategory) => void;
  setSearchQuery: (query: string) => void;
  setSortBy: (sort: FilterState['sortBy']) => void;
  resetFilters: () => void;
}

const STORAGE_KEY = 'kopitiam-filters';

export const useFilterStore = create<FilterState>()(
  persist(
    (set) => ({
      activeCategory: 'all',
      searchQuery: '',
      sortBy: 'popular',

      setActiveCategory: (category) => {
        set({ activeCategory: category });
      },

      setSearchQuery: (query) => {
        set({ searchQuery: query });
      },

      setSortBy: (sort) => {
        set({ sortBy: sort });
      },

      resetFilters: () => {
        set({
          activeCategory: 'all',
          searchQuery: '',
          sortBy: 'popular',
        });
      },
    }),
    {
      name: STORAGE_KEY,
      partialize: (state) => ({
        activeCategory: state.activeCategory,
        sortBy: state.sortBy,
      }),
    }
  )
);

export const PRODUCT_CATEGORIES: { value: ProductCategory; label: string }[] = [
  { value: 'all', label: 'All Items' },
  { value: 'coffee', label: 'Coffee' },
  { value: 'breakfast', label: 'Breakfast' },
  { value: 'pastries', label: 'Pastries' },
  { value: 'beverages', label: 'Beverages' },
];

export const SORT_OPTIONS: { value: FilterState['sortBy']; label: string }[] = [
  { value: 'popular', label: 'Most Popular' },
  { value: 'name', label: 'Name (A-Z)' },
  { value: 'price-asc', label: 'Price (Low to High)' },
  { value: 'price-desc', label: 'Price (High to Low)' },
];