import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  category: string;
  imageUrl?: string;
}

export interface CartHistory {
  items: CartItem[];
  timestamp: number;
}

interface CartState {
  items: CartItem[];
  past: CartHistory[];
  future: CartHistory[];
  
  // Actions
  addItem: (item: Omit<CartItem, 'quantity'>) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  
  // Undo/Redo
  undo: () => void;
  redo: () => void;
  saveToHistory: () => void;
  
  // Getters
  getItemCount: () => number;
  getSubtotal: () => number;
  getGST: () => number;
  getTotal: () => number;
}

const GST_RATE = 0.09; // Singapore GST 9%
const STORAGE_KEY = 'kopitiam-cart';
const HISTORY_KEY = 'kopitiam-cart-history';
const MAX_HISTORY_LENGTH = 10;
const STORAGE_RETENTION_DAYS = 30;
const HISTORY_RETENTION_DAYS = 7;

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      past: [],
      future: [],

      // Add item to cart
      addItem: (item) => {
        const state = get();
        const existingItem = state.items.find((i) => i.id === item.id);

        state.saveToHistory();

        if (existingItem) {
          set({
            items: state.items.map((i) =>
              i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
            ),
          });
        } else {
          set({
            items: [...state.items, { ...item, quantity: 1 }],
          });
        }
      },

      // Remove item from cart
      removeItem: (id) => {
        const state = get();
        state.saveToHistory();

        set({
          items: state.items.filter((i) => i.id !== id),
        });
      },

      // Update item quantity
      updateQuantity: (id, quantity) => {
        const state = get();
        state.saveToHistory();

        if (quantity <= 0) {
          set({
            items: state.items.filter((i) => i.id !== id),
          });
        } else {
          set({
            items: state.items.map((i) =>
              i.id === id ? { ...i, quantity } : i
            ),
          });
        }
      },

      // Clear cart
      clearCart: () => {
        const state = get();
        state.saveToHistory();

        set({ items: [], future: [] });
      },

      // Save current state to history
      saveToHistory: () => {
        const state = get();
        const newHistory: CartHistory = {
          items: JSON.parse(JSON.stringify(state.items)), // Deep copy
          timestamp: Date.now(),
        };

        set({
          past: [newHistory, ...state.past].slice(0, MAX_HISTORY_LENGTH),
          future: [], // Clear future on new action
        });
      },

      // Undo last action
      undo: () => {
        const state = get();
        if (state.past.length === 0) return;

        const previous = state.past[0];
        const newPast = state.past.slice(1);

        set({
          items: previous.items,
          past: newPast,
          future: [
            { items: JSON.parse(JSON.stringify(state.items)), timestamp: Date.now() },
            ...state.future,
          ],
        });
      },

      // Redo last undone action
      redo: () => {
        const state = get();
        if (state.future.length === 0) return;

        const next = state.future[0];
        const newFuture = state.future.slice(1);

        set({
          items: next.items,
          past: [
            { items: JSON.parse(JSON.stringify(state.items)), timestamp: Date.now() },
            ...state.past,
          ],
          future: newFuture,
        });
      },

      // Get total item count
      getItemCount: () => {
        return get().items.reduce((sum, item) => sum + item.quantity, 0);
      },

      // Get subtotal (before GST)
      getSubtotal: () => {
        return get().items.reduce(
          (sum, item) => sum + item.price * item.quantity,
          0
        );
      },

      // Get GST amount
      getGST: () => {
        return Math.round(get().getSubtotal() * GST_RATE * 100) / 100;
      },

      // Get total (including GST)
      getTotal: () => {
        return get().getSubtotal() + get().getGST();
      },
    }),
    {
      name: STORAGE_KEY,
      partialize: (state) => ({
        items: state.items,
        past: state.past,
        future: state.future,
      }),
    }
  )
);

// Helper function to clear expired storage
export function clearExpiredStorage() {
  const now = Date.now();
  
  // Clear expired cart
  const cartData = localStorage.getItem(STORAGE_KEY);
  if (cartData) {
    try {
      const parsed = JSON.parse(cartData);
      const timestamp = parsed.state?.items?.[0]?.timestamp || parsed.state?.timestamp;
      if (timestamp && (now - timestamp) > STORAGE_RETENTION_DAYS * 24 * 60 * 60 * 1000) {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch (error) {
      console.warn('Failed to check cart storage expiration:', error);
    }
  }
  
  // Clear expired history
  const historyData = localStorage.getItem(HISTORY_KEY);
  if (historyData) {
    try {
      const parsed = JSON.parse(historyData);
      if (parsed.state?.past?.[0]?.timestamp && 
          (now - parsed.state.past[0].timestamp) > HISTORY_RETENTION_DAYS * 24 * 60 * 60 * 1000) {
        localStorage.removeItem(HISTORY_KEY);
      }
    } catch (error) {
      console.warn('Failed to check history storage expiration:', error);
    }
  }
}

// Initialize storage cleanup
if (typeof window !== 'undefined') {
  clearExpiredStorage();
}