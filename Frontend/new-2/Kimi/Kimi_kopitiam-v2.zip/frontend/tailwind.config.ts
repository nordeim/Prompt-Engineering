import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      // Custom colors from design tokens
      colors: {
        'sunrise-amber': {
          DEFAULT: '#E8A857',
          50: '#FFF8E7',
          100: '#F5DEB3',
          200: '#E8A857',
          300: '#D4A574',
          400: '#C68642',
        },
        'terracotta-warm': {
          DEFAULT: '#D4693B',
          50: '#FAF3E3',
          100: '#E6C9A8',
          200: '#D4693B',
          300: '#C68642',
          400: '#6B4423',
        },
        'espresso-dark': {
          DEFAULT: '#3D2B1F',
          50: '#FAF3E3',
          100: '#FFF8E7',
          200: '#F5DEB3',
          300: '#3D2B1F',
          400: '#2A1F16',
        },
        'coral-pop': {
          DEFAULT: '#FF7B54',
          50: '#FFF5F2',
          100: '#FFE8E1',
          200: '#FF7B54',
          300: '#E86A45',
          400: '#D45D3A',
        },
        'sage-fresh': {
          DEFAULT: '#8FA68A',
          50: '#F4F6F3',
          100: '#E8EBE7',
          200: '#8FA68A',
          300: '#7A9475',
          400: '#6B8267',
        },
        'cream-white': '#FFF8E7',
        'honey-light': '#F5DEB3',
        'mocha-medium': '#6B4423',
        'cinnamon-glow': '#C68642',
        'caramel-swirl': '#D4A574',
        'butter-toast': '#E6C9A8',
        'vintage-paper': '#FAF3E3',
        'kopi-black': '#2A1F16',
      },
      
      // Custom font families
      fontFamily: {
        'display': ['Fraunces', 'Georgia', 'serif'],
        'body': ['DM Sans', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
      },
      
      // Custom spacing (8px grid)
      spacing: {
        '1': '0.25rem',    // 4px
        '2': '0.5rem',     // 8px
        '3': '0.75rem',    // 12px
        '4': '1rem',       // 16px
        '5': '1.25rem',    // 20px
        '6': '1.5rem',     // 24px
        '8': '2rem',       // 32px
        '10': '2.5rem',    // 40px
        '12': '3rem',      // 48px
        '16': '4rem',      // 64px
        '20': '5rem',      // 80px
        '24': '6rem',      // 96px
      },
      
      // Custom border radius (very 70s - rounded!)
      borderRadius: {
        'sm': '8px',
        'md': '16px',
        'lg': '24px',
        'xl': '32px',
        '2xl': '48px',
        'full': '9999px',
      },
      
      // Custom shadows (warm-tinted)
      boxShadow: {
        'sm': '0 2px 8px rgba(61, 43, 31, 0.08)',
        'md': '0 4px 16px rgba(61, 43, 31, 0.12)',
        'lg': '0 8px 32px rgba(61, 43, 31, 0.16)',
        'glow': '0 0 40px rgba(232, 168, 87, 0.3)',
        'button': '0 4px 0 var(--terracotta-warm)',
      },
      
      // Custom animations
      animation: {
        'slow-rotate': 'slowRotate 120s linear infinite',
        'bean-bounce': 'beanBounce 2s ease-in-out infinite',
        'steam-rise': 'steamRise 2s ease-in-out infinite',
        'gentle-float': 'gentleFloat 6s ease-in-out infinite',
        'marker-pulse': 'markerPulse 2s ease-in-out infinite',
        'fade-in': 'fadeIn 0.5s ease-out forwards',
      },
      
      // Custom keyframes
      keyframes: {
        slowRotate: {
          '0%': { transform: 'translateX(-50%) rotate(0deg)' },
          '100%': { transform: 'translateX(-50%) rotate(360deg)' },
        },
        beanBounce: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-8px)' },
        },
        steamRise: {
          '0%': { opacity: '0', transform: 'translateY(0) scale(1)' },
          '50%': { opacity: '1' },
          '100%': { opacity: '0', transform: 'translateY(-30px) scale(0.5)' },
        },
        gentleFloat: {
          '0%, 100%': { transform: 'translateY(0) rotate(0deg)' },
          '50%': { transform: 'translateY(-20px) rotate(3deg)' },
        },
        markerPulse: {
          '0%, 100%': { transform: 'scale(1)' },
          '50%': { transform: 'scale(1.1)' },
        },
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      
      // Custom transitions
      transitionTimingFunction: {
        'smooth': 'cubic-bezier(0.23, 1, 0.32, 1)',
        'bounce': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
      },
      
      transitionDuration: {
        'fast': '0.15s',
        'normal': '0.3s',
        'slow': '0.5s',
      },
      
      // Custom z-index
      zIndex: {
        'base': '1',
        'sticky': '100',
        'nav': '1000',
        'overlay': '2000',
        'modal': '3000',
        'toast': '4000',
      },
    },
  },
  plugins: [],
};

export default config;