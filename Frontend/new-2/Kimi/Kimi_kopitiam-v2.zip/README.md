# ☕ Morning Brew Collective

**Singapore's authentic kopitiam experience, digitally reimagined for the modern era.**

A high-fidelity e-commerce platform that resurrects Singapore's 1970s coffee shop culture with avant-garde minimalist design and enterprise-grade regulatory compliance.

## 🏗️ Architecture

**Backend-for-Frontend (BFF) Pattern:**
- **Frontend**: Next.js 15 App Router + React 19 (UX Orchestration)
- **Backend**: Laravel 12 + PHP 8.3 (Domain Truth)
- **Database**: PostgreSQL 16 (Financial Precision)
- **Cache**: Redis 7 (Atomic Operations)
- **Infrastructure**: Docker Compose + Nginx

## 🚀 Quick Start

### Prerequisites
- Docker and Docker Compose
- Make (optional, for convenience commands)

### Development Setup

1. **Clone and start the project:**
   ```bash
   make fresh
   ```

2. **Or manually:**
   ```bash
   # Start services
   docker-compose up -d
   
   # Install dependencies
   make install
   
   # Run migrations and seeders
   make migrate
   make seed
   ```

3. **Access the application:**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - Mailpit (Email Testing): http://localhost:8025

### Available Commands

```bash
make help          # Show all available commands
make up            # Start all services
make down          # Stop all services
make logs          # Show logs from all services
make test          # Run all tests
make lint          # Run all linters
make clean         # Remove all containers and volumes
make fresh         # Complete fresh installation
```

## 🎨 Design System

The platform follows a **"Sunrise at the Kopitiam"** aesthetic:

- **Colors**: Sunrise amber, terracotta warmth, espresso dark, cream white
- **Typography**: Fraunces (display), DM Sans (body)
- **Animations**: Gentle float, bean bounce, steam rise, sunburst rotation
- **Patterns**: Retro textures, decorative SVG patterns, vintage grain

## 🇸🇬 Singapore Compliance

### GST (9%)
- All prices stored as `DECIMAL(10,4)` for audit precision
- Automatic GST calculation with 4 decimal places
- IRAS-compliant invoice generation

### PayNow Integration
- Stripe-powered PayNow QR code generation
- Real-time payment status tracking
- Webhook-based order confirmation

### InvoiceNow (PEPPOL)
- UBL 2.1 XML generation
- IMDA-compliant e-invoicing
- Automatic submission to PEPPOL network

### PDPA Compliance
- Pseudonymized customer data (SHA256)
- Granular consent tracking
- Audit trail for all data processing
- 7-year retention policy

## 🔧 Development Workflow

### Code Standards
- **Frontend**: TypeScript strict mode, ESLint, Prettier
- **Backend**: PSR-12, Laravel Pint, Pest testing
- **Git**: Conventional commits, feature branches

### Testing Strategy
- **Unit Tests**: Vitest (frontend), Pest (backend)
- **E2E Tests**: Playwright
- **Visual Regression**: Percy
- **Performance**: Lighthouse CI
- **Accessibility**: axe-core (WCAG AAA)

### Database Migrations
```bash
# Create migration
docker-compose exec backend php artisan make:migration create_products_table

# Run migrations
make migrate

# Rollback last migration
docker-compose exec backend php artisan migrate:rollback
```

## 📁 Project Structure

```
morning-brew-collective/
├── frontend/           # Next.js application
│   ├── src/
│   │   ├── app/       # App Router pages
│   │   ├── components/# React components
│   │   ├── lib/       # Utilities and helpers
│   │   └── stores/    # Zustand state stores
│   ├── public/        # Static assets
│   └── package.json
├── backend/           # Laravel application
│   ├── app/
│   │   ├── Http/      # Controllers and requests
│   │   ├── Models/    # Eloquent models
│   │   └── Services/  # Business logic
│   ├── database/      # Migrations and seeders
│   └── routes/        # API routes
├── infra/             # Infrastructure scripts
├── nginx/             # Nginx configuration
├── scripts/           # Utility scripts
└── docs/              # Documentation
```

## 🔐 Security

- **Authentication**: Laravel Sanctum
- **Authorization**: Spatie Permissions
- **Rate Limiting**: Nginx + Laravel
- **Input Validation**: Form requests
- **SQL Injection**: Eloquent ORM protection
- **XSS Protection**: React auto-escaping

## 📊 Monitoring

- **Application Monitoring**: Laravel Horizon
- **Queue Monitoring**: Redis + Horizon Dashboard
- **Error Tracking**: Laravel Log Viewer
- **Performance**: Laravel Telescope (development)

## 🚀 Deployment

### Production Build
```bash
make build
```

### Environment Configuration
Copy `.env.example` to `.env` and configure:
- Database credentials
- Stripe keys (live mode)
- InvoiceNow credentials
- PDPA salt

### SSL Configuration
Place SSL certificates in `nginx/ssl/`:
- `fullchain.pem`
- `privkey.pem`

## 🧪 Testing

### Run All Tests
```bash
make test
```

### Specific Test Suites
```bash
# Backend tests
docker-compose exec backend vendor/bin/pest

# Frontend tests
docker-compose exec frontend npm test

# E2E tests
docker-compose exec frontend npm run test:e2e
```

## 📚 Documentation

- [Design System](./docs/design-system.md)
- [API Documentation](./docs/api-documentation.md)
- [Deployment Guide](./docs/deployment.md)
- [Compliance Guide](./docs/compliance.md)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'feat: add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Design Inspiration**: 1970s Singapore kopitiam culture
- **Typography**: Google Fonts (Fraunces, DM Sans)
- **Icons**: Lucide React
- **Patterns**: Decorative SVG textures from various sources

---

**Morning Brew Collective** - Where Singapore's morning ritual begins. ☕