-- PostgreSQL Initialization Script for Morning Brew Collective
-- Creates necessary extensions for UUID generation and cryptographic functions

-- Enable UUID generation extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable cryptographic functions extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create database user with appropriate permissions
-- This is handled by Docker environment variables, but we can add additional setup here

-- Set timezone to Singapore
SET timezone = 'Asia/Singapore';

-- Grant necessary permissions (these are typically handled by Docker)
-- GRANT ALL PRIVILEGES ON DATABASE morning_brew TO laravel;

-- Note: Additional schema setup will be handled by Laravel migrations