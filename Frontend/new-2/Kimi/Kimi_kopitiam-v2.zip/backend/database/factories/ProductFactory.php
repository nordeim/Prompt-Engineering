<?php

namespace Database\Factories;

use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductFactory extends Factory
{
    protected $model = Product::class;

    public function definition(): array
    {
        $categories = ['coffee', 'breakfast', 'pastries', 'beverages'];
        $category = $this->faker->randomElement($categories);
        
        $names = [
            'coffee' => ['Traditional Kopi-O', 'Kopi-C', 'Kopi Siew Dai', 'Kopi Ga Dai', 'Espresso', 'Latte', 'Cappuccino'],
            'breakfast' => ['Kaya Toast Set', 'Soft-Boiled Eggs', 'Mee Siam', 'Nasi Lemak', 'Chee Cheong Fun'],
            'pastries' => ['Butter Croissant', 'Kaya Puff', 'Egg Tart', 'Pineapple Tart', 'Butter Cake'],
            'beverages' => ['Teh Tarik', 'Milo Dinosaur', 'Barley Drink', 'Lemon Tea', 'Iced Coffee'],
        ];
        
        $name = $this->faker->randomElement($names[$category]);
        
        return [
            'name' => $name,
            'description' => $this->faker->sentence(),
            'price_cents' => $this->faker->numberBetween(200, 1500),
            'category' => $category,
            'image_url' => $this->faker->imageUrl(400, 300, 'food', true),
            'is_active' => true,
            'is_popular' => $this->faker->boolean(30),
            'stock_quantity' => $this->faker->numberBetween(10, 100),
            'sku' => 'MB' . strtoupper(substr(uniqid(), -6)),
        ];
    }

    public function coffee(): static
    {
        return $this->state(fn (array $attributes) => [
            'category' => 'coffee',
            'name' => $this->faker->randomElement(['Traditional Kopi-O', 'Kopi-C', 'Kopi Siew Dai', 'Espresso', 'Latte']),
        ]);
    }

    public function breakfast(): static
    {
        return $this->state(fn (array $attributes) => [
            'category' => 'breakfast',
            'name' => $this->faker->randomElement(['Kaya Toast Set', 'Soft-Boiled Eggs', 'Mee Siam', 'Nasi Lemak']),
        ]);
    }

    public function popular(): static
    {
        return $this->state(fn (array $attributes) => [
            'is_popular' => true,
        ]);
    }

    public function outOfStock(): static
    {
        return $this->state(fn (array $attributes) => [
            'stock_quantity' => 0,
        ]);
    }
}