<?php

namespace Database\Factories;

use App\Models\Location;
use Illuminate\Database\Eloquent\Factories\Factory;

class LocationFactory extends Factory
{
    protected $model = Location::class;

    public function definition(): array
    {
        $names = [
            'Chinatown Heritage Outlet',
            'Marina Bay Modern',
            'Orchard Road Branch',
            'Tiong Bahru Outlet',
            'Bugis Junction Store',
            'Sentosa Island Cafe',
            'Changi Airport T3',
            'Jurong East Hub',
        ];

        $features = [
            ['Traditional Atmosphere', 'Heritage Decor'],
            ['Modern Design', 'WiFi Available', 'Meeting Rooms'],
            ['Shopping District', 'Family Friendly'],
            ['Artisan Coffee', 'Local Vibes', 'Pet Friendly'],
            ['Central Location', 'Outdoor Seating'],
            ['Tourist Friendly', 'Sea View'],
            ['24/7 Service', 'Travel Friendly'],
            ['Community Hub', 'Event Space'],
        ];

        $operatingHours = [
            'monday' => ['open' => '06:00', 'close' => '22:00'],
            'tuesday' => ['open' => '06:00', 'close' => '22:00'],
            'wednesday' => ['open' => '06:00', 'close' => '22:00'],
            'thursday' => ['open' => '06:00', 'close' => '22:00'],
            'friday' => ['open' => '06:00', 'close' => '23:00'],
            'saturday' => ['open' => '07:00', 'close' => '23:00'],
            'sunday' => ['open' => '07:00', 'close' => '22:00'],
        ];

        return [
            'name' => $this->faker->randomElement($names),
            'address' => $this->faker->streetAddress() . ', Singapore ' . $this->faker->postcode(),
            'postal_code' => $this->faker->postcode(),
            'phone' => '+65' . $this->faker->numberBetween(60000000, 99999999),
            'email' => $this->faker->optional()->email(),
            'latitude' => $this->faker->latitude(1.2, 1.5),
            'longitude' => $this->faker->longitude(103.6, 104.0),
            'operating_hours' => $operatingHours,
            'features' => $this->faker->randomElements($features[$this->faker->numberBetween(0, 7)], $this->faker->numberBetween(1, 3)),
            'is_active' => true,
            'capacity' => $this->faker->numberBetween(30, 150),
        ];
    }

    public function inactive(): static
    {
        return $this->state(fn (array $attributes) => [
            'is_active' => false,
        ]);
    }

    public function withExtendedHours(): static
    {
        return $this->state(fn (array $attributes) => [
            'operating_hours' => [
                'monday' => ['open' => '05:00', 'close' => '23:00'],
                'tuesday' => ['open' => '05:00', 'close' => '23:00'],
                'wednesday' => ['open' => '05:00', 'close' => '23:00'],
                'thursday' => ['open' => '05:00', 'close' => '23:00'],
                'friday' => ['open' => '05:00', 'close' => '24:00'],
                'saturday' => ['open' => '06:00', 'close' => '24:00'],
                'sunday' => ['open' => '06:00', 'close' => '23:00'],
            ],
        ]);
    }
}