<?php

namespace Database\Factories;

use App\Models\Order;
use App\Models\Location;
use Illuminate\Database\Eloquent\Factories\Factory;

class OrderFactory extends Factory
{
    protected $model = Order::class;

    public function definition(): array
    {
        $pickupLocation = Location::inRandomOrder()->first() ?? Location::factory()->create();
        $subtotal = $this->faker->numberBetween(500, 5000); // $5 to $50
        $gstRate = 0.09; // Singapore GST 9%
        $gst = (int) round($subtotal * $gstRate);
        $total = $subtotal + $gst;

        return [
            'order_number' => Order::generateOrderNumber(),
            'customer_name' => $this->faker->name(),
            'customer_email' => $this->faker->email(),
            'customer_phone' => '+65' . $this->faker->numberBetween(80000000, 99999999),
            'customer_pseudonym' => hash('sha256', $this->faker->email() . config('app.pdpa_salt', 'morning_brew_default_salt')),
            'pickup_location_id' => $pickupLocation->id,
            'pickup_datetime' => now()->addHours($this->faker->numberBetween(1, 48)),
            'subtotal_cents' => $subtotal,
            'gst_cents' => $gst,
            'total_cents' => $total,
            'status' => $this->faker->randomElement([
                Order::STATUS_PENDING,
                Order::STATUS_CONFIRMED,
                Order::STATUS_PREPARING,
                Order::STATUS_COMPLETED,
            ]),
            'payment_status' => $this->faker->randomElement([
                Order::PAYMENT_PENDING,
                Order::PAYMENT_PAID,
            ]),
            'payment_method' => $this->faker->randomElement(['paynow', 'credit_card', 'cash']),
            'notes' => $this->faker->optional()->sentence(),
        ];
    }

    public function pending(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => Order::STATUS_PENDING,
            'payment_status' => Order::PAYMENT_PENDING,
        ]);
    }

    public function confirmed(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => Order::STATUS_CONFIRMED,
            'payment_status' => Order::PAYMENT_PAID,
        ]);
    }

    public function completed(): static
    {
        return $this->state(fn (array $attributes) => [
            'status' => Order::STATUS_COMPLETED,
            'payment_status' => Order::PAYMENT_PAID,
        ]);
    }

    public function paid(): static
    {
        return $this->state(fn (array $attributes) => [
            'payment_status' => Order::PAYMENT_PAID,
        ]);
    }

    public function withStripePayment(): static
    {
        return $this->state(fn (array $attributes) => [
            'stripe_payment_intent_id' => 'pi_' . str()->random(24),
            'payment_method' => 'credit_card',
        ]);
    }
}