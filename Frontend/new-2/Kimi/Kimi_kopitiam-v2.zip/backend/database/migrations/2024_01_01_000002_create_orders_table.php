<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('order_number')->unique();
            $table->string('customer_name');
            $table->string('customer_email');
            $table->string('customer_phone');
            $table->string('customer_pseudonym'); // SHA256 hash for PDPA compliance
            $table->uuid('pickup_location_id');
            $table->dateTime('pickup_datetime');
            
            // Financial fields stored in cents for precision
            $table->integer('subtotal_cents');
            $table->integer('gst_cents');
            $table->integer('total_cents');
            
            $table->enum('status', [
                'pending',
                'confirmed',
                'preparing',
                'ready',
                'completed',
                'cancelled'
            ])->default('pending');
            
            $table->enum('payment_status', [
                'pending',
                'paid',
                'failed',
                'refunded'
            ])->default('pending');
            
            $table->enum('payment_method', [
                'paynow',
                'credit_card',
                'cash'
            ]);
            
            $table->string('payment_reference')->nullable();
            $table->string('stripe_payment_intent_id')->nullable();
            
            // InvoiceNow fields
            $table->string('invoice_number')->nullable();
            $table->boolean('invoice_sent')->default(false);
            
            $table->text('notes')->nullable();
            $table->timestamps();
            
            // Indexes
            $table->index('order_number');
            $table->index('customer_email');
            $table->index('status');
            $table->index('payment_status');
            $table->index('pickup_datetime');
            $table->index(['created_at', 'status']);
            
            // Foreign keys
            $table->foreign('pickup_location_id')
                  ->references('id')
                  ->on('locations')
                  ->onDelete('restrict');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};