<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pdpa_consents', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('order_id')->nullable();
            $table->string('customer_email');
            $table->string('customer_pseudonym'); // SHA256 hash
            $table->enum('consent_type', [
                'marketing',
                'order_processing',
                'account_creation'
            ]);
            $table->boolean('consent_given');
            $table->dateTime('consent_timestamp');
            $table->string('ip_address');
            $table->text('user_agent')->nullable();
            $table->string('wording_hash'); // Hash of consent wording for audit
            $table->string('consent_version');
            $table->dateTime('withdrawn_at')->nullable();
            $table->timestamps();
            
            // Indexes
            $table->index('order_id');
            $table->index('customer_pseudonym');
            $table->index('consent_type');
            $table->index('consent_given');
            $table->index('consent_timestamp');
            $table->index(['customer_pseudonym', 'consent_type']);
            
            // Foreign keys
            $table->foreign('order_id')
                  ->references('id')
                  ->on('orders')
                  ->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('pdpa_consents');
    }
};