<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Product;
use App\Models\Location;
use App\Models\Order;
use App\Models\OrderItem;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create locations
        $locations = Location::factory()->count(5)->create();
        
        // Create products
        $products = Product::factory()->count(20)->create();
        
        // Create some orders
        $orders = Order::factory()->count(50)->create();
        
        // Create order items for each order
        foreach ($orders as $order) {
            $itemCount = rand(1, 5);
            $selectedProducts = $products->random($itemCount);
            
            foreach ($selectedProducts as $product) {
                $quantity = rand(1, 3);
                $totalCents = $product->price_cents * $quantity;
                
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $product->id,
                    'product_name' => $product->name,
                    'product_price_cents' => $product->price_cents,
                    'quantity' => $quantity,
                    'total_cents' => $totalCents,
                ]);
            }
            
            // Recalculate order totals
            $order->refresh();
            $subtotal = $order->orderItems->sum('total_cents');
            $order->setSubtotal($subtotal / 100);
            $order->save();
        }
        
        $this->command->info('Database seeded successfully!');
        $this->command->info('Created: ');
        $this->command->info('- ' . $locations->count() . ' locations');
        $this->command->info('- ' . $products->count() . ' products');
        $this->command->info('- ' . $orders->count() . ' orders');
    }
}