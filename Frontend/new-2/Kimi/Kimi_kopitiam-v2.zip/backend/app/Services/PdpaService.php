<?php

namespace App\Services;

use App\Models\PdpaConsent;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class PdpaService
{
    /**
     * Record customer consent.
     */
    public function recordConsent(
        string $email,
        string $consentType,
        bool $given,
        ?string $orderId = null,
        ?string $ipAddress = null,
        ?string $userAgent = null,
        ?string $wording = null
    ): PdpaConsent {
        $pseudonym = $this->generatePseudonym($email);
        
        // Use default wording if not provided
        if (!$wording) {
            $wording = $this->getDefaultWording($consentType);
        }

        $consent = PdpaConsent::create([
            'order_id' => $orderId,
            'customer_email' => $email,
            'customer_pseudonym' => $pseudonym,
            'consent_type' => $consentType,
            'consent_given' => $given,
            'consent_timestamp' => now('Asia/Singapore'),
            'ip_address' => $ipAddress ?? request()->ip(),
            'user_agent' => $userAgent ?? request()->userAgent(),
            'wording_hash' => $this->hashWording($wording),
            'consent_version' => config('app.pdpa_consent_version', '1.0'),
        ]);

        Log::info('PDPA consent recorded', [
            'consent_id' => $consent->id,
            'email_hash' => $pseudonym,
            'consent_type' => $consentType,
            'given' => $given,
        ]);

        return $consent;
    }

    /**
     * Check if customer has given consent.
     */
    public function hasConsent(string $email, string $consentType): bool
    {
        $pseudonym = $this->generatePseudonym($email);
        
        return PdpaConsent::valid()
            ->byType($consentType)
            ->where('customer_pseudonym', $pseudonym)
            ->exists();
    }

    /**
     * Withdraw customer consent.
     */
    public function withdrawConsent(string $email, string $consentType): bool
    {
        $pseudonym = $this->generatePseudonym($email);
        
        $consents = PdpaConsent::valid()
            ->byType($consentType)
            ->where('customer_pseudonym', $pseudonym)
            ->get();

        foreach ($consents as $consent) {
            $consent->withdraw();
        }

        Log::info('PDPA consent withdrawn', [
            'email_hash' => $pseudonym,
            'consent_type' => $consentType,
            'withdrawn_count' => $consents->count(),
        ]);

        return true;
    }

    /**
     * Export customer data (GDPR/PDPA compliance).
     */
    public function exportCustomerData(string $email): array
    {
        $pseudonym = $this->generatePseudonym($email);
        
        $consents = PdpaConsent::where('customer_pseudonym', $pseudonym)
            ->orderBy('created_at', 'desc')
            ->get();

        $orders = [];
        foreach ($consents as $consent) {
            if ($consent->order) {
                $orders[] = [
                    'order_number' => $consent->order->order_number,
                    'created_at' => $consent->order->created_at->toIso8601String(),
                    'status' => $consent->order->status,
                    'total' => $consent->order->total,
                ];
            }
        }

        return [
            'email' => $email,
            'email_hash' => $pseudonym,
            'consents' => $consents->map(function ($consent) {
                return [
                    'type' => $consent->consent_type,
                    'given' => $consent->consent_given,
                    'timestamp' => $consent->consent_timestamp->toIso8601String(),
                    'version' => $consent->consent_version,
                    'withdrawn_at' => $consent->withdrawn_at?->toIso8601String(),
                ];
            }),
            'orders' => $orders,
            'exported_at' => now('Asia/Singapore')->toIso8601String(),
        ];
    }

    /**
     * Delete customer data (GDPR/PDPA compliance).
     */
    public function deleteCustomerData(string $email): bool
    {
        $pseudonym = $this->generatePseudonym($email);
        
        // Get all consents for this customer
        $consents = PdpaConsent::where('customer_pseudonym', $pseudonym)->get();
        
        // Anonymize the data
        foreach ($consents as $consent) {
            $consent->customer_email = 'deleted@anonymous.local';
            $consent->ip_address = '0.0.0.0';
            $consent->user_agent = null;
            $consent->save();
        }
        
        Log::info('Customer data anonymized', [
            'email_hash' => $pseudonym,
            'consent_count' => $consents->count(),
        ]);
        
        return true;
    }

    /**
     * Generate pseudonym for email.
     */
    public function generatePseudonym(string $email): string
    {
        $salt = config('app.pdpa_salt', 'morning_brew_default_salt');
        return hash('sha256', strtolower(trim($email)) . $salt);
    }

    /**
     * Hash consent wording.
     */
    public function hashWording(string $wording): string
    {
        return hash('sha256', trim($wording));
    }

    /**
     * Get default consent wording.
     */
    private function getDefaultWording(string $consentType): string
    {
        return match ($consentType) {
            PdpaConsent::TYPE_MARKETING => 
                'I consent to receive marketing communications from Morning Brew Collective.',
            PdpaConsent::TYPE_ORDER_PROCESSING => 
                'I consent to the processing of my personal data for order fulfillment.',
            PdpaConsent::TYPE_ACCOUNT_CREATION => 
                'I consent to the creation of an account with Morning Brew Collective.',
            default => 
                'I consent to the processing of my personal data.',
        };
    }

    /**
     * Check if consent wording has changed.
     */
    public function hasWordingChanged(string $consentType, string $wording): bool
    {
        $defaultWording = $this->getDefaultWording($consentType);
        $currentHash = $this->hashWording($wording);
        $defaultHash = $this->hashWording($defaultWording);
        
        return $currentHash !== $defaultHash;
    }

    /**
     * Get consent statistics.
     */
    public function getConsentStatistics(): array
    {
        $types = PdpaConsent::getConsentTypes();
        $stats = [];
        
        foreach ($types as $type => $label) {
            $total = PdpaConsent::byType($type)->count();
            $given = PdpaConsent::valid()->byType($type)->count();
            $withdrawn = PdpaConsent::byType($type)->whereNotNull('withdrawn_at')->count();
            
            $stats[$type] = [
                'label' => $label,
                'total' => $total,
                'given' => $given,
                'withdrawn' => $withdrawn,
                'rate' => $total > 0 ? round(($given / $total) * 100, 2) : 0,
            ];
        }
        
        return $stats;
    }

    /**
     * Clean up expired data based on retention policy.
     */
    public function cleanupExpiredData(): int
    {
        $retentionDays = PdpaConsent::getRetentionPeriod();
        $cutoffDate = now('Asia/Singapore')->subDays($retentionDays);
        
        $expiredConsents = PdpaConsent::where('created_at', '<', $cutoffDate)
            ->whereNull('withdrawn_at')
            ->get();
        
        $count = 0;
        foreach ($expiredConsents as $consent) {
            $this->deleteCustomerData($consent->customer_email);
            $count++;
        }
        
        Log::info('Cleaned up expired PDPA data', [
            'retention_days' => $retentionDays,
            'cutoff_date' => $cutoffDate->toDateString(),
            'cleaned_count' => $count,
        ]);
        
        return $count;
    }
}