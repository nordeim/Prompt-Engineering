<?php

namespace App\Services;

use App\Models\Product;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class InventoryService
{
    /**
     * Reserve stock for an order with two-phase locking.
     */
    public function reserveStock(Product $product, int $quantity): bool
    {
        $lockKey = "inventory_lock_{$product->id}";
        $reservationKey = "inventory_reservation_{$product->id}_" . uniqid();
        
        try {
            // Phase 1: Redis-based advisory lock
            $lockAcquired = Cache::lock($lockKey, 10)->get(function () use ($product, $quantity, $reservationKey) {
                // Phase 2: Database pessimistic lock
                return DB::transaction(function () use ($product, $quantity, $reservationKey) {
                    // Lock the product row for update
                    $lockedProduct = Product::where('id', $product->id)
                        ->lockForUpdate()
                        ->first();
                    
                    if (!$lockedProduct) {
                        throw new \Exception("Product {$product->id} not found");
                    }
                    
                    // Check stock availability
                    if ($lockedProduct->stock_quantity < $quantity) {
                        throw new \Exception("Insufficient stock for product {$product->id}");
                    }
                    
                    // Reserve stock
                    $lockedProduct->stock_quantity -= $quantity;
                    $lockedProduct->save();
                    
                    // Store reservation in Redis for tracking
                    Cache::put($reservationKey, [
                        'product_id' => $product->id,
                        'quantity' => $quantity,
                        'reserved_at' => now()->timestamp,
                    ], 1800); // 30 minutes
                    
                    return true;
                });
            });
            
            if (!$lockAcquired) {
                throw new \Exception("Could not acquire inventory lock for product {$product->id}");
            }
            
            Log::info('Stock reserved successfully', [
                'product_id' => $product->id,
                'quantity' => $quantity,
                'reservation_key' => $reservationKey,
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Failed to reserve stock', [
                'product_id' => $product->id,
                'quantity' => $quantity,
                'error' => $e->getMessage(),
            ]);
            
            return false;
        }
    }

    /**
     * Release reserved stock.
     */
    public function releaseStock(Product $product, int $quantity): bool
    {
        try {
            DB::transaction(function () use ($product, $quantity) {
                $product->stock_quantity += $quantity;
                $product->save();
            });
            
            Log::info('Stock released successfully', [
                'product_id' => $product->id,
                'quantity' => $quantity,
            ]);
            
            return true;
            
        } catch (\Exception $e) {
            Log::error('Failed to release stock', [
                'product_id' => $product->id,
                'quantity' => $quantity,
                'error' => $e->getMessage(),
            ]);
            
            return false;
        }
    }

    /**
     * Check stock availability.
     */
    public function checkStock(Product $product, int $quantity): bool
    {
        return DB::transaction(function () use ($product, $quantity) {
            $currentStock = Product::where('id', $product->id)
                ->value('stock_quantity');
            
            return $currentStock >= $quantity;
        });
    }

    /**
     * Get stock level with reservation count.
     */
    public function getStockLevel(Product $product): array
    {
        $availableStock = $product->stock_quantity;
        $reservedStock = $this->getReservedStockCount($product->id);
        
        return [
            'product_id' => $product->id,
            'available_stock' => $availableStock,
            'reserved_stock' => $reservedStock,
            'net_available' => $availableStock - $reservedStock,
        ];
    }

    /**
     * Get count of reserved stock for a product.
     */
    private function getReservedStockCount(string $productId): int
    {
        $pattern = "inventory_reservation_{$productId}_*";
        $reservations = Cache::get($pattern, []);
        
        $totalReserved = 0;
        $expiredReservations = [];
        
        foreach ($reservations as $key => $reservation) {
            // Check if reservation has expired (30 minutes)
            if (now()->timestamp - $reservation['reserved_at'] > 1800) {
                $expiredReservations[] = $key;
                continue;
            }
            
            $totalReserved += $reservation['quantity'];
        }
        
        // Clean up expired reservations
        foreach ($expiredReservations as $key) {
            Cache::forget($key);
        }
        
        return $totalReserved;
    }

    /**
     * Auto-release expired reservations.
     */
    public function releaseExpiredReservations(): void
    {
        $pattern = 'inventory_reservation_*';
        $keys = Cache::get($pattern, []);
        
        foreach ($keys as $key) {
            $reservation = Cache::get($key);
            
            if ($reservation && (now()->timestamp - $reservation['reserved_at'] > 1800)) {
                try {
                    $product = Product::find($reservation['product_id']);
                    if ($product) {
                        $this->releaseStock($product, $reservation['quantity']);
                    }
                    Cache::forget($key);
                    
                    Log::info('Auto-released expired reservation', [
                        'reservation_key' => $key,
                        'product_id' => $reservation['product_id'],
                        'quantity' => $reservation['quantity'],
                    ]);
                } catch (\Exception $e) {
                    Log::error('Failed to auto-release expired reservation', [
                        'reservation_key' => $key,
                        'error' => $e->getMessage(),
                    ]);
                }
            }
        }
    }

    /**
     * Get low stock alerts.
     */
    public function getLowStockAlerts(int $threshold = 10): array
    {
        return Product::where('is_active', true)
            ->where('stock_quantity', '<=', $threshold)
            ->orderBy('stock_quantity', 'asc')
            ->get()
            ->map(function ($product) use ($threshold) {
                return [
                    'product_id' => $product->id,
                    'name' => $product->name,
                    'sku' => $product->sku,
                    'current_stock' => $product->stock_quantity,
                    'threshold' => $threshold,
                    'urgency' => $product->stock_quantity <= 5 ? 'high' : 'medium',
                ];
            })
            ->toArray();
    }
}