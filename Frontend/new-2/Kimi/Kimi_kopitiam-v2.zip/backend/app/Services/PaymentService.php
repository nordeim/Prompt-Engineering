<?php

namespace App\Services;

use App\Models\Order;
use Stripe\Stripe;
use Stripe\PaymentIntent;
use Stripe\Webhook;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Config;

class PaymentService
{
    public function __construct()
    {
        Stripe::setApiKey(Config::get('services.stripe.secret'));
    }

    /**
     * Create a PayNow payment.
     */
    public function createPayNowPayment(Order $order): array
    {
        try {
            // For PayNow, we'll use Stripe's Singapore payment methods
            $paymentIntent = PaymentIntent::create([
                'amount' => $order->total_cents,
                'currency' => 'sgd',
                'payment_method_types' => ['paynow'],
                'metadata' => [
                    'order_number' => $order->order_number,
                    'customer_email' => $order->customer_email,
                ],
                'description' => 'Morning Brew Collective - Order ' . $order->order_number,
            ]);

            return [
                'status' => 'pending',
                'payment_intent_id' => $paymentIntent->id,
                'client_secret' => $paymentIntent->client_secret,
                'payment_method' => 'paynow',
                'qr_code' => $this->generatePayNowQrCode($order),
                'expires_at' => now()->addHours(1)->toIso8601String(),
            ];
        } catch (\Exception $e) {
            Log::error('Failed to create PayNow payment', [
                'order_id' => $order->id,
                'error' => $e->getMessage(),
            ]);

            throw new \Exception('Failed to create PayNow payment');
        }
    }

    /**
     * Create a Stripe payment.
     */
    public function createStripePayment(Order $order): array
    {
        try {
            $paymentIntent = PaymentIntent::create([
                'amount' => $order->total_cents,
                'currency' => 'sgd',
                'payment_method_types' => ['card'],
                'metadata' => [
                    'order_number' => $order->order_number,
                    'customer_email' => $order->customer_email,
                ],
                'description' => 'Morning Brew Collective - Order ' . $order->order_number,
            ]);

            return [
                'status' => 'pending',
                'payment_intent_id' => $paymentIntent->id,
                'client_secret' => $paymentIntent->client_secret,
                'payment_method' => 'credit_card',
                'expires_at' => now()->addHours(1)->toIso8601String(),
            ];
        } catch (\Exception $e) {
            Log::error('Failed to create Stripe payment', [
                'order_id' => $order->id,
                'error' => $e->getMessage(),
            ]);

            throw new \Exception('Failed to create Stripe payment');
        }
    }

    /**
     * Handle Stripe webhook.
     */
    public function handleStripeWebhook(Request $request): array
    {
        $payload = $request->getContent();
        $sigHeader = $request->header('Stripe-Signature');
        $endpointSecret = Config::get('services.stripe.webhook_secret');

        try {
            $event = Webhook::constructEvent($payload, $sigHeader, $endpointSecret);

            switch ($event->type) {
                case 'payment_intent.succeeded':
                    $paymentIntent = $event->data->object;
                    $this->handlePaymentSuccess($paymentIntent);
                    break;

                case 'payment_intent.payment_failed':
                    $paymentIntent = $event->data->object;
                    $this->handlePaymentFailure($paymentIntent);
                    break;

                default:
                    Log::info('Unhandled Stripe event', [
                        'type' => $event->type,
                    ]);
            }

            return ['status' => 'success'];
        } catch (\UnexpectedValueException $e) {
            Log::error('Invalid Stripe payload', [
                'error' => $e->getMessage(),
            ]);
            return ['status' => 'error', 'message' => 'Invalid payload'];
        } catch (\Stripe\Exception\SignatureVerificationException $e) {
            Log::error('Invalid Stripe signature', [
                'error' => $e->getMessage(),
            ]);
            return ['status' => 'error', 'message' => 'Invalid signature'];
        }
    }

    /**
     * Handle PayNow webhook.
     */
    public function handlePayNowWebhook(Request $request): array
    {
        // PayNow webhook implementation would go here
        // This would handle notifications from the PayNow gateway
        
        Log::info('PayNow webhook received', [
            'request' => $request->all(),
        ]);

        // Validate and process the webhook
        // Update order status accordingly

        return ['status' => 'success'];
    }

    /**
     * Handle successful payment.
     */
    private function handlePaymentSuccess(PaymentIntent $paymentIntent): void
    {
        $order = Order::where('stripe_payment_intent_id', $paymentIntent->id)->first();

        if (!$order) {
            Log::warning('Payment succeeded but order not found', [
                'payment_intent_id' => $paymentIntent->id,
            ]);
            return;
        }

        $order->payment_status = Order::PAYMENT_PAID;
        $order->payment_reference = $paymentIntent->charges->data[0]->id ?? null;
        $order->save();

        Log::info('Payment succeeded', [
            'order_id' => $order->id,
            'payment_intent_id' => $paymentIntent->id,
        ]);

        // Send confirmation email
        // TODO: Implement email notification
    }

    /**
     * Handle failed payment.
     */
    private function handlePaymentFailure(PaymentIntent $paymentIntent): void
    {
        $order = Order::where('stripe_payment_intent_id', $paymentIntent->id)->first();

        if (!$order) {
            Log::warning('Payment failed but order not found', [
                'payment_intent_id' => $paymentIntent->id,
            ]);
            return;
        }

        $order->payment_status = Order::PAYMENT_FAILED;
        $order->save();

        Log::info('Payment failed', [
            'order_id' => $order->id,
            'payment_intent_id' => $paymentIntent->id,
            'failure_reason' => $paymentIntent->last_payment_error->message ?? 'Unknown',
        ]);

        // Release reserved stock
        foreach ($order->orderItems as $item) {
            $product = $item->product;
            if ($product) {
                $product->releaseStock($item->quantity);
            }
        }
    }

    /**
     * Generate PayNow QR code data.
     */
    private function generatePayNowQrCode(Order $order): array
    {
        // This would generate the actual PayNow QR code data
        // For now, return a mock response
        
        return [
            'qr_data' => '00020101021126360009SG.PAYNOW010100211+65812345670103' . 
                        '0104' . sprintf('%012d', $order->total_cents) . 
                        '5204000053037025403' . $order->total_cents . 
                        '5802SG5913Morning Brew 6009Singapore62070104ORDER',
            'amount' => $order->total,
            'reference' => $order->order_number,
        ];
    }

    /**
     * Refund a payment.
     */
    public function refundPayment(Order $order, float $amount = null): array
    {
        if (!$order->isPaid()) {
            return [
                'success' => false,
                'error' => 'Order is not paid',
            ];
        }

        try {
            if ($order->stripe_payment_intent_id) {
                $paymentIntent = PaymentIntent::retrieve($order->stripe_payment_intent_id);
                
                $refundAmount = $amount ? (int) round($amount * 100) : $order->total_cents;
                
                $refund = $paymentIntent->refunds->create([
                    'amount' => $refundAmount,
                    'reason' => 'requested_by_customer',
                ]);

                $order->payment_status = Order::PAYMENT_REFUNDED;
                $order->save();

                return [
                    'success' => true,
                    'refund_id' => $refund->id,
                    'amount' => $refundAmount / 100,
                ];
            }

            return [
                'success' => false,
                'error' => 'No payment reference found',
            ];
        } catch (\Exception $e) {
            Log::error('Refund failed', [
                'order_id' => $order->id,
                'error' => $e->getMessage(),
            ]);

            return [
                'success' => false,
                'error' => $e->getMessage(),
            ];
        }
    }
}