<?php

namespace App\Services;

use App\Models\Order;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use SimpleXMLElement;

class InvoiceService
{
    /**
     * Generate UBL 2.1 XML invoice.
     */
    public function generateInvoice(Order $order): string
    {
        $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?><Invoice></Invoice>');
        $xml->addAttribute('xmlns', 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2');
        $xml->addAttribute('xmlns:cac', 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $xml->addAttribute('xmlns:cbc', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');

        // Invoice metadata
        $this->addInvoiceMetadata($xml, $order);
        
        // Seller (Morning Brew Collective)
        $this->addSeller($xml);
        
        // Buyer (Customer)
        $this->addBuyer($xml, $order);
        
        // Line items
        $this->addLineItems($xml, $order);
        
        // Tax information
        $this->addTaxInformation($xml, $order);
        
        // Legal total
        $this->addLegalTotal($xml, $order);

        // Format and save
        $dom = dom_import_simplexml($xml)->ownerDocument;
        $dom->formatOutput = true;
        $xmlString = $dom->saveXML();

        // Store invoice
        $filename = "invoices/{$order->order_number}.xml";
        Storage::disk('local')->put($filename, $xmlString);

        return $filename;
    }

    /**
     * Send invoice via InvoiceNow (PEPPOL).
     */
    public function sendInvoice(Order $order): bool
    {
        if ($order->invoice_sent) {
            Log::info('Invoice already sent', ['order_id' => $order->id]);
            return true;
        }

        try {
            // Generate invoice if not already done
            if (!$order->invoice_number) {
                $order->invoice_number = $this->generateInvoiceNumber($order);
                $order->save();
            }

            $xmlPath = $this->generateInvoice($order);
            $xmlContent = Storage::disk('local')->get($xmlPath);

            // Send to InvoiceNow access point
            $response = Http::withHeaders([
                'Content-Type' => 'application/xml',
                'Authorization' => 'Bearer ' . config('services.invoicenow.api_key'),
            ])->post(config('services.invoicenow.access_point'), $xmlContent);

            if ($response->successful()) {
                $order->invoice_sent = true;
                $order->save();

                Log::info('Invoice sent successfully', [
                    'order_id' => $order->id,
                    'invoice_number' => $order->invoice_number,
                ]);

                return true;
            }

            Log::error('Failed to send invoice', [
                'order_id' => $order->id,
                'response_status' => $response->status(),
                'response_body' => $response->body(),
            ]);

            return false;

        } catch (\Exception $e) {
            Log::error('Exception while sending invoice', [
                'order_id' => $order->id,
                'error' => $e->getMessage(),
            ]);

            return false;
        }
    }

    /**
     * Generate invoice number.
     */
    private function generateInvoiceNumber(Order $order): string
    {
        $prefix = 'INV';
        $year = date('Y');
        $sequence = str_pad($order->id, 6, '0', STR_PAD_LEFT);
        
        return "{$prefix}{$year}{$sequence}";
    }

    /**
     * Add invoice metadata to XML.
     */
    private function addInvoiceMetadata(SimpleXMLElement $xml, Order $order): void
    {
        $cbc = $xml->children('cbc', true);
        
        $cbc->addChild('ID', $order->invoice_number ?? $order->order_number);
        $cbc->addChild('IssueDate', $order->created_at->format('Y-m-d'));
        $cbc->addChild('IssueTime', $order->created_at->format('H:i:s'));
        $cbc->addChild('InvoiceTypeCode', '380'); // Commercial invoice
        $cbc->addChild('DocumentCurrencyCode', 'SGD');
        $cbc->addChild('BuyerReference', $order->order_number);
    }

    /**
     * Add seller information to XML.
     */
    private function addSeller(SimpleXMLElement $xml): void
    {
        $cac = $xml->addChild('cac:AccountingSupplierParty', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $party = $cac->addChild('cac:Party', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        
        // Party name
        $partyName = $party->addChild('cac:PartyName', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $partyName->addChild('cbc:Name', 'Morning Brew Collective Pte Ltd', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        
        // Postal address
        $postalAddress = $party->addChild('cac:PostalAddress', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $postalAddress->addChild('cbc:AddressFormatCode', '1', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        $postalAddress->addChild('cbc:CityName', 'Singapore', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        $postalAddress->addChild('cbc:PostalZone', '059413', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        $postalAddress->addChild('cbc:CountrySubentityCode', 'SG', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        
        $country = $postalAddress->addChild('cac:Country', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $country->addChild('cbc:IdentificationCode', 'SGP', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        
        // Tax scheme
        $taxScheme = $party->addChild('cac:PartyTaxScheme', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $taxScheme->addChild('cbc:CompanyID', '201234567X', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        
        $taxSchemeType = $taxScheme->addChild('cac:TaxScheme', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $taxSchemeType->addChild('cbc:ID', 'GST', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        
        // Contact
        $contact = $party->addChild('cac:Contact', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $contact->addChild('cbc:Telephone', '+65 6123 4567', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        $contact->addChild('cbc:ElectronicMail', 'hello@morningbrew.sg', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
    }

    /**
     * Add buyer information to XML.
     */
    private function addBuyer(SimpleXMLElement $xml, Order $order): void
    {
        $cac = $xml->addChild('cac:AccountingCustomerParty', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $party = $cac->addChild('cac:Party', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        
        // Party name (use pseudonym for privacy)
        $partyName = $party->addChild('cac:PartyName', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $partyName->addChild('cbc:Name', 'Customer ' . substr($order->customer_pseudonym, 0, 8), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        
        // Contact
        $contact = $party->addChild('cac:Contact', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $contact->addChild('cbc:Telephone', $order->customer_phone, 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        $contact->addChild('cbc:ElectronicMail', $order->customer_email, 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
    }

    /**
     * Add line items to XML.
     */
    private function addLineItems(SimpleXMLElement $xml, Order $order): void
    {
        foreach ($order->orderItems as $index => $item) {
            $cac = $xml->addChild('cac:InvoiceLine', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
            $cac->addChild('cbc:ID', $index + 1, 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
            $cac->addChild('cbc:InvoicedQuantity', $item->quantity, 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
                ->addAttribute('unitCode', 'C62');
            $cac->addChild('cbc:LineExtensionAmount', number_format($item->total_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
                ->addAttribute('currencyID', 'SGD');
            
            // Item details
            $itemNode = $cac->addChild('cac:Item', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
            $itemNode->addChild('cbc:Name', $item->product_name, 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
            
            // Price
            $price = $cac->addChild('cac:Price', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
            $price->addChild('cbc:PriceAmount', number_format($item->product_price_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
                ->addAttribute('currencyID', 'SGD');
        }
    }

    /**
     * Add tax information to XML.
     */
    private function addTaxInformation(SimpleXMLElement $xml, Order $order): void
    {
        $cac = $xml->addChild('cac:TaxTotal', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $cac->addChild('cbc:TaxAmount', number_format($order->gst_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
            ->addAttribute('currencyID', 'SGD');
        
        $taxSubtotal = $cac->addChild('cac:TaxSubtotal', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $taxSubtotal->addChild('cbc:TaxableAmount', number_format($order->subtotal_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
            ->addAttribute('currencyID', 'SGD');
        $taxSubtotal->addChild('cbc:TaxAmount', number_format($order->gst_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
            ->addAttribute('currencyID', 'SGD');
        
        $taxCategory = $taxSubtotal->addChild('cac:TaxCategory', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $taxCategory->addChild('cbc:ID', 'S', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        $taxCategory->addChild('cbc:Percent', '9', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
        
        $taxScheme = $taxCategory->addChild('cac:TaxScheme', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $taxScheme->addChild('cbc:ID', 'GST', 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2');
    }

    /**
     * Add legal total to XML.
     */
    private function addLegalTotal(SimpleXMLElement $xml, Order $order): void
    {
        $cac = $xml->addChild('cac:LegalMonetaryTotal', null, 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2');
        $cac->addChild('cbc:LineExtensionAmount', number_format($order->subtotal_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
            ->addAttribute('currencyID', 'SGD');
        $cac->addChild('cbc:TaxExclusiveAmount', number_format($order->subtotal_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
            ->addAttribute('currencyID', 'SGD');
        $cac->addChild('cbc:TaxInclusiveAmount', number_format($order->total_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
            ->addAttribute('currencyID', 'SGD');
        $cac->addChild('cbc:PayableAmount', number_format($order->total_cents / 100, 2), 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2')
            ->addAttribute('currencyID', 'SGD');
    }
}