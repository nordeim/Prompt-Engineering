<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\Location;
use App\Models\PdpaConsent;
use App\Services\InventoryService;
use App\Services\PaymentService;
use App\Services\InvoiceService;
use App\Services\PdpaService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Log;

class OrderController extends Controller
{
    /**
     * Display a listing of the orders.
     */
    public function index(Request $request): JsonResponse
    {
        $query = Order::with(['orderItems', 'pickupLocation']);

        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        // Filter by payment status
        if ($request->has('payment_status')) {
            $query->where('payment_status', $request->payment_status);
        }

        // Filter by date range
        if ($request->has('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->has('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        // Sorting
        $query->orderBy('created_at', 'desc');

        // Pagination
        $perPage = min($request->input('per_page', 20), 100);
        $orders = $query->paginate($perPage);

        return response()->json($orders);
    }

    /**
     * Store a newly created order.
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'customer_name' => 'required|string|max:255',
            'customer_email' => 'required|email|max:255',
            'customer_phone' => 'required|string|max:20',
            'pickup_location_id' => 'required|uuid|exists:locations,id',
            'pickup_datetime' => 'required|date|after:now',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|uuid|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1|max:100',
            'payment_method' => 'required|in:paynow,credit_card,cash',
            'consent_marketing' => 'required|boolean',
            'consent_order_processing' => 'required|boolean',
            'notes' => 'nullable|string|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Validation failed',
                'messages' => $validator->errors(),
            ], 422);
        }

        return DB::transaction(function () use ($request) {
            // Validate pickup location
            $location = Location::findOrFail($request->pickup_location_id);
            
            if (!$location->is_active) {
                return response()->json([
                    'error' => 'Location unavailable',
                    'message' => 'The selected pickup location is currently unavailable.',
                ], 400);
            }

            // Validate products and calculate totals
            $subtotal = 0;
            $validatedItems = [];

            foreach ($request->items as $item) {
                $product = Product::find($item['product_id']);
                
                if (!$product || !$product->is_active) {
                    return response()->json([
                        'error' => 'Product unavailable',
                        'message' => "Product {$item['product_id']} is not available.",
                    ], 400);
                }

                if (!$product->hasSufficientStock($item['quantity'])) {
                    return response()->json([
                        'error' => 'Insufficient stock',
                        'message' => "Insufficient stock for {$product->name}.",
                    ], 400);
                }

                $itemTotal = $product->price * $item['quantity'];
                $subtotal += $itemTotal;

                $validatedItems[] = [
                    'product' => $product,
                    'quantity' => $item['quantity'],
                    'price' => $product->price,
                    'total' => $itemTotal,
                ];
            }

            // Calculate GST (Singapore 9%)
            $gstRate = config('app.gst_rate', 0.09);
            $gstAmount = $subtotal * $gstRate;
            $total = $subtotal + $gstAmount;

            // Create order
            $order = new Order();
            $order->customer_name = $request->customer_name;
            $order->customer_email = $request->customer_email;
            $order->customer_phone = $request->customer_phone;
            $order->customer_pseudonym = PdpaService::generatePseudonym($request->customer_email);
            $order->pickup_location_id = $request->pickup_location_id;
            $order->pickup_datetime = $request->pickup_datetime;
            $order->setSubtotal($subtotal);
            $order->payment_method = $request->payment_method;
            $order->notes = $request->notes;
            $order->save();

            // Create order items
            foreach ($validatedItems as $item) {
                $orderItem = $order->orderItems()->create([
                    'product_id' => $item['product']->id,
                    'product_name' => $item['product']->name,
                    'product_price_cents' => (int) round($item['price'] * 100),
                    'quantity' => $item['quantity'],
                    'total_cents' => (int) round($item['total'] * 100),
                ]);

                // Reserve stock
                $inventoryService = new InventoryService();
                $inventoryService->reserveStock($item['product'], $item['quantity']);
            }

            // Record PDPA consents
            $pdpaService = new PdpaService();
            
            if ($request->consent_marketing) {
                $pdpaService->recordConsent(
                    $order->customer_email,
                    PdpaConsent::TYPE_MARKETING,
                    true,
                    $order->id
                );
            }

            if ($request->consent_order_processing) {
                $pdpaService->recordConsent(
                    $order->customer_email,
                    PdpaConsent::TYPE_ORDER_PROCESSING,
                    true,
                    $order->id
                );
            }

            // Process payment based on method
            $paymentService = new PaymentService();
            
            switch ($request->payment_method) {
                case 'paynow':
                    $paymentResult = $paymentService->createPayNowPayment($order);
                    break;
                case 'credit_card':
                    $paymentResult = $paymentService->createStripePayment($order);
                    break;
                case 'cash':
                    $paymentResult = ['status' => 'pending', 'method' => 'cash'];
                    break;
                default:
                    throw new \InvalidArgumentException('Invalid payment method');
            }

            // Update order with payment reference
            if (isset($paymentResult['payment_intent_id'])) {
                $order->stripe_payment_intent_id = $paymentResult['payment_intent_id'];
                $order->save();
            }

            // Send order confirmation
            try {
                // TODO: Implement email notification
                // Mail::to($order->customer_email)->send(new OrderConfirmation($order));
            } catch (\Exception $e) {
                Log::error('Failed to send order confirmation email', [
                    'order_id' => $order->id,
                    'error' => $e->getMessage(),
                ]);
            }

            return response()->json([
                'order' => $order->load('orderItems'),
                'payment' => $paymentResult,
                'breakdown' => $order->calculateBreakdown(),
            ], 201);
        });
    }

    /**
     * Display the specified order.
     */
    public function show(Order $order): JsonResponse
    {
        return response()->json($order->load(['orderItems.product', 'pickupLocation']));
    }

    /**
     * Get order status.
     */
    public function status(Order $order): JsonResponse
    {
        return response()->json([
            'order_number' => $order->order_number,
            'status' => $order->status,
            'payment_status' => $order->payment_status,
            'pickup_datetime' => $order->pickup_datetime->toIso8601String(),
            'estimated_ready_time' => $order->pickup_datetime->subMinutes(15)->toIso8601String(),
        ]);
    }

    /**
     * Update order status.
     */
    public function updateStatus(Request $request, Order $order): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'status' => 'required|in:confirmed,preparing,ready,completed,cancelled',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Validation failed',
                'messages' => $validator->errors(),
            ], 422);
        }

        $newStatus = $request->status;
        $transitions = $order->getAvailableTransitions();

        if (!isset($transitions[$newStatus])) {
            return response()->json([
                'error' => 'Invalid transition',
                'message' => 'Cannot transition from ' . $order->status . ' to ' . $newStatus,
                'available_transitions' => $transitions,
            ], 400);
        }

        $order->status = $newStatus;
        $order->save();

        // Send status update notification
        // TODO: Implement notification

        return response()->json([
            'message' => 'Order status updated successfully',
            'order' => $order,
        ]);
    }

    /**
     * Confirm an order.
     */
    public function confirm(Order $order): JsonResponse
    {
        if (!$order->isPending()) {
            return response()->json([
                'error' => 'Invalid status',
                'message' => 'Order is not in pending status.',
            ], 400);
        }

        $order->confirm();

        // Generate and send InvoiceNow if applicable
        if ($order->isPaid() && !$order->invoice_sent) {
            $invoiceService = new InvoiceService();
            $invoiceService->generateInvoice($order);
            $invoiceService->sendInvoice($order);
        }

        return response()->json([
            'message' => 'Order confirmed successfully',
            'order' => $order,
        ]);
    }

    /**
     * Complete an order.
     */
    public function complete(Order $order): JsonResponse
    {
        if ($order->status !== Order::STATUS_READY) {
            return response()->json([
                'error' => 'Invalid status',
                'message' => 'Order must be ready for pickup before completing.',
            ], 400);
        }

        $order->complete();

        return response()->json([
            'message' => 'Order completed successfully',
            'order' => $order,
        ]);
    }

    /**
     * Get user's orders.
     */
    public function userOrders(Request $request): JsonResponse
    {
        $email = $request->user()->email ?? $request->input('email');
        
        if (!$email) {
            return response()->json([
                'error' => 'Email required',
                'message' => 'Please provide an email address to look up orders.',
            ], 400);
        }

        $orders = Order::where('customer_email', $email)
            ->with(['orderItems', 'pickupLocation'])
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return response()->json($orders);
    }

    /**
     * Get a specific user order.
     */
    public function userOrder(Request $request, Order $order): JsonResponse
    {
        $email = $request->user()->email ?? $request->input('email');
        
        if ($order->customer_email !== $email) {
            return response()->json([
                'error' => 'Unauthorized',
                'message' => 'You do not have permission to view this order.',
            ], 403);
        }

        return response()->json($order->load(['orderItems', 'pickupLocation']));
    }

    /**
     * Handle Stripe webhook.
     */
    public function stripeWebhook(Request $request): JsonResponse
    {
        $paymentService = new PaymentService();
        $result = $paymentService->handleStripeWebhook($request);

        return response()->json($result);
    }

    /**
     * Handle PayNow webhook.
     */
    public function payNowWebhook(Request $request): JsonResponse
    {
        $paymentService = new PaymentService();
        $result = $paymentService->handlePayNowWebhook($request);

        return response()->json($result);
    }

    /**
     * Get sales report.
     */
    public function salesReport(Request $request): JsonResponse
    {
        $days = min($request->input('days', 30), 365);
        $dateFrom = now()->subDays($days);

        $report = [
            'period' => [
                'from' => $dateFrom->toDateString(),
                'to' => now()->toDateString(),
            ],
            'total_orders' => Order::where('created_at', '>=', $dateFrom)
                ->where('status', 'completed')
                ->count(),
            'total_revenue' => Order::where('created_at', '>=', $dateFrom)
                ->where('status', 'completed')
                ->sum('total_cents') / 100,
            'average_order_value' => Order::where('created_at', '>=', $dateFrom)
                ->where('status', 'completed')
                ->avg('total_cents') / 100,
            'daily_breakdown' => Order::selectRaw(
                'DATE(created_at) as date, COUNT(*) as orders, SUM(total_cents) / 100 as revenue'
            )
                ->where('created_at', '>=', $dateFrom)
                ->where('status', 'completed')
                ->groupBy('date')
                ->orderBy('date', 'desc')
                ->get(),
        ];

        return response()->json($report);
    }

    /**
     * Destroy an order.
     */
    public function destroy(Order $order): JsonResponse
    {
        // Only allow deletion of pending orders
        if (!$order->isPending()) {
            return response()->json([
                'error' => 'Cannot delete',
                'message' => 'Only pending orders can be deleted.',
            ], 400);
        }

        // Release reserved stock
        foreach ($order->orderItems as $item) {
            $product = $item->product;
            if ($product) {
                $product->releaseStock($item->quantity);
            }
        }

        $order->delete();

        return response()->json([
            'message' => 'Order deleted successfully',
        ]);
    }
}