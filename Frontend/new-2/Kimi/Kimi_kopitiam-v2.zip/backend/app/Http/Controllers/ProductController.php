<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class ProductController extends Controller
{
    /**
     * Display a listing of the products.
     */
    public function index(Request $request): JsonResponse
    {
        $query = Product::active();

        // Filter by category
        if ($request->has('category')) {
            $query->where('category', $request->category);
        }

        // Filter by popularity
        if ($request->boolean('popular')) {
            $query->popular();
        }

        // Search by name
        if ($request->has('search')) {
            $query->where('name', 'ilike', '%' . $request->search . '%');
        }

        // Sorting
        $sortBy = $request->input('sort_by', 'name');
        $sortOrder = $request->input('sort_order', 'asc');

        switch ($sortBy) {
            case 'price':
                $query->orderBy('price_cents', $sortOrder);
                break;
            case 'popular':
                $query->orderBy('is_popular', 'desc')->orderBy('name', 'asc');
                break;
            default:
                $query->orderBy($sortBy, $sortOrder);
        }

        // Pagination
        $perPage = min($request->input('per_page', 20), 100);
        $products = $query->paginate($perPage);

        return response()->json([
            'data' => $products->items(),
            'pagination' => [
                'current_page' => $products->currentPage(),
                'per_page' => $products->perPage(),
                'total' => $products->total(),
                'last_page' => $products->lastPage(),
                'from' => $products->firstItem(),
                'to' => $products->lastItem(),
            ],
        ]);
    }

    /**
     * Display the specified product.
     */
    public function show(Product $product): JsonResponse
    {
        if (!$product->is_active) {
            return response()->json([
                'error' => 'Product not found',
                'message' => 'The requested product is not available.',
            ], 404);
        }

        return response()->json($product);
    }

    /**
     * Get products by category.
     */
    public function byCategory(Request $request, string $category): JsonResponse
    {
        $validCategories = ['coffee', 'breakfast', 'pastries', 'beverages'];

        if (!in_array($category, $validCategories)) {
            return response()->json([
                'error' => 'Invalid category',
                'message' => 'The requested category is not valid.',
                'valid_categories' => $validCategories,
            ], 400);
        }

        $query = Product::active()->where('category', $category);

        // Sort popular items first
        $query->orderBy('is_popular', 'desc')->orderBy('name', 'asc');

        $perPage = min($request->input('per_page', 20), 100);
        $products = $query->paginate($perPage);

        return response()->json([
            'data' => $products->items(),
            'pagination' => [
                'current_page' => $products->currentPage(),
                'per_page' => $products->perPage(),
                'total' => $products->total(),
                'last_page' => $products->lastPage(),
            ],
        ]);
    }

    /**
     * Store a newly created product.
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0.01',
            'category' => 'required|in:coffee,breakfast,pastries,beverages',
            'image_url' => 'nullable|url',
            'is_popular' => 'boolean',
            'stock_quantity' => 'integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Validation failed',
                'messages' => $validator->errors(),
            ], 422);
        }

        $product = new Product();
        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->category = $request->category;
        $product->image_url = $request->image_url;
        $product->is_popular = $request->boolean('is_popular', false);
        $product->stock_quantity = $request->input('stock_quantity', 0);
        $product->sku = $this->generateSku();
        $product->save();

        return response()->json($product, 201);
    }

    /**
     * Update the specified product.
     */
    public function update(Request $request, Product $product): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|required|string|max:255',
            'description' => 'sometimes|nullable|string',
            'price' => 'sometimes|required|numeric|min:0.01',
            'category' => 'sometimes|required|in:coffee,breakfast,pastries,beverages',
            'image_url' => 'sometimes|nullable|url',
            'is_active' => 'boolean',
            'is_popular' => 'boolean',
            'stock_quantity' => 'sometimes|integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Validation failed',
                'messages' => $validator->errors(),
            ], 422);
        }

        $product->fill($request->only([
            'name',
            'description',
            'price',
            'category',
            'image_url',
            'is_active',
            'is_popular',
            'stock_quantity',
        ]));

        $product->save();

        return response()->json($product);
    }

    /**
     * Update product stock quantity.
     */
    public function updateStock(Request $request, Product $product): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'stock_quantity' => 'required|integer|min:0',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Validation failed',
                'messages' => $validator->errors(),
            ], 422);
        }

        $product->stock_quantity = $request->stock_quantity;
        $product->save();

        return response()->json([
            'message' => 'Stock updated successfully',
            'product' => $product,
        ]);
    }

    /**
     * Remove the specified product.
     */
    public function destroy(Product $product): JsonResponse
    {
        // Soft delete by setting inactive
        $product->is_active = false;
        $product->save();

        return response()->json([
            'message' => 'Product deactivated successfully',
        ]);
    }

    /**
     * Get popular products report.
     */
    public function popularProducts(Request $request): JsonResponse
    {
        $days = min($request->input('days', 30), 365);
        $dateFrom = now()->subDays($days);

        $popularProducts = Product::select('products.*')
            ->selectRaw('COUNT(order_items.id) as order_count')
            ->selectRaw('SUM(order_items.quantity) as total_quantity')
            ->leftJoin('order_items', 'products.id', '=', 'order_items.product_id')
            ->leftJoin('orders', 'order_items.order_id', '=', 'orders.id')
            ->where('orders.created_at', '>=', $dateFrom)
            ->where('orders.status', 'completed')
            ->groupBy('products.id')
            ->orderBy('total_quantity', 'desc')
            ->limit(20)
            ->get();

        return response()->json($popularProducts);
    }

    /**
     * Generate a unique SKU.
     */
    private function generateSku(): string
    {
        $prefix = 'MB';
        $random = strtoupper(substr(uniqid(), -6));
        return $prefix . $random;
    }
}