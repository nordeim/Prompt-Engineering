<?php

namespace App\Http\Controllers;

use App\Models\Location;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class LocationController extends Controller
{
    /**
     * Display a listing of the locations.
     */
    public function index(Request $request): JsonResponse
    {
        $query = Location::active();

        // Filter by features
        if ($request->has('features')) {
            $features = is_array($request->features) ? $request->features : [$request->features];
            foreach ($features as $feature) {
                $query->whereJsonContains('features', $feature);
            }
        }

        // Sort by distance if coordinates provided
        if ($request->has(['latitude', 'longitude'])) {
            $lat = $request->latitude;
            $lng = $request->longitude;
            
            $query->selectRaw(
                '*, (6371 * acos(cos(radians(?)) * cos(radians(latitude)) * cos(radians(longitude) - radians(?)) + sin(radians(?)) * sin(radians(latitude)))) AS distance',
                [$lat, $lng, $lat]
            )->orderBy('distance');
        } else {
            $query->orderBy('name');
        }

        $perPage = min($request->input('per_page', 20), 50);
        $locations = $query->paginate($perPage);

        return response()->json([
            'data' => $locations->items(),
            'pagination' => [
                'current_page' => $locations->currentPage(),
                'per_page' => $locations->perPage(),
                'total' => $locations->total(),
                'last_page' => $locations->lastPage(),
            ],
        ]);
    }

    /**
     * Display the specified location.
     */
    public function show(Location $location): JsonResponse
    {
        if (!$location->is_active) {
            return response()->json([
                'error' => 'Location not found',
                'message' => 'The requested location is not available.',
            ], 404);
        }

        return response()->json($location);
    }

    /**
     * Get location operating hours.
     */
    public function operatingHours(Location $location): JsonResponse
    {
        if (!$location->is_active) {
            return response()->json([
                'error' => 'Location not found',
                'message' => 'The requested location is not available.',
            ], 404);
        }

        return response()->json([
            'location_id' => $location->id,
            'location_name' => $location->name,
            'is_currently_open' => $location->isCurrentlyOpen(),
            'operating_hours' => $location->getFormattedHours(),
        ]);
    }

    /**
     * Store a newly created location.
     */
    public function store(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'address' => 'required|string|max:500',
            'postal_code' => 'required|string|max:10',
            'phone' => 'required|string|max:20',
            'email' => 'nullable|email|max:255',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'operating_hours' => 'required|array',
            'operating_hours.*.open' => 'required|string',
            'operating_hours.*.close' => 'required|string',
            'features' => 'nullable|array',
            'features.*' => 'string',
            'capacity' => 'integer|min:1|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Validation failed',
                'messages' => $validator->errors(),
            ], 422);
        }

        $location = Location::create($request->all());

        return response()->json($location, 201);
    }

    /**
     * Update the specified location.
     */
    public function update(Request $request, Location $location): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'name' => 'sometimes|required|string|max:255',
            'address' => 'sometimes|required|string|max:500',
            'postal_code' => 'sometimes|required|string|max:10',
            'phone' => 'sometimes|required|string|max:20',
            'email' => 'sometimes|nullable|email|max:255',
            'latitude' => 'sometimes|required|numeric|between:-90,90',
            'longitude' => 'sometimes|required|numeric|between:-180,180',
            'operating_hours' => 'sometimes|required|array',
            'features' => 'sometimes|nullable|array',
            'is_active' => 'boolean',
            'capacity' => 'sometimes|integer|min:1|max:1000',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'error' => 'Validation failed',
                'messages' => $validator->errors(),
            ], 422);
        }

        $location->fill($request->all());
        $location->save();

        return response()->json($location);
    }

    /**
     * Remove the specified location.
     */
    public function destroy(Location $location): JsonResponse
    {
        // Soft delete by setting inactive
        $location->is_active = false;
        $location->save();

        return response()->json([
            'message' => 'Location deactivated successfully',
        ]);
    }
}