<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\Hash;

class PdpaConsent extends Model
{
    use HasFactory;

    /**
     * Consent type constants.
     */
    const TYPE_MARKETING = 'marketing';
    const TYPE_ORDER_PROCESSING = 'order_processing';
    const TYPE_ACCOUNT_CREATION = 'account_creation';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'order_id',
        'customer_email',
        'customer_pseudonym',
        'consent_type',
        'consent_given',
        'consent_timestamp',
        'ip_address',
        'user_agent',
        'wording_hash',
        'consent_version',
        'withdrawn_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'consent_given' => 'boolean',
        'consent_timestamp' => 'datetime',
        'withdrawn_at' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Create a new PDPA consent record.
     */
    public static function createConsent(array $data): self
    {
        $pseudonym = static::generatePseudonym($data['customer_email']);
        
        return static::create([
            'order_id' => $data['order_id'] ?? null,
            'customer_email' => $data['customer_email'],
            'customer_pseudonym' => $pseudonym,
            'consent_type' => $data['consent_type'],
            'consent_given' => $data['consent_given'],
            'consent_timestamp' => now('Asia/Singapore'),
            'ip_address' => $data['ip_address'] ?? request()->ip(),
            'user_agent' => $data['user_agent'] ?? request()->userAgent(),
            'wording_hash' => static::hashWording($data['wording'] ?? ''),
            'consent_version' => config('app.pdpa_consent_version', '1.0'),
        ]);
    }

    /**
     * Generate pseudonym for customer email.
     */
    public static function generatePseudonym(string $email): string
    {
        $salt = config('app.pdpa_salt', 'morning_brew_default_salt');
        return hash('sha256', $email . $salt);
    }

    /**
     * Hash consent wording for audit purposes.
     */
    public static function hashWording(string $wording): string
    {
        return hash('sha256', trim($wording));
    }

    /**
     * Withdraw consent.
     */
    public function withdraw(): void
    {
        $this->consent_given = false;
        $this->withdrawn_at = now('Asia/Singapore');
        $this->save();
    }

    /**
     * Check if consent is currently valid.
     */
    public function isValid(): bool
    {
        return $this->consent_given && !$this->withdrawn_at;
    }

    /**
     * Check if consent wording has changed.
     */
    public function hasWordingChanged(string $currentWording): bool
    {
        return $this->wording_hash !== static::hashWording($currentWording);
    }

    /**
     * Scope a query to only include valid consents.
     */
    public function scopeValid($query)
    {
        return $query->where('consent_given', true)
                     ->whereNull('withdrawn_at');
    }

    /**
     * Scope a query to only include consents by type.
     */
    public function scopeByType($query, string $type)
    {
        return $query->where('consent_type', $type);
    }

    /**
     * Scope a query to only include consents by email.
     */
    public function scopeByEmail($query, string $email)
    {
        $pseudonym = static::generatePseudonym($email);
        return $query->where('customer_pseudonym', $pseudonym);
    }

    /**
     * Relationship with order.
     */
    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Get consent types as array.
     */
    public static function getConsentTypes(): array
    {
        return [
            self::TYPE_MARKETING => 'Marketing Communications',
            self::TYPE_ORDER_PROCESSING => 'Order Processing',
            self::TYPE_ACCOUNT_CREATION => 'Account Creation',
        ];
    }

    /**
     * Get retention period in days.
     */
    public static function getRetentionPeriod(): int
    {
        return config('app.pdpa_retention_days', 2555); // 7 years default
    }

    /**
     * Check if record is past retention period.
     */
    public function isPastRetentionPeriod(): bool
    {
        $retentionDays = static::getRetentionPeriod();
        return $this->created_at->diffInDays(now()) > $retentionDays;
    }
}