<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Order extends Model
{
    use HasFactory;

    /**
     * Order status constants.
     */
    const STATUS_PENDING = 'pending';
    const STATUS_CONFIRMED = 'confirmed';
    const STATUS_PREPARING = 'preparing';
    const STATUS_READY = 'ready';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';

    /**
     * Payment status constants.
     */
    const PAYMENT_PENDING = 'pending';
    const PAYMENT_PAID = 'paid';
    const PAYMENT_FAILED = 'failed';
    const PAYMENT_REFUNDED = 'refunded';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'order_number',
        'customer_name',
        'customer_email',
        'customer_phone',
        'customer_pseudonym',
        'pickup_location_id',
        'pickup_datetime',
        'subtotal_cents',
        'gst_cents',
        'total_cents',
        'status',
        'payment_status',
        'payment_method',
        'payment_reference',
        'stripe_payment_intent_id',
        'invoice_number',
        'invoice_sent',
        'notes',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'subtotal_cents' => 'integer',
        'gst_cents' => 'integer',
        'total_cents' => 'integer',
        'pickup_datetime' => 'datetime',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
        'invoice_sent' => 'boolean',
    ];

    /**
     * The "booted" method of the model.
     */
    protected static function booted()
    {
        static::creating(function ($order) {
            if (empty($order->order_number)) {
                $order->order_number = static::generateOrderNumber();
            }
        });
    }

    /**
     * Generate a unique order number.
     */
    public static function generateOrderNumber(): string
    {
        $prefix = 'MB' . date('Ymd');
        $lastOrder = static::whereDate('created_at', today())
            ->where('order_number', 'like', $prefix . '%')
            ->latest()
            ->first();

        $sequence = $lastOrder 
            ? (int) substr($lastOrder->order_number, -4) + 1 
            : 1;

        return $prefix . str_pad($sequence, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Get subtotal in dollars.
     */
    public function getSubtotalAttribute(): float
    {
        return $this->subtotal_cents / 100;
    }

    /**
     * Get GST amount in dollars.
     */
    public function getGstAmountAttribute(): float
    {
        return $this->gst_cents / 100;
    }

    /**
     * Get total in dollars.
     */
    public function getTotalAttribute(): float
    {
        return $this->total_cents / 100;
    }

    /**
     * Calculate order breakdown including GST.
     */
    public function calculateBreakdown(): array
    {
        $subtotal = $this->subtotal_cents / 100;
        $gstRate = config('app.gst_rate', 0.09);
        $gstAmount = $subtotal * $gstRate;
        $total = $subtotal + $gstAmount;

        return [
            'subtotal' => round($subtotal, 2),
            'gst_rate' => $gstRate,
            'gst_amount' => round($gstAmount, 2),
            'total' => round($total, 2),
        ];
    }

    /**
     * Set subtotal and calculate GST.
     */
    public function setSubtotal(float $amount): void
    {
        $this->subtotal_cents = (int) round($amount * 100);
        
        $gstRate = config('app.gst_rate', 0.09);
        $this->gst_cents = (int) round($this->subtotal_cents * $gstRate);
        
        $this->total_cents = $this->subtotal_cents + $this->gst_cents;
    }

    /**
     * Check if order is pending.
     */
    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    /**
     * Check if order is confirmed.
     */
    public function isConfirmed(): bool
    {
        return $this->status === self::STATUS_CONFIRMED;
    }

    /**
     * Check if order is completed.
     */
    public function isCompleted(): bool
    {
        return $this->status === self::STATUS_COMPLETED;
    }

    /**
     * Check if order is paid.
     */
    public function isPaid(): bool
    {
        return $this->payment_status === self::PAYMENT_PAID;
    }

    /**
     * Mark order as confirmed.
     */
    public function confirm(): void
    {
        $this->status = self::STATUS_CONFIRMED;
        $this->save();
    }

    /**
     * Mark order as completed.
     */
    public function complete(): void
    {
        $this->status = self::STATUS_COMPLETED;
        $this->save();
    }

    /**
     * Get available status transitions.
     */
    public function getAvailableTransitions(): array
    {
        return match ($this->status) {
            self::STATUS_PENDING => [
                self::STATUS_CONFIRMED => 'Confirm',
                self::STATUS_CANCELLED => 'Cancel',
            ],
            self::STATUS_CONFIRMED => [
                self::STATUS_PREPARING => 'Start Preparing',
                self::STATUS_CANCELLED => 'Cancel',
            ],
            self::STATUS_PREPARING => [
                self::STATUS_READY => 'Mark Ready',
            ],
            self::STATUS_READY => [
                self::STATUS_COMPLETED => 'Complete',
            ],
            default => [],
        };
    }

    /**
     * Relationship with order items.
     */
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * Relationship with pickup location.
     */
    public function pickupLocation()
    {
        return $this->belongsTo(Location::class, 'pickup_location_id');
    }

    /**
     * Relationship with PDPA consent.
     */
    public function pdpaConsent()
    {
        return $this->hasOne(PdpaConsent::class);
    }
}