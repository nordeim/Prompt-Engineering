<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Location extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'address',
        'postal_code',
        'phone',
        'email',
        'latitude',
        'longitude',
        'operating_hours',
        'features',
        'is_active',
        'capacity',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'latitude' => 'float',
        'longitude' => 'float',
        'features' => 'array',
        'operating_hours' => 'array',
        'is_active' => 'boolean',
        'capacity' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Scope a query to only include active locations.
     */
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    /**
     * Check if location is currently open.
     */
    public function isCurrentlyOpen(): bool
    {
        $now = now('Asia/Singapore');
        $currentDay = strtolower($now->format('l')); // monday, tuesday, etc.
        $currentTime = $now->format('H:i');

        $hours = $this->operating_hours[$currentDay] ?? null;
        
        if (!$hours) {
            return false;
        }

        return $currentTime >= $hours['open'] && $currentTime <= $hours['close'];
    }

    /**
     * Get formatted operating hours.
     */
    public function getFormattedHours(): array
    {
        $formatted = [];
        $days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

        foreach ($days as $day) {
            if (isset($this->operating_hours[$day])) {
                $formatted[ucfirst($day)] = sprintf(
                    '%s - %s',
                    $this->formatTime($this->operating_hours[$day]['open']),
                    $this->formatTime($this->operating_hours[$day]['close'])
                );
            }
        }

        return $formatted;
    }

    /**
     * Format time for display.
     */
    private function formatTime(string $time): string
    {
        return date('g:i A', strtotime($time));
    }

    /**
     * Calculate distance from given coordinates.
     */
    public function calculateDistance(float $lat, float $lng): float
    {
        $earthRadius = 6371; // km

        $latDiff = deg2rad($this->latitude - $lat);
        $lngDiff = deg2rad($this->longitude - $lng);

        $a = sin($latDiff / 2) * sin($latDiff / 2) +
             cos(deg2rad($lat)) * cos(deg2rad($this->latitude)) *
             sin($lngDiff / 2) * sin($lngDiff / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c;
    }

    /**
     * Relationship with orders.
     */
    public function orders()
    {
        return $this->hasMany(Order::class, 'pickup_location_id');
    }
}