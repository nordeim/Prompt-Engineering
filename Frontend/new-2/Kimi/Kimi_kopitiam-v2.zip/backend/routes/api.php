<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\LocationController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

// Health check endpoint
Route::get('/health', function () {
    return response()->json([
        'status' => 'healthy',
        'timestamp' => now()->toIso8601String(),
        'service' => 'Morning Brew Collective API',
        'version' => '1.0.0',
    ]);
});

// Public API routes (no authentication required)
Route::prefix('v1')->group(function () {
    // Products
    Route::get('/products', [ProductController::class, 'index']);
    Route::get('/products/{product}', [ProductController::class, 'show']);
    Route::get('/products/category/{category}', [ProductController::class, 'byCategory']);
    
    // Locations
    Route::get('/locations', [LocationController::class, 'index']);
    Route::get('/locations/{location}', [LocationController::class, 'show']);
    Route::get('/locations/{location}/hours', [LocationController::class, 'operatingHours']);
    
    // Orders (public endpoints)
    Route::post('/orders', [OrderController::class, 'store']);
    Route::get('/orders/{order}/status', [OrderController::class, 'status']);
    
    // Payment webhooks (Stripe, etc.)
    Route::post('/webhooks/stripe', [OrderController::class, 'stripeWebhook']);
    Route::post('/webhooks/paynow', [OrderController::class, 'payNowWebhook']);
});

// Protected API routes (authentication required)
Route::prefix('v1')->middleware('auth:sanctum')->group(function () {
    // Admin-only routes
    Route::middleware('role:admin')->group(function () {
        // Product management
        Route::post('/products', [ProductController::class, 'store']);
        Route::put('/products/{product}', [ProductController::class, 'update']);
        Route::delete('/products/{product}', [ProductController::class, 'destroy']);
        Route::patch('/products/{product}/stock', [ProductController::class, 'updateStock']);
        
        // Order management
        Route::get('/orders', [OrderController::class, 'index']);
        Route::get('/orders/{order}', [OrderController::class, 'show']);
        Route::patch('/orders/{order}/status', [OrderController::class, 'updateStatus']);
        Route::patch('/orders/{order}/confirm', [OrderController::class, 'confirm']);
        Route::patch('/orders/{order}/complete', [OrderController::class, 'complete']);
        Route::delete('/orders/{order}', [OrderController::class, 'destroy']);
        
        // Location management
        Route::post('/locations', [LocationController::class, 'store']);
        Route::put('/locations/{location}', [LocationController::class, 'update']);
        Route::delete('/locations/{location}', [LocationController::class, 'destroy']);
        
        // Reports and analytics
        Route::get('/reports/sales', [OrderController::class, 'salesReport']);
        Route::get('/reports/popular-products', [ProductController::class, 'popularProducts']);
    });
    
    // Customer routes
    Route::get('/user/orders', [OrderController::class, 'userOrders']);
    Route::get('/user/orders/{order}', [OrderController::class, 'userOrder']);
});

// Rate limited endpoints
Route::prefix('v1')->middleware('throttle:60,1')->group(function () {
    // Order creation (additional rate limiting)
    Route::post('/orders/quick', [OrderController::class, 'quickOrder']);
});

// Fallback route
Route::fallback(function () {
    return response()->json([
        'error' => 'Endpoint not found',
        'message' => 'The requested API endpoint does not exist.',
    ], 404);
});