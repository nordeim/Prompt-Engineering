import { translations } from '../data/translations';

interface CritiquePanelProps {
  selectedVersion: number | null;
  setSelectedVersion: (version: number | null) => void;
}

export function CritiquePanel({ selectedVersion, setSelectedVersion }: CritiquePanelProps) {
  return (
    <div className="space-y-6">
      {/* Overview Section */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-4">
          <h2 className="text-2xl font-bold text-white">Comprehensive Translation Analysis</h2>
          <p className="text-indigo-100 text-sm mt-1">Meticulous review of three translation versions</p>
        </div>
        
        <div className="p-8 space-y-6">
          {/* Overall Assessment */}
          <div className="border-l-4 border-indigo-500 pl-6 py-2">
            <h3 className="text-xl font-bold text-slate-900 mb-3">Overall Assessment</h3>
            <p className="text-slate-700 leading-relaxed mb-4">
              All three translations demonstrate <strong className="text-indigo-600">professional-level quality</strong> and 
              accurately convey the technical content of the Chinese source. The translations successfully maintain the 
              formal, analytical tone while preserving technical terminology and structural organization. Each version 
              would be acceptable for publication, but they differ in stylistic choices, formatting conventions, 
              and terminological precision.
            </p>
            <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
              <p className="text-sm text-slate-600">
                <strong>Key Finding:</strong> Versions 1 and 3 are nearly identical (95%+ similarity) with only minor 
                formatting differences, while Version 2 represents a more distinct stylistic approach with concise 
                phrasing and different word choices.
              </p>
            </div>
          </div>

          {/* Quality Ranking */}
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6">
            <h3 className="text-lg font-bold text-green-900 mb-4 flex items-center">
              <span className="text-2xl mr-2">🏆</span>
              Quality Ranking & Recommendations
            </h3>
            <div className="space-y-3">
              <div className="bg-white rounded-lg p-4 border-l-4 border-green-500">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-green-900">1st Place: Version 3</span>
                  <span className="text-xs bg-green-500 text-white px-3 py-1 rounded-full font-semibold">95/100</span>
                </div>
                <p className="text-sm text-slate-700">
                  Best overall - combines accuracy with optimal formatting, proper use of code backticks, 
                  and clear emphasis through bold text where appropriate.
                </p>
              </div>
              <div className="bg-white rounded-lg p-4 border-l-4 border-blue-500">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-blue-900">2nd Place: Version 2</span>
                  <span className="text-xs bg-blue-500 text-white px-3 py-1 rounded-full font-semibold">92/100</span>
                </div>
                <p className="text-sm text-slate-700">
                  Most stylistically distinct - offers concise, natural phrasing and good terminological variety, 
                  though lacks markdown formatting consistency.
                </p>
              </div>
              <div className="bg-white rounded-lg p-4 border-l-4 border-purple-500">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-purple-900">3rd Place: Version 1</span>
                  <span className="text-xs bg-purple-500 text-white px-3 py-1 rounded-full font-semibold">91/100</span>
                </div>
                <p className="text-sm text-slate-700">
                  Very similar to Version 3 but slightly less polished in formatting details; 
                  still an excellent translation.
                </p>
              </div>
            </div>
          </div>

          {/* Version Selector */}
          <div>
            <h3 className="text-lg font-bold text-slate-900 mb-3">Select Version for Detailed Analysis</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {translations.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setSelectedVersion(t.id)}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    selectedVersion === t.id
                      ? 'border-indigo-500 bg-indigo-50 shadow-md'
                      : 'border-slate-200 hover:border-indigo-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="text-lg font-bold text-slate-900">{t.name}</div>
                  <div className="text-sm text-slate-600 mt-1">
                    {t.id === 1 && 'Click for detailed critique'}
                    {t.id === 2 && 'Click for detailed critique'}
                    {t.id === 3 && 'Click for detailed critique'}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Critiques */}
      {selectedVersion && (
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          <div className={`px-6 py-4 ${
            selectedVersion === 1 ? 'bg-gradient-to-r from-blue-500 to-blue-600' :
            selectedVersion === 2 ? 'bg-gradient-to-r from-green-500 to-green-600' :
            'bg-gradient-to-r from-purple-500 to-purple-600'
          }`}>
            <h3 className="text-xl font-bold text-white">
              Detailed Critique: Version {selectedVersion}
            </h3>
          </div>
          <div className="p-8">
            {selectedVersion === 1 && <Version1Critique />}
            {selectedVersion === 2 && <Version2Critique />}
            {selectedVersion === 3 && <Version3Critique />}
          </div>
        </div>
      )}

      {/* Comparative Analysis */}
      <ComparativeAnalysis />
    </div>
  );
}

function Version1Critique() {
  return (
    <div className="space-y-6">
      <div className="prose prose-slate max-w-none">
        <h4 className="text-lg font-bold text-slate-900 flex items-center">
          <span className="text-green-500 mr-2">✅</span> Strengths
        </h4>
        <ul className="text-slate-700 space-y-2">
          <li>
            <strong>Excellent terminology precision:</strong> Properly uses technical terms like "Instruction Set Architecture (ISA)", 
            "virtualization", "conformance levels" with accurate context.
          </li>
          <li>
            <strong>Maintains structural fidelity:</strong> Preserves all emoji headers and organizational structure from the source.
          </li>
          <li>
            <strong>Clear technical phrasing:</strong> "forces translation requests to sequentially pass through stages" 
            accurately conveys the deterministic state machine concept.
          </li>
          <li>
            <strong>Good use of backticks:</strong> Consistently formats code elements like <code>BOOTSTRAP → ANALYZE</code> 
            and filenames like <code>TRA-MODULE-ZH-EN.md</code>.
          </li>
          <li>
            <strong>Accurate concept mapping:</strong> "parataxis to hypotaxis" correctly translates "意合转形合" 
            (Chinese implicit coherence to English explicit grammatical connection).
          </li>
        </ul>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-amber-500 mr-2">⚠️</span> Areas for Improvement
        </h4>
        <ul className="text-slate-700 space-y-2">
          <li>
            <strong>Inconsistent emphasis formatting:</strong> "Audit Trace" in the L3 description should be bold or 
            in code format for consistency, as it's a technical term.
          </li>
          <li>
            <strong>Slight awkwardness:</strong> "This may appear rigid, but it is the foundation" - the phrase 
            "may appear" sounds slightly tentative; "appears" would be more direct.
          </li>
          <li>
            <strong>Minor redundancy:</strong> "highly trusted" in the conclusion could be "high-trust" (more concise) 
            or "trustworthy" (more natural).
          </li>
          <li>
            <strong>Missing em-dash:</strong> The final sentence uses "and serves as" where Version 3 uses an em-dash, 
            which would be more stylistically polished.
          </li>
        </ul>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-blue-500 mr-2">📊</span> Specific Examples
        </h4>
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 space-y-3">
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Opening sentence:</div>
            <div className="text-sm text-slate-800 italic">
              "After a detailed review of the entire contents of the `nordeim/Translation-Runtime-Architecture` repository..."
            </div>
            <div className="text-xs text-green-600 mt-1">
              ✓ Excellent - "detailed review" properly conveys "详细审阅", maintains formal register
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Technical concept:</div>
            <div className="text-sm text-slate-800 italic">
              "The Hierarchy of Quality"
            </div>
            <div className="text-xs text-amber-600 mt-1">
              ≈ Adequate - "Hierarchy" is accurate but "Ladder" (V2/V3) better captures the progressive 
              nature of "阶梯" (ascending steps)
            </div>
          </div>
        </div>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-purple-500 mr-2">🎯</span> Overall Grade
        </h4>
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-blue-900">Final Score:</span>
            <span className="text-2xl font-bold text-blue-600">91/100</span>
          </div>
          <p className="text-sm text-blue-800">
            A highly competent, professional translation that would be publication-ready with minor formatting 
            adjustments. Strong on accuracy and technical terminology, with room for subtle stylistic refinement.
          </p>
        </div>
      </div>
    </div>
  );
}

function Version2Critique() {
  return (
    <div className="space-y-6">
      <div className="prose prose-slate max-w-none">
        <h4 className="text-lg font-bold text-slate-900 flex items-center">
          <span className="text-green-500 mr-2">✅</span> Strengths
        </h4>
        <ul className="text-slate-700 space-y-2">
          <li>
            <strong>Most natural and concise phrasing:</strong> "my core assessment is this: it is..." uses a 
            conversational colon break that's more engaging than the other versions.
          </li>
          <li>
            <strong>Excellent lexical variety:</strong> Uses "pipeline" instead of "workflow", "central" instead of 
            "core philosophy", "proceed sequentially" vs. "sequentially pass through" - demonstrates sophisticated 
            synonym awareness.
          </li>
          <li>
            <strong>Strong terminological precision:</strong> "paratactic-to-hypotactic transformation" is more 
            precise than V1/V3's "parataxis to hypotaxis".
          </li>
          <li>
            <strong>Better word choice for nuance:</strong> "factual completeness" vs. "factual integrity" better 
            captures "事实完整性" (emphasis on completeness, not just truthfulness).
          </li>
          <li>
            <strong>More natural L1-L4 descriptions:</strong> "Preserves fundamentals, for internal drafts" is more 
            concise than "Preserves basics, used for internal drafts" (removes redundant "used").
          </li>
          <li>
            <strong>Excellent closing:</strong> "high-confidence translation systems -- a highly valuable reference" 
            uses an em-dash effectively and flows beautifully.
          </li>
        </ul>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-amber-500 mr-2">⚠️</span> Areas for Improvement
        </h4>
        <ul className="text-slate-700 space-y-2">
          <li>
            <strong className="text-red-600">Critical issue - Lack of code formatting:</strong> Technical terms like 
            BOOTSTRAP, ANALYZE_DOCUMENT, TRA-MODULE-ZH-EN.md are NOT in backticks. This is a significant markdown 
            convention violation for technical documentation.
          </li>
          <li>
            <strong>Missing Chinese character formatting:</strong> "成立" appears without any code formatting or quotes, 
            making it less clear it's a foreign language example.
          </li>
          <li>
            <strong>Inconsistent term choices:</strong> Uses both "Benchmark Suite" and "Conformance Guide" without 
            backticks or consistent formatting, unlike V1/V3.
          </li>
          <li>
            <strong>Slightly awkward phrasing:</strong> "This may appear rigid, yet it is" - the "yet" feels slightly 
            archaic; "but" would be more modern.
          </li>
          <li>
            <strong>Minor terminology issue:</strong> "audit trail" vs. "Audit Trace" - should maintain the original 
            technical term "Trace" as it appears to be a specific feature name in the system.
          </li>
        </ul>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-blue-500 mr-2">📊</span> Specific Examples
        </h4>
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 space-y-3">
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Terminology precision:</div>
            <div className="text-sm text-slate-800 italic">
              "paratactic-to-hypotactic transformation"
            </div>
            <div className="text-xs text-green-600 mt-1">
              ✓ Superior - The hyphenated form and addition of "transformation" more precisely captures the 
              Chinese "意合转形合" (structural transformation in discourse)
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Code formatting issue:</div>
            <div className="text-sm text-slate-800 italic">
              "the BOOTSTRAP → ANALYZE → BUILD → TRANSLATE → VERIFY → REPAIR → AUDIT → EMIT phases"
            </div>
            <div className="text-xs text-red-600 mt-1">
              ✗ Problem - Should be in backticks like `BOOTSTRAP → ANALYZE...` for technical documentation
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Stylistic excellence:</div>
            <div className="text-sm text-slate-800 italic">
              "my core assessment is this: it is a rigorously designed..."
            </div>
            <div className="text-xs text-green-600 mt-1">
              ✓ Excellent - The colon creates natural rhythm and emphasis, superior to V1/V3's longer phrasing
            </div>
          </div>
        </div>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-purple-500 mr-2">🎯</span> Overall Grade
        </h4>
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-green-900">Final Score:</span>
            <span className="text-2xl font-bold text-green-600">92/100</span>
          </div>
          <p className="text-sm text-green-800">
            The most stylistically sophisticated translation with superior phrasing and lexical choices. 
            The lack of code formatting is a significant technical documentation flaw that prevents it from 
            being the top choice, but the prose quality is exceptional. <strong>With formatting fixes, this would 
            be the best version.</strong>
          </p>
        </div>
      </div>
    </div>
  );
}

function Version3Critique() {
  return (
    <div className="space-y-6">
      <div className="prose prose-slate max-w-none">
        <h4 className="text-lg font-bold text-slate-900 flex items-center">
          <span className="text-green-500 mr-2">✅</span> Strengths
        </h4>
        <ul className="text-slate-700 space-y-2">
          <li>
            <strong className="text-green-600">Superior formatting consistency:</strong> Perfect use of backticks for 
            all code elements, filenames, and technical terms throughout the document.
          </li>
          <li>
            <strong>Optimal emphasis through formatting:</strong> Uses **bold** for "Audit Trace" in the L3 description, 
            correctly highlighting this important technical feature.
          </li>
          <li>
            <strong>Precise technical term handling:</strong> Properly formats Chinese example as <code>`"成立"`</code> 
            and English as <code>`"Confirmed"`</code> with both backticks and quotes, making it crystal clear these 
            are linguistic examples.
          </li>
          <li>
            <strong>Best title formatting:</strong> Uses backticks for <code>`Translation-Runtime-Architecture`</code> 
            in the conclusion, properly treating it as a project/repository name.
          </li>
          <li>
            <strong>Professional em-dash usage:</strong> The conclusion uses an em-dash (—) instead of "and serves as", 
            which is more sophisticated punctuation.
          </li>
          <li>
            <strong>Maintains all V1 strengths:</strong> Excellent terminology, structural fidelity, and technical accuracy.
          </li>
          <li>
            <strong>Consistent bullet points:</strong> Uses proper markdown formatting throughout all sections.
          </li>
        </ul>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-amber-500 mr-2">⚠️</span> Areas for Improvement
        </h4>
        <ul className="text-slate-700 space-y-2">
          <li>
            <strong>Very minor - "The Quality Ladder" vs alternatives:</strong> While "Ladder" effectively conveys 
            "阶梯", it's only marginally better than "Hierarchy" - both are acceptable.
          </li>
          <li>
            <strong>Slight verbosity:</strong> Like V1, "sequentially pass through stages such as" could be shortened 
            to "proceed through" (as in V2), though this is a negligible issue.
          </li>
          <li>
            <strong>Minor stylistic consideration:</strong> The opening is identical to V1, whereas V2's "my core 
            assessment is this:" has slightly more rhetorical flair (though V3's version is perfectly professional).
          </li>
        </ul>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-blue-500 mr-2">📊</span> Specific Examples
        </h4>
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 space-y-3">
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Perfect code formatting:</div>
            <div className="text-sm text-slate-800 font-mono bg-white p-2 rounded border border-slate-300">
              `BOOTSTRAP → ANALYZE → BUILD → TRANSLATE → VERIFY → REPAIR → AUDIT → EMIT`
            </div>
            <div className="text-xs text-green-600 mt-1">
              ✓ Excellent - Proper markdown backtick usage for technical state machine phases
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Linguistic example handling:</div>
            <div className="text-sm text-slate-800 font-mono bg-white p-2 rounded border border-slate-300">
              `"成立"` must be translated as `"Confirmed"`
            </div>
            <div className="text-xs text-green-600 mt-1">
              ✓ Superior - Double formatting (backticks + quotes) makes it absolutely clear these are 
              linguistic examples, not regular text
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Technical term emphasis:</div>
            <div className="text-sm text-slate-800 italic">
              "Requires a complete glossary, precise cognitive mapping, and an **Audit Trace**."
            </div>
            <div className="text-xs text-green-600 mt-1">
              ✓ Excellent - Bold formatting draws appropriate attention to this key technical feature
            </div>
          </div>
          <div>
            <div className="text-sm font-semibold text-slate-600 mb-1">Professional punctuation:</div>
            <div className="text-sm text-slate-800 italic">
              "building high-quality, high-confidence translation systems—a highly valuable reference."
            </div>
            <div className="text-xs text-green-600 mt-1">
              ✓ Excellent - Em-dash creates elegant flow, more sophisticated than "and serves as"
            </div>
          </div>
        </div>

        <h4 className="text-lg font-bold text-slate-900 flex items-center mt-6">
          <span className="text-purple-500 mr-2">🎯</span> Overall Grade
        </h4>
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-purple-900">Final Score:</span>
            <span className="text-2xl font-bold text-purple-600">95/100</span>
          </div>
          <p className="text-sm text-purple-800">
            <strong className="text-purple-900">The best overall translation.</strong> Combines all the accuracy 
            and terminological precision of V1 with superior formatting conventions essential for technical documentation. 
            The consistent use of backticks, proper bold emphasis, and sophisticated punctuation make this the 
            most polished and publication-ready version. This demonstrates understanding that technical translation 
            isn't just about words—formatting and presentation are integral to clarity.
          </p>
        </div>

        <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-l-4 border-green-500 p-4 mt-4">
          <p className="text-sm text-green-900">
            <strong>Recommendation:</strong> Use Version 3 as-is for publication. The only improvements would be 
            minor stylistic polishing (potentially adopting V2's opening phrasing for more rhetorical impact), 
            but these are aesthetic preferences rather than quality issues.
          </p>
        </div>
      </div>
    </div>
  );
}

function ComparativeAnalysis() {
  return (
    <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
      <div className="bg-gradient-to-r from-slate-700 to-slate-800 px-6 py-4">
        <h3 className="text-xl font-bold text-white">Comparative Analysis: Key Differences</h3>
      </div>
      <div className="p-8 space-y-6">
        {/* Terminology Comparison */}
        <div>
          <h4 className="text-lg font-bold text-slate-900 mb-3">📚 Terminology Choices</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-sm border border-slate-200">
              <thead className="bg-slate-100">
                <tr>
                  <th className="px-4 py-2 text-left font-semibold text-slate-700 border-b border-slate-200">Chinese Term</th>
                  <th className="px-4 py-2 text-left font-semibold text-blue-700 border-b border-slate-200">Version 1</th>
                  <th className="px-4 py-2 text-left font-semibold text-green-700 border-b border-slate-200">Version 2</th>
                  <th className="px-4 py-2 text-left font-semibold text-purple-700 border-b border-slate-200">Version 3</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="px-4 py-3 font-mono text-slate-600">翻译流程</td>
                  <td className="px-4 py-3">translation workflow</td>
                  <td className="px-4 py-3 bg-green-50">translation <strong>pipeline</strong></td>
                  <td className="px-4 py-3">translation <strong>pipeline</strong></td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-mono text-slate-600">质量的阶梯</td>
                  <td className="px-4 py-3">The Hierarchy of Quality</td>
                  <td className="px-4 py-3 bg-green-50">The Quality <strong>Ladder</strong></td>
                  <td className="px-4 py-3 bg-green-50">The Quality <strong>Ladder</strong></td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-mono text-slate-600">事实完整性</td>
                  <td className="px-4 py-3">factual integrity</td>
                  <td className="px-4 py-3 bg-green-50">factual <strong>completeness</strong></td>
                  <td className="px-4 py-3">factual integrity</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-mono text-slate-600">意合转形合</td>
                  <td className="px-4 py-3">parataxis to hypotaxis</td>
                  <td className="px-4 py-3 bg-green-50"><strong>paratactic-to-hypotactic transformation</strong></td>
                  <td className="px-4 py-3">parataxis-to-hypotaxis transformation</td>
                </tr>
                <tr>
                  <td className="px-4 py-3 font-mono text-slate-600">审计追踪</td>
                  <td className="px-4 py-3">Audit Trace</td>
                  <td className="px-4 py-3">audit trail</td>
                  <td className="px-4 py-3 bg-purple-50">**Audit Trace** (bold)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Formatting Comparison */}
        <div>
          <h4 className="text-lg font-bold text-slate-900 mb-3">💅 Formatting & Style</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border border-blue-200 rounded-lg p-4 bg-blue-50">
              <h5 className="font-bold text-blue-900 mb-2">Version 1</h5>
              <ul className="text-sm text-slate-700 space-y-1">
                <li>✅ Consistent backticks for code</li>
                <li>✅ Proper file name formatting</li>
                <li>⚠️ Missing bold on "Audit Trace"</li>
                <li>⚠️ Simple "and serves" ending</li>
              </ul>
            </div>
            <div className="border border-green-200 rounded-lg p-4 bg-green-50">
              <h5 className="font-bold text-green-900 mb-2">Version 2</h5>
              <ul className="text-sm text-slate-700 space-y-1">
                <li>❌ <strong>No backticks</strong> for code elements</li>
                <li>❌ Missing Chinese char formatting</li>
                <li>✅ Excellent em-dash usage</li>
                <li>✅ Natural, concise phrasing</li>
              </ul>
            </div>
            <div className="border border-purple-200 rounded-lg p-4 bg-purple-50">
              <h5 className="font-bold text-purple-900 mb-2">Version 3</h5>
              <ul className="text-sm text-slate-700 space-y-1">
                <li>✅ <strong>Perfect backtick usage</strong></li>
                <li>✅ Bold on "Audit Trace"</li>
                <li>✅ Proper Chinese char formatting</li>
                <li>✅ Professional em-dash</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Critical Insights */}
        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl p-6">
          <h4 className="text-lg font-bold text-indigo-900 mb-3 flex items-center">
            <span className="text-2xl mr-2">💡</span>
            Critical Insights
          </h4>
          <div className="space-y-3 text-slate-700">
            <div className="flex items-start space-x-2">
              <span className="text-indigo-500 font-bold">1.</span>
              <p className="text-sm">
                <strong>Formatting matters in technical translation:</strong> Version 2's superior prose is undermined 
                by lack of markdown conventions. This shows formatting is not cosmetic—it's functional in technical documentation.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <span className="text-indigo-500 font-bold">2.</span>
              <p className="text-sm">
                <strong>Versions 1 and 3 share 95%+ identical content:</strong> They appear to be from the same translation 
                with manual formatting refinements. Version 3 represents the "polished" version of Version 1.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <span className="text-indigo-500 font-bold">3.</span>
              <p className="text-sm">
                <strong>Version 2 shows independent translation:</strong> Different lexical choices ("pipeline" vs "workflow", 
                "completeness" vs "integrity") suggest this was translated independently, not edited from another version.
              </p>
            </div>
            <div className="flex items-start space-x-2">
              <span className="text-indigo-500 font-bold">4.</span>
              <p className="text-sm">
                <strong>Terminology precision vs. natural flow:</strong> Version 2 prioritizes natural English flow, 
                while V1/V3 prioritize terminological exactness. Both approaches have merit depending on audience.
              </p>
            </div>
          </div>
        </div>

        {/* Final Recommendation */}
        <div className="border-l-4 border-purple-500 bg-purple-50 p-6 rounded-r-lg">
          <h4 className="text-lg font-bold text-purple-900 mb-2">🎯 Final Recommendation</h4>
          <p className="text-slate-800 mb-3">
            <strong className="text-purple-700">For publication: Use Version 3 as-is.</strong>
          </p>
          <p className="text-sm text-slate-700 mb-3">
            For maximum quality, consider creating a "Version 4" that combines:
          </p>
          <ul className="text-sm text-slate-700 space-y-1 ml-4">
            <li>✅ Version 3's impeccable formatting and markdown conventions</li>
            <li>✅ Version 2's superior lexical choices ("pipeline", "completeness", "paratactic-to-hypotactic transformation")</li>
            <li>✅ Version 2's engaging opening ("my core assessment is this:")</li>
          </ul>
          <p className="text-sm text-slate-600 mt-3 italic">
            However, Version 3 is already publication-ready at a 95/100 quality level.
          </p>
        </div>
      </div>
    </div>
  );
}
