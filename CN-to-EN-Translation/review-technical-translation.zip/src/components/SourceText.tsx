import { sourceText } from '../data/translations';

export function SourceText() {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 px-6 py-4">
          <h2 className="text-xl font-bold text-white">Original Source Text (Chinese)</h2>
          <p className="text-indigo-100 text-sm mt-1">完整的原始中文文本</p>
        </div>
        <div className="p-8">
          <div className="prose prose-slate max-w-none">
            <div className="whitespace-pre-wrap text-slate-800 leading-relaxed font-serif text-lg">
              {sourceText}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <div className="flex-shrink-0 mt-1">
            <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-blue-900 mb-1">Context</h3>
            <p className="text-sm text-blue-700">
              This is a technical review/critique of the Translation-Runtime-Architecture repository, 
              written in Chinese. The text discusses a formal specification framework for high-fidelity 
              technical translation, covering architecture, instruction sets, modularity, and conformance levels.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
