import { translations } from '../data/translations';

export function ComparisonView() {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Side-by-Side Comparison</h2>
        <p className="text-slate-600 mb-6">Compare all three translation versions simultaneously</p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {translations.map((translation) => (
            <div key={translation.id} className="space-y-3">
              <div className={`rounded-lg px-4 py-2 text-center font-semibold text-white ${
                translation.id === 1 ? 'bg-blue-500' :
                translation.id === 2 ? 'bg-green-500' :
                'bg-purple-500'
              }`}>
                {translation.name}
              </div>
              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200 h-[600px] overflow-y-auto">
                <div className="prose prose-sm max-w-none">
                  <div className="whitespace-pre-wrap text-slate-700 text-sm leading-relaxed">
                    {translation.text}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <div className="flex-shrink-0 mt-1">
            <svg className="w-5 h-5 text-amber-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-amber-900 mb-1">Quick Observation</h3>
            <p className="text-sm text-amber-700">
              All three versions maintain high quality but differ in terminology choices, 
              formatting conventions (backticks, bold text), and stylistic nuances. 
              Version 2 is the most concise, while Versions 1 and 3 are nearly identical 
              with subtle formatting differences.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
