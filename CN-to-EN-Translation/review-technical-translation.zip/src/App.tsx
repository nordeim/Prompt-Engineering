import { useState } from 'react';
import { ComparisonView } from './components/ComparisonView';
import { CritiquePanel } from './components/CritiquePanel';
import { SourceText } from './components/SourceText';

type ViewMode = 'source' | 'comparison' | 'critique';

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('critique');
  const [selectedVersion, setSelectedVersion] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg p-2">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900">Translation Analysis Tool</h1>
                <p className="text-xs text-slate-500">Meticulous Review & Critique</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex space-x-2 bg-white rounded-xl p-1.5 shadow-sm border border-slate-200">
          <button
            onClick={() => setViewMode('source')}
            className={`flex-1 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              viewMode === 'source'
                ? 'bg-indigo-500 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            📄 Source Text
          </button>
          <button
            onClick={() => setViewMode('comparison')}
            className={`flex-1 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              viewMode === 'comparison'
                ? 'bg-indigo-500 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            🔄 Side-by-Side Comparison
          </button>
          <button
            onClick={() => setViewMode('critique')}
            className={`flex-1 px-4 py-2.5 rounded-lg text-sm font-medium transition-all ${
              viewMode === 'critique'
                ? 'bg-indigo-500 text-white shadow-sm'
                : 'text-slate-600 hover:bg-slate-50'
            }`}
          >
            🎯 Detailed Critique
          </button>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        {viewMode === 'source' && <SourceText />}
        {viewMode === 'comparison' && <ComparisonView />}
        {viewMode === 'critique' && (
          <CritiquePanel 
            selectedVersion={selectedVersion}
            setSelectedVersion={setSelectedVersion}
          />
        )}
      </main>
    </div>
  );
}
